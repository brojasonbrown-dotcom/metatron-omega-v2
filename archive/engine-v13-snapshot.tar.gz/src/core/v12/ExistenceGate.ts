/**
 * ExistenceGate — scale-aware admission (RHUFT Ch. 1 §12 existsQ).
 *
 * A structure "exists" at scale n only if it clears four thresholds:
 *   1. signal      — amplitude above noise floor
 *   2. persistence — survives ≥ Fibonacci window of ticks
 *   3. coherence   — local Kuramoto r above threshold
 *   4. relational  — chainUpCoupling within band of its rung
 *
 * Gate returns a bit vector + composite score. Only structures passing at
 * their own scale should contribute to memory consolidation. This kills
 * the noise-inflation problem in the raw pattern store.
 *
 * Pure, deterministic, no engine mutation.
 */

export const FIB_WINDOW = Object.freeze([3, 5, 8, 13, 21] as const);

export interface ExistenceThresholds {
  signal: number;        // e.g. 0.05
  persistence: number;   // ticks; snapped to nearest Fib window
  coherence: number;     // e.g. 0.30 (Kuramoto r)
  relationBandLow: number;  // e.g. 0.10
  relationBandHigh: number; // e.g. 0.90
}

export const DEFAULT_THRESHOLDS: ExistenceThresholds = Object.freeze({
  signal: 0.05,
  persistence: 8,
  coherence: 0.30,
  relationBandLow: 0.10,
  relationBandHigh: 0.90,
});

export interface ExistenceCandidate {
  signalScore: number;
  ticksAlive: number;
  coherenceScore: number;
  chainUpCoupling: number;
}

export interface ExistenceVerdict {
  exists: boolean;
  score: number;      // ∈ [0,1] — geometric mean of the four normalized ratios
  passed: {
    signal: boolean;
    persistence: boolean;
    coherence: boolean;
    relation: boolean;
  };
}

function snapFib(n: number): number {
  let best: number = FIB_WINDOW[0];
  let dBest = Infinity;
  for (const f of FIB_WINDOW) {
    const d = Math.abs(f - n);
    if (d < dBest) { dBest = d; best = f; }
  }
  return best;
}

export function existsQ(
  c: ExistenceCandidate,
  t: Partial<ExistenceThresholds> = {},
): ExistenceVerdict {
  const th = { ...DEFAULT_THRESHOLDS, ...t };
  const persistTh = snapFib(th.persistence);

  const passSignal = c.signalScore >= th.signal;
  const passPersist = c.ticksAlive >= persistTh;
  const passCoh = c.coherenceScore >= th.coherence;
  const passRel = c.chainUpCoupling >= th.relationBandLow &&
                  c.chainUpCoupling <= th.relationBandHigh;

  // Normalized 0..1 contributions (clamped) for the composite score.
  const rSig = Math.min(1, c.signalScore / Math.max(1e-9, th.signal));
  const rPer = Math.min(1, c.ticksAlive / Math.max(1, persistTh));
  const rCoh = Math.min(1, c.coherenceScore / Math.max(1e-9, th.coherence));
  const bandWidth = Math.max(1e-9, th.relationBandHigh - th.relationBandLow);
  const dCenter = Math.abs(c.chainUpCoupling - (th.relationBandLow + th.relationBandHigh) / 2);
  const rRel = Math.max(0, 1 - (dCenter / (bandWidth / 2)));

  const score = Math.pow(Math.max(1e-12, rSig * rPer * rCoh * rRel), 0.25);
  const exists = passSignal && passPersist && passCoh && passRel;
  return {
    exists,
    score,
    passed: { signal: passSignal, persistence: passPersist, coherence: passCoh, relation: passRel },
  };
}
