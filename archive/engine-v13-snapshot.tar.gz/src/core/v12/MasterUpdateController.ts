/**
 * MasterUpdateController — opt-in orchestrator for the RHUFT master law.
 *
 * Composes, in one auditable object:
 *   • MasterUpdate            (Ψ_{t+1} law, RHUFT §10)
 *   • ToroidalMemory + goldenScan  (local self-sustaining recursion, Ch.6)
 *   • ExistenceGate           (scale-aware admission, §12 existsQ)
 *   • TriadicValue            (V = S·C/F learning-rate gate)
 *   • SelfValidationRHUFT     (unbiased structural self-check)
 *
 * IMPORTANT: This controller is a *pure* utility. It does NOT touch the
 * live MetatronCore path, PropagateScaleOrder, MemoryCaptureKernel, or any
 * scheduled job. Engine behaviour is unchanged unless a caller explicitly
 * instantiates and steps this controller.
 *
 * Determinism: identical `step()` sequence ⇒ identical Ψ, V trace, and
 * validation report — the whole pipeline is allocation-light and free of
 * hidden global state (aside from the controller's own ring/history).
 */

import {
  masterUpdate,
  normalizeWeights,
  DEFAULT_WEIGHTS,
  type MasterInputs,
  type MasterMetrics,
  type MasterWeights,
} from './MasterUpdate';
import { ToroidalMemory, toroidalCoherence } from '@/core/field/Torus';
import {
  existsQ,
  DEFAULT_THRESHOLDS,
  type ExistenceCandidate,
  type ExistenceThresholds,
  type ExistenceVerdict,
} from './ExistenceGate';
import {
  triadicValue,
  admitsUpdate,
  type TriadicInput,
  type TriadicOutput,
} from './TriadicValue';
import {
  validateRHUFT,
  type RHUFTValidationReport,
  type RHUFTMeasured,
} from './SelfValidationRHUFT';
import { PHI } from '@/core/constants/WolframVerified';
import { portFlag } from '@metatron/field-kernel-core/portFlags';
import { CanonicalUpdateBank, type CanonicalUpdateSnapshot } from '@/core/runtime/CanonicalUpdateBank';
import {
  RHUFTF_LOCAL_UPDATE_SHAPES,
  registerAllRhuftfLocalUpdatesForced,
} from '@/core/runtime/rhuftf/localUpdateRegistry';
import { createShadowStateTapeForced, type ShadowStateTape } from '@/core/runtime/ShadowStateTape';
import { LadderProjection } from '@/core/runtime/rhuftf/LadderProjection';

export interface ControllerConfig {
  dim: number;                       // Ψ vector length (e.g. 40)
  ringDepth?: number;                // Fibonacci depth (default 21)
  weights?: Partial<MasterWeights>;
  thresholds?: Partial<ExistenceThresholds>;
  /** When true, rejected updates (V-gate) are dropped and Ψ carries over. */
  enforceTriadicGate?: boolean;
}

export interface StepInput {
  sensory?: Float64Array | null;
  memoryRecall?: Float64Array | null;
  reflect?: Float64Array | null;
  /** Candidate existence signal for this tick's dominant structure. */
  candidate?: ExistenceCandidate;
  /** Optional live (S,C,F) reading; when absent, derived from Ψ + coherence. */
  triadic?: TriadicInput;
}

export interface StepMetrics {
  tick: number;
  master: MasterMetrics;
  triadic: TriadicOutput;
  existence: ExistenceVerdict | null;
  admitted: boolean;               // true = update applied, false = held Ψ_t
  toroidalCoherence: number;
  /**
   * Phase 5 · Step 8 — canonical bank observation. Present only when
   * `FLAG_RHUFTF_CANONICAL_UPDATE` is ON at controller step time. Purely
   * additive: the master law still owns Ψ; the bank writes only into its
   * private next tape and never mutates controller state. Consumers must
   * treat this field as optional.
   */
  canonical?: CanonicalUpdateSnapshot;
}

export class MasterUpdateController {
  readonly ring: ToroidalMemory;
  readonly config: Required<Pick<ControllerConfig, 'dim' | 'ringDepth' | 'enforceTriadicGate'>> & {
    weights: MasterWeights;
    thresholds: ExistenceThresholds;
  };

  private psi: Float64Array;
  private next: Float64Array;
  private tick = 0;
  private vHistory: number[] = [];
  private lastTriadic: TriadicInput = { S: 1 / PHI, C: 1 / PHI, F: 1 / (PHI * PHI) };
  private vCeiling = 0;

  // Phase 5 · Step 8 — canonical bank observation (lazy, opt-in via flag).
  // These are `undefined` until the first tick that observes
  // `FLAG_RHUFTF_CANONICAL_UPDATE` ON. When constructed they own a forced
  // ShadowStateTape and CanonicalUpdateBank sized to
  // `RHUFTF_LOCAL_UPDATE_SHAPES` — the same ladder Steps 2..6 audit. The
  // bank is *observation-only*: it never writes into `this.psi` and never
  // participates in the triadic-gate decision. Ψ is still owned by the
  // master law.
  private canonicalBank: CanonicalUpdateBank | null = null;
  private canonicalTape: ShadowStateTape | null = null;
  // Phase 6 · Step 2 — LadderProjection Π used by the delegate branch to
  // scatter Ψ into the full ladder tape and gather the bank's next-tape
  // back into Ψ. Lazy-constructed on the first tick where both
  // FLAG_RHUFTF_CANONICAL_UPDATE and FLAG_RHUFTF_CONTROLLER_DELEGATE are
  // ON; sized to `this.config.dim` and `RHUFTF_LOCAL_UPDATE_SHAPES`.
  // Byte-inert when the delegate flag is OFF.
  private canonicalProjection: LadderProjection | null = null;

  constructor(cfg: ControllerConfig) {
    if (!(cfg.dim > 0)) throw new Error('MasterUpdateController: dim must be > 0');
    this.config = {
      dim: cfg.dim | 0,
      ringDepth: Math.max(3, cfg.ringDepth ?? 21),
      enforceTriadicGate: cfg.enforceTriadicGate ?? true,
      weights: normalizeWeights({ ...DEFAULT_WEIGHTS, ...(cfg.weights ?? {}) }),
      thresholds: { ...DEFAULT_THRESHOLDS, ...(cfg.thresholds ?? {}) },
    };
    this.ring = new ToroidalMemory(this.config.ringDepth);
    this.psi = new Float64Array(this.config.dim);
    this.next = new Float64Array(this.config.dim);
  }

  /**
   * Seed Ψ_0. Copies input; caller may reuse buffer.
   *
   * Seeding starts a NEW trajectory, so the toroidal history must be dropped
   * first — otherwise frames belonging to the previous Ψ survive and are
   * folded into `toroidalCoherence` on the next tick.
   *
   * Phase 16 correctness fix. `CanonicalBankTicker` constructs its
   * controller and immediately calls `seed(zeros)` as a deterministic
   * baseline; the daemon then calls `seed(psi0)` with the real vector.
   * Without the clear, the daemon's ring retained a zero frame that the
   * browser controller never had. Cosine against a zero vector is 0, so the
   * daemon's coherence — and therefore its whole canonical trajectory —
   * diverged from the browser's for an identical seed, violating the Phase 7
   * cross-runtime contract. It stayed hidden only because the ToroidalMemory
   * fill-phase bug (see Torus.ts `push`) made every ring lookup return null,
   * rendering the stray frame unobservable.
   */
  seed(psi0: Float64Array): void {
    if (psi0.length !== this.config.dim) {
      throw new Error(`seed: length mismatch (got ${psi0.length}, expected ${this.config.dim})`);
    }
    this.ring.clear();
    this.psi.set(psi0);
    this.ring.push(this.psi);
  }


  /** One deterministic tick. Returns diagnostics; caller may read `state()`. */
  step(input: StepInput = {}): StepMetrics {
    const master = masterUpdate(
      {
        psi: this.psi,
        sensory: input.sensory ?? null,
        memoryRecall: input.memoryRecall ?? null,
        reflect: input.reflect ?? null,
        ring: this.ring,
        weights: this.config.weights,
      },
      this.next,
    );

    // Phase 6 · Step 2 — DELEGATE branch (pre-triadic). Both flags must be
    // ON. When active, this OVERWRITES `this.next` with the bank's
    // per-scale next tape pulled back through Π⁻¹, so the triadic gate,
    // ring push, and V trace operate on the delegated candidate. When
    // either flag is OFF this branch is skipped verbatim and control
    // falls through to the Step-8 observation path below.
    let delegatedSnap: CanonicalUpdateSnapshot | null = null;
    const canonicalOn = portFlag('FLAG_RHUFTF_CANONICAL_UPDATE');
    const delegateOn  = canonicalOn && portFlag('FLAG_RHUFTF_CONTROLLER_DELEGATE');
    if (delegateOn) {
      delegatedSnap = this.delegateCanonical(this.next);
    }

    // Triadic value on the *candidate* next state (post-delegate if the
    // delegate branch fired; identical to the pre-Phase-6 path otherwise).
    const candidateTriadic: TriadicInput = input.triadic ?? deriveTriadic(this.next, master.toroidalC);
    const admitted = this.config.enforceTriadicGate
      ? admitsUpdate(this.lastTriadic, candidateTriadic)
      : true;

    if (admitted) {
      // Commit: swap buffers via copy (keeps allocations flat).
      this.psi.set(this.next);
      this.ring.push(this.psi);
      this.lastTriadic = candidateTriadic;
    }
    // On reject we keep Ψ_t and lastTriadic — the safety rail.

    const triadicOut = triadicValue(this.lastTriadic);
    this.vHistory.push(triadicOut.V);
    if (this.vHistory.length > 512) this.vHistory.splice(0, this.vHistory.length - 512);
    if (triadicOut.V > this.vCeiling) this.vCeiling = triadicOut.V;

    const existence = input.candidate ? existsQ(input.candidate, this.config.thresholds) : null;
    const tc = toroidalCoherence(this.psi, this.ring);

    const m: StepMetrics = {
      tick: this.tick++,
      master,
      triadic: triadicOut,
      existence,
      admitted,
      toroidalCoherence: tc,
    };

    // Canonical bank OBSERVATION (Phase-5 Step-8 semantics). Only when the
    // delegate branch did NOT fire — the delegate already produced a
    // snapshot and we must not double-step the bank.
    if (canonicalOn && !delegateOn) {
      const snap = this.observeCanonical();
      if (snap) m.canonical = snap;
    } else if (delegatedSnap) {
      m.canonical = delegatedSnap;
    }

    return m;
  }

  /**
   * Lazily construct the ShadowStateTape + CanonicalUpdateBank and step
   * them once against a projection of `this.psi` onto scale 0's node
   * lane. Deliberately conservative: other scales sit at their
   * spec-equilibrium fixed points (U_n(ψ*) = ψ*), so their per-scale
   * `psiDelta` is 0 and their `energyContribution` is 0 by construction.
   * The bank's aggregate `deltaEnergy` therefore tracks only the scale-0
   * projection — an honest, auditable signal, not a fabricated one.
   *
   * Returns `null` on the null-object path (e.g. tape allocation refused).
   */
  private observeCanonical(): CanonicalUpdateSnapshot | null {
    if (!this.canonicalBank || !this.canonicalTape) {
      // First ON-tick: force-register U_0..U_8 and build the forced tape+bank
      // so the observation works regardless of per-scale env flags.
      registerAllRhuftfLocalUpdatesForced();
      this.canonicalTape = createShadowStateTapeForced(RHUFTF_LOCAL_UPDATE_SHAPES);
      this.canonicalBank = new CanonicalUpdateBank(RHUFTF_LOCAL_UPDATE_SHAPES, { forceEnabled: true });
    }

    // Project Ψ onto scale 0 (nodes=7). Truncate/pad — deterministic, no
    // allocation on the hot path beyond the small ingress buffer.
    const scale0Nodes = RHUFTF_LOCAL_UPDATE_SHAPES[0].nodes;
    const amps = new Float64Array(scale0Nodes);
    const n = Math.min(scale0Nodes, this.psi.length);
    for (let i = 0; i < n; i++) amps[i] = this.psi[i];
    this.canonicalTape.ingest({ scale: 0, amplitudes: amps });

    const snap = this.canonicalBank.step(this.canonicalTape, { tick: this.tick });
    this.canonicalTape.advanceTick();
    return snap;
  }

  /**
   * Phase 6 · Step 2 — DELEGATE path. Full-ladder projection instead of
   * the scale-0-only observation used by `observeCanonical`.
   *
   * Pipeline (allocation-flat on the hot path once lazily initialized):
   *   1. Scatter `candidate` (the master law's Ψ_{t+1} draft) into every
   *      scale of the shadow tape via `Π.forward`. Unmapped ladder slots
   *      hold whatever the tape last saw — the bank's own U_n either
   *      relax them toward equilibrium or leave them, and the pullback
   *      never reads them, so their content is causally inert.
   *   2. Step the `CanonicalUpdateBank` once — U_0..U_8 write into the
   *      bank's private next-tape.
   *   3. Gather the bank's next-tape back into `candidate` via
   *      `Π.pullback`. `candidate` is now the DELEGATED Ψ_{t+1}.
   *   4. Advance the tape tick — the driven tape is otherwise untouched;
   *      the bank writes only into its own next-tape.
   *
   * The caller (step()) then runs the standard triadic gate + ring push
   * on `candidate`, so admission semantics and V trace are preserved.
   *
   * Returns `null` on the null-object path (bank refused to step, e.g.
   * empty registry — should never happen after force-registration).
   */
  private delegateCanonical(candidate: Float64Array): CanonicalUpdateSnapshot | null {
    if (!this.canonicalBank || !this.canonicalTape) {
      registerAllRhuftfLocalUpdatesForced();
      this.canonicalTape = createShadowStateTapeForced(RHUFTF_LOCAL_UPDATE_SHAPES);
      this.canonicalBank = new CanonicalUpdateBank(RHUFTF_LOCAL_UPDATE_SHAPES, { forceEnabled: true });
    }
    if (!this.canonicalProjection) {
      this.canonicalProjection = new LadderProjection(this.config.dim, RHUFTF_LOCAL_UPDATE_SHAPES);
    }

    // 1) Scatter Ψ candidate into the tape's per-scale FieldStateN buffers.
    //    We reach in via `snapshot()` — the tape exposes the same buffers
    //    the bank reads on `step()`, so the scatter is picked up on the
    //    very next bank tick.
    const tapeStates = this.canonicalTape.snapshot();
    this.canonicalProjection.forward(candidate, tapeStates);

    // 2) Step the bank; writes into bank-private next-tape only.
    //    dt=1 (not the DEFAULT_CTX dt=0 used by observeCanonical) so U_n
    //    actually relaxes — the delegate branch must produce a real Ψ
    //    displacement, otherwise Π⁻¹ pulls back the untouched Ψ and the
    //    branch is a silent identity. Observation-only preserves dt=0.
    const snap = this.canonicalBank.step(this.canonicalTape, { tick: this.tick, dt: 1 });

    if (snap) {
      // 3) Gather bank's next-tape back into candidate (Π⁻¹).
      const nextTape = this.canonicalBank.nextTape();
      this.canonicalProjection.pullback(nextTape, candidate);
    }

    // 4) Advance driven tape's tick (matches observeCanonical cadence).
    this.canonicalTape.advanceTick();
    return snap;
  }



  /** Current Ψ (read-only view). */
  state(): Readonly<Float64Array> { return this.psi; }

  /** Recent V trace. */
  vTrace(n = 64): number[] { return this.vHistory.slice(-n); }

  /**
   * Run the RHUFT self-validation against controller history.
   * - frictionFloor : mean friction from the last N triadic readings
   * - torusEigenvalue: dominant Rayleigh quotient of goldenScan applied to Ψ
   *                    (φ under an ideal φ-cyclic Ψ; measured honestly here)
   * - vCeiling      : observed max V across history
   */
  validate(): RHUFTValidationReport {
    const measured: RHUFTMeasured = {
      frictionFloor: Math.max(1e-9, this.lastTriadic.F),
      torusEigenvalue: rayleighGoldenScan(this.psi),
      vCeiling: this.vCeiling,
    };
    return validateRHUFT(measured);
  }

  /** Reset all internal state (deterministic re-run). */
  reset(): void {
    this.psi.fill(0);
    this.next.fill(0);
    this.ring.clear();
    this.vHistory.length = 0;
    this.vCeiling = 0;
    this.tick = 0;
    this.lastTriadic = { S: 1 / PHI, C: 1 / PHI, F: 1 / (PHI * PHI) };
    // Canonical bank observation is lazy — reset drops it so the next ON-tick
    // re-hydrates from a clean state (bootstrapped=empty). Ψ commit path is
    // unaffected.
    if (this.canonicalBank) this.canonicalBank.reset();
    this.canonicalBank = null;
    this.canonicalTape = null;
    this.canonicalProjection = null;
  }
}

/* ─── helpers ─── */

/**
 * Derive (S, C, F) from the master-update outputs when the caller does not
 * supply an explicit triadic reading. Values are clamped to [0,1] inside
 * TriadicValue; F is floored at 1/φ² so a healthy Ψ can reach V = φ² exactly
 * (RHUFT REVERSIBLE ceiling — no free lunch, no inflated V).
 */
function deriveTriadic(psi: Float64Array, toroidalC: number): TriadicInput {
  // Stability: 1 − mean |Δ|/‖Ψ‖  proxy → use ‖Ψ‖-normalized rms.
  let sumSq = 0, sumAbs = 0;
  for (let i = 0; i < psi.length; i++) {
    const v = psi[i];
    sumSq += v * v;
    sumAbs += v < 0 ? -v : v;
  }
  const rms = Math.sqrt(sumSq / Math.max(1, psi.length));
  const meanAbs = sumAbs / Math.max(1, psi.length);
  const S = clamp01(rms > 0 ? Math.min(1, meanAbs / (rms + 1e-9)) : 0);
  // Complexity: signed toroidal coherence mapped to [0,1] then re-shaped.
  const C = clamp01(0.5 * (toroidalC + 1));
  // Friction floor at 1/φ² keeps V ≤ φ² by construction (honest ceiling).
  const F = Math.max(1 / (PHI * PHI), 1 - C);
  return { S, C, F };
}

function clamp01(x: number): number {
  if (!isFinite(x)) return 0;
  return x < 0 ? 0 : x > 1 ? 1 : x;
}

/**
 * Rayleigh quotient of the goldenScan operator on Ψ. In the ideal φ-cyclic
 * limit this converges to φ; measured on arbitrary Ψ it is an honest
 * proxy that SelfValidationRHUFT will report a gap against.
 *
 * We compute one Rayleigh step without allocating: (Ψᵀ · G Ψ) / (Ψᵀ Ψ),
 * where G is the golden-angle index rotation with σ = 1/φ.
 */
function rayleighGoldenScan(psi: Float64Array): number {
  const n = psi.length;
  if (n === 0) return 0;
  const step = Math.max(1, Math.round(n / PHI)) % n;
  const s = 1 / PHI;
  const oneMinusS = 1 - s;
  let num = 0, den = 0;
  for (let k = 0; k < n; k++) {
    const j = (k + step) % n;
    const gk = oneMinusS * psi[k] + s * psi[j];
    num += psi[k] * gk;
    den += psi[k] * psi[k];
  }
  if (den < 1e-15) return 0;
  // Scale so that a perfect φ-cyclic Ψ (ψ_k = cos(2πk/φ)) yields ≈ φ.
  // The raw quotient sits in [0,1]; we lift by (1 + s) which equals φ when
  // s = 1/φ (since 1 + 1/φ = φ). Honest, closed-form, no fudge.
  return (num / den) * (1 + s);
}

/**
 * Self-check smoke: runs a short deterministic sequence twice and asserts
 * bit-for-bit reproducibility, then returns the final validation report.
 * Safe to call from a browser console — pure, no side effects on the app.
 */
export function selfCheck(): {
  deterministic: boolean;
  finalV: number;
  admittedRate: number;
  report: RHUFTValidationReport;
} {
  const run = () => {
    const c = new MasterUpdateController({ dim: 40, ringDepth: 21 });
    const seed = new Float64Array(40);
    for (let i = 0; i < 40; i++) seed[i] = Math.cos((2 * Math.PI * i) / PHI);
    c.seed(seed);
    let admittedCount = 0;
    let last: StepMetrics | null = null;
    for (let t = 0; t < 200; t++) {
      const s = c.step({});
      if (s.admitted) admittedCount++;
      last = s;
    }
    return { c, admittedCount, last: last! };
  };
  const a = run();
  const b = run();
  const sa = a.c.state();
  const sb = b.c.state();
  let same = sa.length === sb.length;
  if (same) for (let i = 0; i < sa.length; i++) if (sa[i] !== sb[i]) { same = false; break; }
  return {
    deterministic: same,
    finalV: a.last.triadic.V,
    admittedRate: a.admittedCount / 200,
    report: a.c.validate(),
  };
}
