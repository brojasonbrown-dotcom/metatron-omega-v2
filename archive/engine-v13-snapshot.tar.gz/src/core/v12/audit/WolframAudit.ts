/**
 * V12 — Wolfram-style identity audit (in-engine).
 * ────────────────────────────────────────────────────────────────────────────
 * Runs deterministic high-precision checks on the constants and weight
 * structure used by `MetatronCoreV2.ts`. No external API call — all checks
 * are derivable from φ and the rung scale anchors, so the audit can run
 * every tick in the browser without latency.
 *
 * Each check reports a "digit count" = floor(-log10(|residual|)). A real
 * Wolfram bridge can be wired in later by replacing `nativeRef()` with an
 * RPC call; the interface is stable.
 */

import { PHI, PHI_INV, PHI_SQ } from '@/core/frameworks/constants';
import {
  V12_ORDER,
  LOG10_SCALE,
  computeLogScaleWeights,
  type V12Framework,
} from '../LogScaleWeights';

export interface AuditCheck {
  id: string;
  label: string;
  /** Value derived from live JS constants / weights. */
  computed: number;
  /** Reference value (closed-form or symbolic). */
  reference: number;
  /** |computed - reference|. */
  residual: number;
  /** floor(-log10(residual)) — clamped to [0, 16]. */
  matchingDigits: number;
  grade: 'IDENTITY' | 'EXCELLENT' | 'GOOD' | 'WEAK' | 'BROKEN';
}

export interface AuditReport {
  checks: AuditCheck[];
  /** Worst residual across all checks. */
  worstResidual: number;
  /** Minimum matching-digits across all checks. */
  minDigits: number;
  /** Per-rung scale-ratio table for the audit UI. */
  scaleTable: Array<{
    framework: V12Framework;
    log10Scale: number;
    log10RatioToPlanck: number;
    phiOctavesFromF4: number;
    weight: number;
  }>;
}

function digitsOf(r: number): number {
  if (!isFinite(r) || r <= 0) return 16;
  return Math.max(0, Math.min(16, Math.floor(-Math.log10(r))));
}

function grade(d: number): AuditCheck['grade'] {
  if (d >= 15) return 'IDENTITY';
  if (d >= 12) return 'EXCELLENT';
  if (d >=  9) return 'GOOD';
  if (d >=  6) return 'WEAK';
  return 'BROKEN';
}

function mk(id: string, label: string, computed: number, reference: number): AuditCheck {
  const residual = Math.abs(computed - reference);
  const d = digitsOf(residual);
  return { id, label, computed, reference, residual, matchingDigits: d, grade: grade(d) };
}

export function runAudit(): AuditReport {
  const weights = computeLogScaleWeights();
  const sumW = weights.reduce((s, w) => s + w.weight, 0);

  const checks: AuditCheck[] = [
    mk('phi_identity',  'φ² = φ + 1',              PHI_SQ,                       PHI + 1),
    mk('phi_inv',       'φ · φ⁻¹ = 1',             PHI * PHI_INV,                1),
    mk('phi_inv_def',   'φ⁻¹ = φ − 1',             PHI_INV,                      PHI - 1),
    mk('phi_sum',       '1 + φ⁻¹ = φ',             1 + PHI_INV,                  PHI),
    mk('weight_sum',    'Σ wᵢ = 1 (log-scale wts)', sumW,                        1),
    mk('identity_close','∏ 1^wᵢ = 1 (identity vec)', Math.exp(
        weights.reduce((s, w) => s + w.weight * Math.log(1), 0)
      ), 1),
  ];

  // Pairwise log-scale ratios — verify F4 sits at the geometric centre.
  const f4 = LOG10_SCALE.F4;
  const planck = LOG10_SCALE.F8;
  checks.push(mk('f4_at_planck',
    'F4 within 1 φ-octave of F8 (Planck floor)',
    Math.abs(LOG10_SCALE.F4 - planck) / Math.log10(PHI), 9.572, // 2 decades = ~9.6 φ-octaves
  ));
  // Tolerance for that one is loose (it's a derived target, not an identity),
  // so let the digit count read what it reads — we still surface it.

  const worstResidual = checks.reduce((m, c) => Math.max(m, c.residual), 0);
  const minDigits = checks.reduce((m, c) => Math.min(m, c.matchingDigits), 16);

  const scaleTable = V12_ORDER.map((fw) => {
    const w = weights.find((x) => x.framework === fw)!;
    return {
      framework: fw,
      log10Scale: LOG10_SCALE[fw],
      log10RatioToPlanck: LOG10_SCALE[fw] - planck,
      phiOctavesFromF4: Math.abs(LOG10_SCALE[fw] - f4) / Math.log10(PHI),
      weight: w.weight,
    };
  });

  return { checks, worstResidual, minDigits, scaleTable };
}
