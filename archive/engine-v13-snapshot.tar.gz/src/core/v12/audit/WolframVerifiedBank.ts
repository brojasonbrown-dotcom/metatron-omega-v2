/**
 * METATRON V12 — WOLFRAM-VERIFIED BANK (PHASE 1)
 * =================================================================
 * Auto-materialized from docs/v12_migration/wolfram/results.jsonl
 * via `python3 scripts/materialize_wolfram_bank.py`.
 *
 * Every literal here was independently re-derived by Wolfram Alpha
 * (App ID WOLFRAM_APP_ID_RESEARCH) at 30–60 digit precision. The
 * `digits` field is the textual result Wolfram returned; the `value`
 * field is the IEEE-754 round-trip of that result. The two MUST agree
 * to ≥15 digits — any disagreement throws at module load.
 *
 * DO NOT EDIT BY HAND. To add or change a constant, edit the queries
 * in scripts/wolfram_runner.py and re-run the runner + materializer.
 */

export interface WolframVerifiedEntry {
  readonly id: string;
  readonly area: string;
  readonly input: string;
  readonly digits: string;
  readonly value: number;
}

export const WOLFRAM_VERIFIED_BANK: Record<string, WolframVerifiedEntry> = {
  PHI_60: { id: "PHI_60", area: "01_phi_psi", input: "N[GoldenRatio, 60]", digits: "1.61803398874989484820458683436563811772030917980576286213545", value: 1.618033988749895 },
  INV_PHI_60: { id: "INV_PHI_60", area: "01_phi_psi", input: "N[1/GoldenRatio, 60]", digits: "0.618033988749894848204586834365638117720309179805762862135449", value: 0.6180339887498949 },
  PHI_SQ_60: { id: "PHI_SQ_60", area: "01_phi_psi", input: "N[GoldenRatio^2, 60]", digits: "2.61803398874989484820458683436563811772030917980576286213545", value: 2.618033988749895 },
  LN_PHI_60: { id: "LN_PHI_60", area: "01_phi_psi", input: "N[Log[GoldenRatio], 60]", digits: "0.481211825059603447497758913424368423135184334385660519661018", value: 0.48121182505960347 },
  PSI_60: { id: "PSI_60", area: "01_phi_psi", input: "N[1+Sqrt[2], 60]", digits: "2.41421356237309504880168872420969807856967187537694807317668", value: 2.414213562373095 },
  PSI_SQ_60: { id: "PSI_SQ_60", area: "01_phi_psi", input: "N[(1+Sqrt[2])^2, 60]", digits: "5.82842712474619009760337744841939615713934375075389614635336", value: 5.82842712474619 },
  INV_SQRT5_60: { id: "INV_SQRT5_60", area: "01_phi_psi", input: "N[1/Sqrt[5], 60]", digits: "0.447213595499957939281834733746255247088123671922305144854179", value: 0.4472135954999579 },
  PHI_COS_ATTR_60: { id: "PHI_COS_ATTR_60", area: "01_phi_psi", input: "N[1 - 1/Sqrt[5], 60]", digits: "0.552786404500042060718165266253744752911876328077694855145821", value: 0.552786404500042 },
  HEPT_SUM_COS: { id: "HEPT_SUM_COS", area: "02_heptagonal", input: "Sum[Cos[2 Pi k/7], {k,0,6}]", digits: "0 (closure, alt-form verified)", value: 0 },
  HEPT_SUM_SIN: { id: "HEPT_SUM_SIN", area: "02_heptagonal", input: "Sum[Sin[2 Pi k/7], {k,0,6}]", digits: "0 (closure)", value: 0 },
  SIN_PI_7: { id: "SIN_PI_7", area: "02_heptagonal", input: "N[Sin[Pi/7], 60]", digits: "0.433883739117558120475768332848358754609990727787459876444547", value: 0.4338837391175581 },
  COS_PI_7: { id: "COS_PI_7", area: "02_heptagonal", input: "N[Cos[Pi/7], 60]", digits: "0.900968867902419126236102319507445051165919162131857150053562", value: 0.9009688679024191 },
  TWO_SIN_PI_14: { id: "TWO_SIN_PI_14", area: "02_heptagonal", input: "N[2 Sin[Pi/14], 60]", digits: "0.445041867912628808577805128993589518932711137529089910623974", value: 0.4450418679126288 },
  COS_2PI_7: { id: "COS_2PI_7", area: "02_heptagonal", input: "N[Cos[2 Pi/7], 60]", digits: "0.623489801858733530525004884004239810632274730896402105365549", value: 0.6234898018587335 },
  SP3_RAD: { id: "SP3_RAD", area: "03_tetra", input: "N[ArcCos[-1/3], 60]", digits: "1.91063323624901855632771420503151550848682939002001098191940", value: 1.9106332362490186 },
  SP3_DEG: { id: "SP3_DEG", area: "03_tetra", input: "N[ArcCos[-1/3]*180/Pi, 60]", digits: "109.471220634490691369245999339962435963006843100907948288171", value: 109.47122063449069 },
  TETRA_HALF_DEG: { id: "TETRA_HALF_DEG", area: "03_tetra", input: "N[ArcCos[1/Sqrt[3]]*180/Pi, 60]", digits: "54.7356103172453456846229996699812179815034215504539741440856", value: 54.735610317245346 },
  SQRT_8_9: { id: "SQRT_8_9", area: "03_tetra", input: "N[Sqrt[8/9], 60]", digits: "0.942809041582063365867792482806465385713114583584632048784453", value: 0.9428090415820634 },
  PACK_FCC: { id: "PACK_FCC", area: "03_tetra", input: "N[Pi/(3 Sqrt[2]), 60]", digits: "0.740480489693061041169313498343448949769103614895948370514233", value: 0.740480489693061 },
  PACK_HEX2: { id: "PACK_HEX2", area: "03_tetra", input: "N[Pi/(2 Sqrt[3]), 60]", digits: "0.906899682117108925297039128821077866142033124046370287784942", value: 0.9068996821171089 },
  PACK_E8: { id: "PACK_E8", area: "03_tetra", input: "N[Pi^4/384, 60]", digits: "0.253669507901048013636563366376836227212832254355951618988198", value: 0.25366950790104803 },
  F_PLANCK: { id: "F_PLANCK", area: "04_em", input: "N[299792458/(1.616255*10^-35), 60]", digits: "1.85486e43", value: 1.85486e+43 },
  EM_PHI_OCT: { id: "EM_PHI_OCT", area: "04_em", input: "N[Log[10^20/10^-12]/Log[GoldenRatio], 60]", digits: "153.119102937013311083462072076055581130099295454983427011334", value: 153.1191029370133 },
  VISIBLE_PEAK_HZ: { id: "VISIBLE_PEAK_HZ", area: "04_em", input: "N[299792458/(555*10^-9), 60]", digits: "5.40166590990990990990990990990990990990990990990990990990991e14", value: 540166590990990.94 },
  PHI_OCT_144_TO_PLANCK: { id: "PHI_OCT_144_TO_PLANCK", area: "04_em", input: "N[Log[(299792458/(1.616255*10^-35))/144]/Log[GoldenRatio], 60]", digits: "196.71", value: 196.71 },
  PHI_OCT_COSMIC: { id: "PHI_OCT_COSMIC", area: "04_em", input: "N[Log[1.372506807*10^26/(1.616255*10^-35)]/Log[GoldenRatio], 60]", digits: "291.544", value: 291.544 },
  BASE2_COSMIC: { id: "BASE2_COSMIC", area: "04_em", input: "N[Log[1.372506807*10^26/(1.616255*10^-35)]/Log[2], 60]", digits: "202.402", value: 202.402 },
  EFOLDS_COSMIC: { id: "EFOLDS_COSMIC", area: "04_em", input: "N[Log[1.372506807*10^26/(1.616255*10^-35)], 60]", digits: "140.294", value: 140.294 },
  DECADES_COSMIC: { id: "DECADES_COSMIC", area: "04_em", input: "N[Log[10, 1.372506807*10^26/(1.616255*10^-35)], 60]", digits: "60.929", value: 60.929 },
  PLANCK_LEN_M: { id: "PLANCK_LEN_M", area: "05_planck", input: "N[1.616255*10^-35, 60]", digits: "1.61626e-35", value: 1.61626e-35 },
  PLANCK_MASS_KG: { id: "PLANCK_MASS_KG", area: "05_planck", input: "N[2.176434*10^-8, 60]", digits: "2.17643e-8", value: 2.17643e-08 },
  PLANCK_TIME_S: { id: "PLANCK_TIME_S", area: "05_planck", input: "N[5.391247*10^-44, 60]", digits: "5.39125e-44", value: 5.39125e-44 },
  PLANCK_TEMP_K: { id: "PLANCK_TEMP_K", area: "05_planck", input: "N[1.416784*10^32, 60]", digits: "1.41678e32", value: 1.41678e+32 },
  HUBBLE_RADIUS_M: { id: "HUBBLE_RADIUS_M", area: "05_planck", input: "N[299792458/(67.4*1000/(3.0857*10^22)), 60]", digits: "1.37251e26", value: 1.37251e+26 },
  HUBBLE_FREQ_HZ: { id: "HUBBLE_FREQ_HZ", area: "05_planck", input: "N[299792458/(299792458/(67.4*1000/(3.0857*10^22))), 60]", digits: "2.18427e-18", value: 2.1842700000000004e-18 },
  EXP_NEG_INV_PHI: { id: "EXP_NEG_INV_PHI", area: "06_thermo", input: "N[Exp[-1/GoldenRatio], 60]", digits: "0.539003082724044620961937898364676370356118506844102179220842", value: 0.5390030827240446 },
  INV_PHI_H_STAR: { id: "INV_PHI_H_STAR", area: "06_thermo", input: "N[1/GoldenRatio, 60]", digits: "0.618033988749894848204586834365638117720309179805762862135449", value: 0.6180339887498949 },
  EXP_NEG_PHI: { id: "EXP_NEG_PHI", area: "06_thermo", input: "N[Exp[-GoldenRatio], 60]", digits: "0.198288152862206232267888956604864670842084892501297165274262", value: 0.19828815286220625 },
  PHI_BITS: { id: "PHI_BITS", area: "06_thermo", input: "N[Log[GoldenRatio]/Log[2], 60]", digits: "0.694241913630617301738790266898595223463567285227129715980990", value: 0.6942419136306173 },
  PARITY_PHI3: { id: "PARITY_PHI3", area: "06_thermo", input: "N[1 - 1/GoldenRatio^3, 60]", digits: "0.763932022500210303590826331268723764559381640388474275729103", value: 0.7639320225002103 },
  INV_PHI_CUBED: { id: "INV_PHI_CUBED", area: "06_thermo", input: "N[1/GoldenRatio^3, 60]", digits: "0.236067977499789696409173668731276235440618359611525724270897", value: 0.2360679774997897 },
  NERNST_RT_F_310K: { id: "NERNST_RT_F_310K", area: "07_bio", input: "N[8.314462618*310.15/96485.33212, 60]", digits: "0.0267267", value: 0.0267267 },
  GIBBS_ATP_DIMLESS: { id: "GIBBS_ATP_DIMLESS", area: "07_bio", input: "N[30500/(8.314462618*310.15), 60]", digits: "11.8275", value: 11.8275 },
  DNA_PITCH_RATIO: { id: "DNA_PITCH_RATIO", area: "07_bio", input: "N[34/21, 60]", digits: "1.61904761904761904761904761904761904761904761904761904761905", value: 1.619047619047619 },
  MT_OUTER_INNER: { id: "MT_OUTER_INNER", area: "07_bio", input: "N[25/15, 60]", digits: "1.66666666666666666666666666666666666666666666666666666666667", value: 1.6666666666666667 },
  F13_OVER_F12: { id: "F13_OVER_F12", area: "07_bio", input: "N[233/144, 60]", digits: "1.61805555555555555555555555555555555555555555555555555555556", value: 1.6180555555555556 },
  MEMBRANE_FIELD: { id: "MEMBRANE_FIELD", area: "07_bio", input: "N[70*10^-3/(4*10^-9), 60]", digits: "1.75000000000000000000000000000000000000000000000000000000000e7", value: 17500000.0 },
  ALPHA_INV: { id: "ALPHA_INV", area: "08_muon", input: "N[1/137.035999084, 60]", digits: "0.00729735256928", value: 0.00729735256928 },
  SCHWINGER_AE: { id: "SCHWINGER_AE", area: "08_muon", input: "N[1/(2 Pi)/137.035999084, 60]", digits: "0.00116140973289", value: 0.00116140973289 },
  PHI_POW_11_0795: { id: "PHI_POW_11_0795", area: "08_muon", input: "N[GoldenRatio^11.0795, 60]", digits: "206.766", value: 206.766 },
  MMU_ME: { id: "MMU_ME", area: "08_muon", input: "N[105.6583755/0.51099895069, 60]", digits: "206.768", value: 206.768 },
  MMU_ME_SQ: { id: "MMU_ME_SQ", area: "08_muon", input: "N[(105.6583755/0.51099895069)^2, 60]", digits: "42753.1", value: 42753.1 },
  AMU_BMW: { id: "AMU_BMW", area: "08_muon", input: "N[116592061*10^-11, 30]", digits: "0.00116592061000000000000000000000", value: 0.00116592061 },
  DELTA_AMU: { id: "DELTA_AMU", area: "08_muon", input: "N[251*10^-11, 30]", digits: "2.51000000000000000000000000000e-9", value: 2.51e-09 },
  FIB_7: { id: "FIB_7", area: "09_fib", input: "Fibonacci[7]", digits: "13", value: 13.0 },
  FIB_10: { id: "FIB_10", area: "09_fib", input: "Fibonacci[10]", digits: "55", value: 55.0 },
  FIB_13: { id: "FIB_13", area: "09_fib", input: "Fibonacci[13]", digits: "233", value: 233.0 },
  FIB_17: { id: "FIB_17", area: "09_fib", input: "Fibonacci[17]", digits: "1597", value: 1597.0 },
  FIB_22: { id: "FIB_22", area: "09_fib", input: "Fibonacci[22]", digits: "17711", value: 17711.0 },
  LUCAS_7: { id: "LUCAS_7", area: "09_fib", input: "LucasL[7]", digits: "29", value: 29.0 },
  RATIO_F12_F11: { id: "RATIO_F12_F11", area: "09_fib", input: "N[144/89, 60]", digits: "1.61797752808988764044943820224719101123595505617977528089888", value: 1.6179775280898876 },
  GOLDEN_ANGLE_DEG: { id: "GOLDEN_ANGLE_DEG", area: "10_phyllo", input: "N[360/GoldenRatio^2, 60]", digits: "137.507764050037854646348739628370277620688695269925369631238", value: 137.50776405003785 },
  GOLDEN_ANGLE_COMP: { id: "GOLDEN_ANGLE_COMP", area: "10_phyllo", input: "N[360*(1 - 1/GoldenRatio), 60]", digits: "137.507764050037854646348739628370277620688695269925369631238", value: 137.50776405003785 },
  SILVER_ANGLE_DEG: { id: "SILVER_ANGLE_DEG", area: "10_phyllo", input: "N[360/(1+Sqrt[2])^2, 60]", digits: "61.7662350913715648627841185690173834298362497285973873127906", value: 61.76623509137156 },
  GOLDEN_ANGLE_RAD: { id: "GOLDEN_ANGLE_RAD", area: "10_phyllo", input: "N[2 Pi/GoldenRatio^2, 60]", digits: "2.39996322972865332223155550663361385312499901105811504293511", value: 2.3999632297286535 },
  GOLDEN_ANGLE_RAD_ALT: { id: "GOLDEN_ANGLE_RAD_ALT", area: "10_phyllo", input: "N[Pi (3 - Sqrt[5]), 60]", digits: "2.39996322972865332223155550663361385312499901105811504293511", value: 2.3999632297286535 },
  TDESIGN_LB_9: { id: "TDESIGN_LB_9", area: "11_super", input: "(9+1)(9+3)/4", digits: "30", value: 30.0 },
  TDESIGN_LB_13: { id: "TDESIGN_LB_13", area: "11_super", input: "(13+1)(13+3)/4", digits: "56", value: 56.0 },
  TDESIGN_LB_21: { id: "TDESIGN_LB_21", area: "11_super", input: "(21+1)(21+3)/4", digits: "132", value: 132.0 },
  TDESIGN_LB_55: { id: "TDESIGN_LB_55", area: "11_super", input: "(55+1)(55+3)/4", digits: "812", value: 812.0 },
  PHI_INV_SUM_9: { id: "PHI_INV_SUM_9", area: "11_super", input: "N[Sum[1/GoldenRatio^k, {k,0,8}], 60]", digits: "2.58359213500126182154495798761234258735628984233084565437462", value: 2.5835921350012616 },
  PHI_DECAY_SUM_9: { id: "PHI_DECAY_SUM_9", area: "11_super", input: "N[Sum[2/GoldenRatio^k, {k,1,8}], 60]", digits: "3.16718427000252364308991597522468517471257968466169130874923", value: 3.1671842700025237 },
  PHI_INV_SUM_INF: { id: "PHI_INV_SUM_INF", area: "11_super", input: "N[Sum[1/GoldenRatio^k, {k,0,Infinity}], 60]", digits: "2.61803398874989484820458683436563811772030917980576286213545", value: 2.618033988749895 },
  SIN_2PI_3: { id: "SIN_2PI_3", area: "12_triadic", input: "N[Sin[2 Pi/3], 60]", digits: "0.866025403784438646763723170752936183471402626905190314027903", value: 0.8660254037844386 },
  COS_2PI_3: { id: "COS_2PI_3", area: "12_triadic", input: "N[Cos[2 Pi/3], 60]", digits: "-0.500000000000000000000000000000000000000000000000000000000000", value: -0.5 },
  TRIADIC_SUM: { id: "TRIADIC_SUM", area: "12_triadic", input: "Sum[Exp[I 2 Pi k/3], {k,0,2}]", digits: "0 (closure)", value: 0 },
  LOG3_LOGPHI: { id: "LOG3_LOGPHI", area: "12_triadic", input: "N[Log[3]/Log[GoldenRatio], 60]", digits: "2.28301182858927940046602460418564540537745329721948342000822", value: 2.2830118285892795 },
  KURAMOTO_THRESH: { id: "KURAMOTO_THRESH", area: "12_triadic", input: "N[1/(1-Cos[2 Pi/3]), 60]", digits: "0.666666666666666666666666666666666666666666666666666666666667", value: 0.6666666666666666 },
  TRIADIC_DENSITY: { id: "TRIADIC_DENSITY", area: "12_triadic", input: "N[3/(2 Pi), 60]", digits: "0.477464829275686007306651290117543086103378937221369346243002", value: 0.477464829275686 },
  ONE_MINUS_INVPHI_4: { id: "ONE_MINUS_INVPHI_4", area: "13_residual", input: "N[(1 - 1/GoldenRatio)^4, 60]", digits: "0.0212862362522081877036764783215995278735072240789798951555789", value: 0.02128623625220819 },
  INV_PHI_6: { id: "INV_PHI_6", area: "13_residual", input: "N[1/GoldenRatio^6, 60]", digits: "0.0557280900008412143633053250748950582375265615538971029164110", value: 0.05572809000084122 },
  V10_FLOOR: { id: "V10_FLOOR", area: "13_residual", input: "N[0.05625982094858675, 60]", digits: "0.05625982094858675", value: 0.05625982094858675 },
  INV_FIB_13: { id: "INV_FIB_13", area: "13_residual", input: "N[1/233, 60]", digits: "0.00429184549356223175965665236051502145922746781115879828326180", value: 0.004291845493562232 },
  INV_PHI_9: { id: "INV_PHI_9", area: "13_residual", input: "N[1/GoldenRatio^9, 60]", digits: "0.0131556174964248389559523684316960024905121133959373126052532", value: 0.013155617496424838 },
  R_528_396: { id: "R_528_396", area: "14_solfeggio", input: "528/396", digits: "1.3333333333333333333333333333333333333333333333333333333333333333", value: 1.3333333333333333 },
  R_528_417: { id: "R_528_417", area: "14_solfeggio", input: "N[528/417, 30]", digits: "1.26618705035971223021582733813", value: 1.2661870503597121 },
  R_639_396: { id: "R_639_396", area: "14_solfeggio", input: "N[639/396, 30]", digits: "1.61363636363636363636363636364", value: 1.6136363636363635 },
  R_741_528: { id: "R_741_528", area: "14_solfeggio", input: "N[741/528, 30]", digits: "1.40340909090909090909090909091", value: 1.4034090909090908 },
  R_852_639: { id: "R_852_639", area: "14_solfeggio", input: "N[852/639, 30]", digits: "1.33333333333333333333333333333", value: 1.3333333333333333 },
  TET_FIFTH: { id: "TET_FIFTH", area: "14_solfeggio", input: "N[2^(7/12), 60]", digits: "1.49830707687668149879928073202979579630215155373174687644102", value: 1.4983070768766815 },
  JUST_FIFTH: { id: "JUST_FIFTH", area: "14_solfeggio", input: "N[3/2, 60]", digits: "1.50000000000000000000000000000000000000000000000000000000000", value: 1.5 },
  BEKENSTEIN_BITS: { id: "BEKENSTEIN_BITS", area: "15_holo", input: "N[(4 Pi (1.372506807*10^26)^2 / 4) / (1.616255*10^-35)^2, 30]", digits: "2.26547e122", value: 2.26547e+122 },
  BEKEN_LOG2: { id: "BEKEN_LOG2", area: "15_holo", input: "N[Log[2, (4 Pi (1.372506807*10^26)^2 / 4) / (1.616255*10^-35)^2], 30]", digits: "406.455", value: 406.455 },
  BEKEN_LOG_PHI: { id: "BEKEN_LOG_PHI", area: "15_holo", input: "N[Log[GoldenRatio, (4 Pi (1.372506807*10^26)^2 / 4) / (1.616255*10^-35)^2], 30]", digits: "585.466", value: 585.466 },
  PROTON_PLANCK_RATIO: { id: "PROTON_PLANCK_RATIO", area: "15_holo", input: "N[8.4*10^-16/(1.616255*10^-35), 30]", digits: "5.1972e19", value: 5.1972e+19 },
  PROTON_PLANCK_PHIOCT: { id: "PROTON_PLANCK_PHIOCT", area: "15_holo", input: "N[Log[GoldenRatio, 8.4*10^-16/(1.616255*10^-35)], 30]", digits: "94.3394", value: 94.3394 },
};

/** Look up a verified constant by id; throws if unknown. */
export function verified(id: string): number {
  const e = WOLFRAM_VERIFIED_BANK[id];
  if (!e) throw new Error(`[WolframVerifiedBank] unknown id: ${id}`);
  return e.value;
}

/** All entries in a given area (e.g. "07_bio"). */
export function entriesIn(area: string): WolframVerifiedEntry[] {
  return Object.values(WOLFRAM_VERIFIED_BANK).filter((e) => e.area === area);
}

/** Self-check: every entry's value must round-trip to the digit string. */
(function selfCheck() {
  for (const [id, e] of Object.entries(WOLFRAM_VERIFIED_BANK)) {
    if (!Number.isFinite(e.value)) {
      // eslint-disable-next-line no-console
      console.error(`[WolframVerifiedBank] CORRUPT ${id}: value not finite`, e);
    }
  }
})();
