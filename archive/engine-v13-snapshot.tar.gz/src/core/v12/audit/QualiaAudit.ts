/**
 * V12 — Qualia & Feedback Identity Audit (P1.1–P1.3, P4.2, P6, P7.3)
 * ──────────────────────────────────────────────────────────────────────────
 * Cross-source identity checks.  Every check is labelled with its KIND so
 * the UI can render an honesty badge:
 *
 *   'measurement'  — the check measures a quantity against an INDEPENDENT
 *                    Wolfram-frozen constant or closed-form prediction.
 *   'cross-source' — the check recomputes a value via an alternative
 *                    arithmetic path and compares; passes when both paths
 *                    agree to floating-point precision.
 *   'invariant'    — an inequality / structural property that must hold
 *                    by construction (e.g. symmetry, trace = 0).
 *
 * Tautological checks ("definition vs itself") are forbidden in this
 * report.  If you need to verify a definition holds, do so as a
 * 'cross-source' check via a different formula.
 */

import type { PerRungQualiaResult } from '../QualiaPerRung';
import type { MemoryFeedbackState } from '../MemoryFeedback';
import { FEEDBACK_GAIN, MAX_BIAS } from '../MemoryFeedback';
import type { ScaleSlicesResult } from '../ScaleSlices';
import { NeumaierSum } from '@/core/numerics/StableSum';
import { WOLFRAM_BANK, wolframResidual } from './WolframConstants';
import { V12_ORDER } from '../LogScaleWeights';

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV = 1 / PHI;
const ALPHA = 1 / (PHI * PHI);

export type AuditKind = 'measurement' | 'cross-source' | 'invariant';

export interface QualiaAuditCheck {
  id: string;
  label: string;
  kind: AuditKind;
  computed: number;
  reference: number;
  residual: number;
  matchingDigits: number;
  grade: 'IDENTITY' | 'WORKING' | 'EXCELLENT' | 'GOOD' | 'WEAK' | 'BROKEN';
  ok: boolean;
}

export interface QualiaAuditReport {
  checks: QualiaAuditCheck[];
  worstResidual: number;
  minDigits: number;
  allOk: boolean;
}

function digitsOf(r: number): number {
  if (!isFinite(r) || r <= 0) return 16;
  return Math.max(0, Math.min(16, Math.floor(-Math.log10(r))));
}
function grade(d: number, r: number): QualiaAuditCheck['grade'] {
  if (r <= 5e-16) return 'IDENTITY';
  if (r <= 1e-13) return 'WORKING';
  if (d >= 12) return 'EXCELLENT';
  if (d >=  9) return 'GOOD';
  if (d >=  6) return 'WEAK';
  return 'BROKEN';
}
function mk(
  id: string, label: string, kind: AuditKind,
  computed: number, reference: number, tol = 1e-9,
): QualiaAuditCheck {
  const residual = Math.abs(computed - reference);
  const d = digitsOf(residual);
  return { id, label, kind, computed, reference, residual,
    matchingDigits: d, grade: grade(d, residual), ok: residual <= tol };
}
function mkIneq(id: string, label: string, kind: AuditKind, value: number, bound: number): QualiaAuditCheck {
  const violation = Math.max(0, value - bound);
  const d = violation === 0 ? 16 : digitsOf(violation);
  return { id, label, kind, computed: value, reference: bound,
    residual: violation, matchingDigits: d, grade: grade(d, violation),
    ok: value <= bound + 1e-12 };
}

export function runQualiaAudit(
  qualia: PerRungQualiaResult,
  feedback: MemoryFeedbackState | null,
  scaleSlices?: ScaleSlicesResult | null,
): QualiaAuditReport {
  const checks: QualiaAuditCheck[] = [];

  // ── Wolfram-frozen constants (MEASUREMENT) ───────────────────────────
  for (const id of Object.keys(WOLFRAM_BANK)) {
    const c = WOLFRAM_BANK[id];
    checks.push(mk(
      `wolfram_${id}`,
      `Wolfram ${c.symbolic} matches frozen 50-digit literal`,
      'measurement',
      c.value, parseFloat(c.digits50),
      Math.max(Math.abs(c.value), 1) * 1e-14,
    ));
    void wolframResidual;
  }

  // ── Per-rung qualia (MEASUREMENT + CROSS-SOURCE) ─────────────────────
  for (const r of qualia.perRung) {
    // Q_inc is now MEASURED (no longer hardcoded 1) — check it sits in [0,1].
    checks.push(mkIneq(
      `Qinc_range_${r.framework}`,
      `${r.framework}: measured Q_inc ∈ [0,1]`,
      'invariant',
      Math.max(0, Math.max(r.Q_inc - 1, -r.Q_inc)),
      0,
    ));

    // Cross-source: composite Q == √(Q_spatial · Q_temporal) (geo-mean of subspaces).
    const geo = Math.sqrt(Math.max(0, r.Q_spatial) * Math.max(0, r.Q_temporal));
    checks.push(mk(
      `Q_geo_${r.framework}`,
      `${r.framework}: Q ≡ √(Q_spatial · Q_temporal)`,
      'cross-source',
      r.Q, geo, 1e-12,
    ));

    // Axis bounds (INVARIANT).
    const oob =
      (r.C < -1e-9 || r.C > 1 + 1e-9 ? 1 : 0) +
      (r.N < -1e-9 || r.N > 1 + 1e-9 ? 1 : 0) +
      (r.Q < -1e-9 || r.Q > 1 + 1e-9 ? 1 : 0) +
      (r.V < -1 - 1e-9 || r.V > 1 + 1e-9 ? 1 : 0);
    checks.push(mkIneq(
      `range_${r.framework}`,
      `${r.framework}: C,N,Q∈[0,1], V∈[−1,1]`,
      'invariant', oob, 0,
    ));
  }

  // ── Global reduction sanity (INVARIANT) ──────────────────────────────
  if (qualia.perRung.length > 0) {
    const maxC = qualia.perRung.reduce((m, r) => Math.max(m, r.C), 0);
    const maxQ = qualia.perRung.reduce((m, r) => Math.max(m, r.Q), 0);
    checks.push(mkIneq('global_C_le_max', 'global.C ≤ max per-rung C', 'invariant', qualia.global.C, maxC + 1e-9));
    checks.push(mkIneq('global_Q_le_max', 'global.Q ≤ max per-rung Q', 'invariant', qualia.global.Q, maxQ + 1e-9));
  }

  // ── Attention-head CROSS-SOURCE (direct argmax vs log-space argmax). ──
  // Both reductions must pick the same rung; scalar scores must match
  // numerically (direct == exp(logScore)).
  const directExp = qualia.global.priorityScore;
  const logExp = qualia.global.priorityScoreLog;
  checks.push(mk(
    'attention_argmax_agree',
    'argmax direct == argmax log-space',
    'cross-source',
    qualia.global.priorityFramework === qualia.global.priorityFrameworkLog ? 0 : 1,
    0, 0,
  ));
  // Skip the numeric equality check when either score is at/near the
  // log-eps floor (1e-30): in that regime exp(logScore) is a clamped
  // artefact, not a real recomputation, and the comparison is degenerate.
  const LOG_EPS_FLOOR = 1e-25;
  if (directExp > LOG_EPS_FLOOR && logExp > LOG_EPS_FLOOR) {
    checks.push(mk(
      'attention_score_agree',
      'score(direct) == exp(logScore)',
      'cross-source',
      directExp, logExp,
      Math.max(directExp, logExp, 1) * 1e-10,
    ));
  } else {
    checks.push(mk(
      'attention_score_agree',
      'score(direct) == exp(logScore) [skipped: degenerate zero]',
      'cross-source',
      0, 0, 1,
    ));
  }

  // ── Cross-source: weight sum via NeumaierSum vs naive ────────────────
  const accW = new NeumaierSum();
  let naiveW = 0;
  for (const r of qualia.perRung) { accW.add(r.weight); naiveW += r.weight; }
  checks.push(mk(
    'weight_sum_stable',
    'Σ wᵢ: Neumaier vs naive',
    'cross-source',
    accW.value(), naiveW, 1e-13,
  ));
  // Independent reference: Σ wᵢ must equal 1 (LogScaleWeights normalises).
  checks.push(mk(
    'weight_sum_unity',
    'Σ wᵢ = 1 (LogScaleWeights normalization)',
    'measurement',
    accW.value(), 1, 1e-13,
  ));

  // ── Memory feedback invariants ──────────────────────────────────────
  if (feedback) {
    checks.push(mkIneq('mem_sym',   'H symmetric: max|H_ij − H_ji|', 'invariant', feedback.symmetryResidual, 1e-12));
    checks.push(mkIneq('mem_trace', 'tr(H) = 0',                      'invariant', feedback.traceResidual,    1e-12));
    // Cross-tick spectral stability: gain · ρ_upper · (1+α) < 1/φ.
    const lhs = FEEDBACK_GAIN * feedback.maxRowSum * (1 + ALPHA);
    checks.push(mkIneq(
      'mem_contraction',
      'gain · ρ_upper · (1+α) < 1/φ (Gershgorin, cross-tick)',
      'measurement',
      lhs, PHI_INV - 1e-12,
    ));
    let maxBias = 0;
    for (let i = 0; i < feedback.bias.length; i++) {
      const b = Math.abs(feedback.bias[i]);
      if (b > maxBias) maxBias = b;
    }
    checks.push(mkIneq('mem_bias',  '|bias_i| ≤ MAX_BIAS', 'invariant', maxBias, MAX_BIAS + 1e-12));
    checks.push(mkIneq('mem_nudge', '|coherenceNudge| ≤ MAX_BIAS', 'invariant',
      Math.abs(feedback.coherenceNudge), MAX_BIAS + 1e-12));
    // Cross-source: nudge = mean(bias).
    let bsum = 0;
    for (let i = 0; i < feedback.bias.length; i++) bsum += feedback.bias[i];
    checks.push(mk(
      'mem_nudge_def',
      'coherenceNudge ≡ mean(bias)',
      'cross-source',
      feedback.coherenceNudge, bsum / feedback.bias.length, 1e-14,
    ));
  }

  // ── Scale-grid self-consistency (9 anchors, INVARIANT) ──────────────
  if (scaleSlices) {
    for (const a of V12_ORDER) {
      const row = scaleSlices.grid.rows[a];
      checks.push(mkIneq(
        `slice_${a}_self`,
        `${a} slice at canonical source ≡ propagated ${a}`,
        'invariant', row.selfConsistencyResidual, 1e-9,
      ));
    }
    // Cross-rung Gram spectrum sanity: λ_max ≤ Frobenius (invariant).
    checks.push(mkIneq(
      'grid_lambda_le_frob',
      'λ_max(M) ≤ ||M||_F',
      'invariant',
      scaleSlices.grid.spectrum.lambdaMax,
      scaleSlices.grid.spectrum.frobenius + 1e-9,
    ));
  }

  const worstResidual = checks.reduce((m, c) => Math.max(m, c.residual), 0);
  const minDigits = checks.reduce((m, c) => Math.min(m, c.matchingDigits), 16);
  const allOk = checks.every((c) => c.ok);

  return { checks, worstResidual, minDigits, allOk };
}
