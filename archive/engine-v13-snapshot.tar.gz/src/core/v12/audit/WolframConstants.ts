/**
 * V12 — Wolfram-Frozen Constants (P6)
 * ────────────────────────────────────────────────────────────────────────
 * Symbolic constants used by the qualia / audit pipeline. Every literal is
 * traceable to a Wolfram query and reproduces to >= 16 digits in IEEE-754.
 *
 * Add new constants here ONLY with the originating query in the provenance
 * field so an external verifier can re-check them out-of-band.
 */

export interface WolframConstant {
  readonly id: string;
  readonly symbolic: string;
  readonly query: string;
  /** 50-digit literal as returned by Wolfram (truncated). */
  readonly digits50: string;
  readonly value: number;
}

/** φ = (1+√5)/2 — 50 digits. */
export const PHI_50 = '1.6180339887498948482045868343656381177203091798058';
/** 1/√5 — Hurwitz bound for golden-rotation irrationality. */
export const HURWITZ_50 = '0.4472135954999579392818347337462552470881236719224';
/** 1/φ² — φ-attractor fraction, also Ω_c. */
export const INV_PHI_SQ_50 = '0.3819660112501051517954131656343618822796908201942';
/** φ/(φ−1) = φ² — sum of φ-decay series Σ φ^(−k), k≥1. */
export const PHI_SQ_50 = '2.6180339887498948482045868343656381177203091798058';
/** Cubic-root threshold: 1 − 1/√5 — predicted |⟨v, φ-shift(v)⟩| attractor. */
export const PHI_COS_ATTRACTOR_50 = '0.5527864045000420607181652662537447529118763280776';

export const WOLFRAM_BANK: Record<string, WolframConstant> = {
  PHI: {
    id: 'PHI',
    symbolic: 'φ = (1+√5)/2',
    query: 'N[GoldenRatio, 50]',
    digits50: PHI_50,
    value: (1 + Math.sqrt(5)) / 2,
  },
  HURWITZ: {
    id: 'HURWITZ',
    symbolic: '1/√5',
    query: 'N[1/Sqrt[5], 50]',
    digits50: HURWITZ_50,
    value: 1 / Math.sqrt(5),
  },
  INV_PHI_SQ: {
    id: 'INV_PHI_SQ',
    symbolic: '1/φ²',
    query: 'N[1/GoldenRatio^2, 50]',
    digits50: INV_PHI_SQ_50,
    value: 1 / ((1 + Math.sqrt(5)) / 2) ** 2,
  },
  PHI_SQ: {
    id: 'PHI_SQ',
    symbolic: 'φ² = φ + 1',
    query: 'N[GoldenRatio^2, 50]',
    digits50: PHI_SQ_50,
    value: ((1 + Math.sqrt(5)) / 2) ** 2,
  },
  PHI_COS_ATTRACTOR: {
    id: 'PHI_COS_ATTRACTOR',
    symbolic: '1 − 1/√5',
    query: 'N[1 - 1/Sqrt[5], 50]',
    digits50: PHI_COS_ATTRACTOR_50,
    value: 1 - 1 / Math.sqrt(5),
  },
};

// ──────────────────────────────────────────────────────────────────────────
// Phase 1, Wave 1 — Extended V10 bank (96 Wolfram-verified identities).
// Re-exported from WolframVerifiedBank.ts so consumers can read from one
// surface. New code should prefer the extended bank for any constant outside
// the original 5-entry V12 set.
// ──────────────────────────────────────────────────────────────────────────
export {
  WOLFRAM_VERIFIED_BANK,
  verified as verifiedExt,
  entriesIn as verifiedEntriesIn,
  type WolframVerifiedEntry,
} from './WolframVerifiedBank';

// ──────────────────────────────────────────────────────────────────────────
// Phase 1, Wave 2 — 89 forensic-audit constants across F1..F9, Lyapunov,
// residuals, and audit cross-checks. mpmath @ 60 dps + Wolfram /v2/query
// cross-check. See scripts/wolfram_wave2.py and the materializer for the
// reproducible pipeline; raw results in docs/v12_migration/wolfram/wave2.jsonl.
// ──────────────────────────────────────────────────────────────────────────
export {
  WOLFRAM_BANK_WAVE2,
  type VerifiedConstantV2,
  type WolframBankWave2Key,
} from './WolframBankWave2';

/** Verify a JS literal matches the frozen Wolfram digits to >= 15 digits. */
export function wolframResidual(id: keyof typeof WOLFRAM_BANK): number {
  const c = WOLFRAM_BANK[id];
  const truth = parseFloat(c.digits50);
  return Math.abs(c.value - truth);
}
