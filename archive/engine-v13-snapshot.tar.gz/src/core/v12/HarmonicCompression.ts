/**
 * HarmonicCompression — Harmonic Compression Axiom (HCA).
 *
 * A subsystem preferentially evolves toward representations that minimize
 * redundancy and stabilization burden while preserving closure, memory
 * continuity, and predictive adequacy.
 *
 * Formal minimization objective (per-scale n):
 *
 *   Ψ_{t+1}^{(n)} = argmin_{Ψ ∈ A^{(n)}}
 *        [ α·D^{(n)}(Ψ)   // dissipation
 *        + β·B^{(n)}(Ψ)   // stabilization burden
 *        + γ·R^{(n)}(Ψ)   // redundancy
 *        − δ·C^{(n)}(Ψ)   // closure / coherence
 *        − ε·M^{(n)}(Ψ) ] // memory continuity
 *
 * This module is a *pure* scorer + admission gate. It does NOT mutate engine
 * state and is composable with MasterUpdate / TriadicValue. It is opt-in:
 * callers may score a candidate Ψ against Ψ_t and accept the candidate only
 * when the HCA cost strictly decreases (or ties within ε).
 *
 * Sign convention: lower J is better. Closure and memory ENTER NEGATIVELY.
 *
 * Determinism: identical inputs ⇒ identical J bit-for-bit.
 */

import { toroidalCoherence, type ToroidalMemory } from '@/core/field/Torus';
import { PHI } from '@/core/constants/WolframVerified';

export interface HCAWeights {
  alpha: number;   // dissipation
  beta: number;    // burden
  gamma: number;   // redundancy
  delta: number;   // closure (reward → subtracted)
  epsilon: number; // memory continuity (reward → subtracted)
}

/**
 * φ-tempered defaults: closure and memory carry φ-weight so a coherent,
 * memory-consistent representation is always preferred over a leaner but
 * disconnected one. Redundancy penalized at 1/φ (soft), dissipation at 1.
 */
export const DEFAULT_HCA_WEIGHTS: HCAWeights = Object.freeze({
  alpha: 1.0,
  beta:  1.0,
  gamma: 1 / PHI,
  delta: PHI,
  epsilon: PHI,
});

export interface HCATerms {
  D: number; // dissipation      (≥ 0)
  B: number; // burden           (≥ 0)
  R: number; // redundancy       (≥ 0)
  C: number; // closure          (≥ 0, higher is better)
  M: number; // memory continuity(≥ 0, higher is better)
}

export interface HCAScore {
  terms: HCATerms;
  J: number;                 // total cost (lower = better)
  weightsUsed: HCAWeights;
}

const HCA_EPS = 1e-12;

/**
 * Score a candidate Ψ against its predecessor Ψ_prev and (optional) toroidal
 * memory ring. All terms are pure functions of the inputs.
 *
 * D — dissipation: ‖Ψ − Ψ_prev‖² / N  (energy spent moving the state)
 * B — burden:      variance of Ψ / N  (how "loud" the representation is)
 * R — redundancy:  mean absolute lag-1 autocorrelation of Ψ (self-similar bloat)
 * C — closure:     toroidalCoherence(Ψ, ring), mapped to [0,1]; 0 if no ring
 * M — memory:      cosine similarity(Ψ, Ψ_prev) mapped to [0,1]
 */
export function scoreHCA(
  psi: Float64Array,
  psiPrev: Float64Array,
  ring: ToroidalMemory | null,
  weights: Partial<HCAWeights> = {},
): HCAScore {
  if (psi.length !== psiPrev.length) {
    throw new Error('scoreHCA: length mismatch');
  }
  const w: HCAWeights = { ...DEFAULT_HCA_WEIGHTS, ...weights };
  const n = psi.length;
  if (n === 0) {
    return { terms: { D: 0, B: 0, R: 0, C: 0, M: 0 }, J: 0, weightsUsed: w };
  }

  // Dissipation, burden (variance), and dot products in a single pass.
  let dSq = 0;
  let sum = 0, sumSq = 0;
  let dotPP = 0, dotPrevPrev = 0, dotCross = 0;
  let lagNum = 0, lagDen = 0;
  for (let i = 0; i < n; i++) {
    const a = psi[i];
    const b = psiPrev[i];
    const d = a - b;
    dSq += d * d;
    sum += a;
    sumSq += a * a;
    dotPP += a * a;
    dotPrevPrev += b * b;
    dotCross += a * b;
    if (i > 0) {
      lagNum += a * psi[i - 1];
      lagDen += psi[i - 1] * psi[i - 1];
    }
  }
  const invN = 1 / n;
  const mean = sum * invN;
  const variance = Math.max(0, sumSq * invN - mean * mean);
  const D = dSq * invN;
  const B = variance;
  const R = lagDen > HCA_EPS ? Math.abs(lagNum) / (lagDen + HCA_EPS) : 0;
  const rawC = ring ? toroidalCoherence(psi, ring) : 0;
  const C = clamp01(0.5 * (rawC + 1));
  const cosDen = Math.sqrt(dotPP * dotPrevPrev);
  const M = cosDen > HCA_EPS ? clamp01(0.5 * (dotCross / cosDen + 1)) : 0;

  const J = w.alpha * D + w.beta * B + w.gamma * R - w.delta * C - w.epsilon * M;
  return { terms: { D, B, R, C, M }, J, weightsUsed: w };
}

/**
 * Admission gate: accept the candidate iff J(candidate) ≤ J(baseline) + ε.
 * "Ties count as improvements" so the system can move sideways along a
 * compression plateau (harmless drift) without inflating cost.
 */
export function admitsCompression(
  candidate: HCAScore,
  baseline: HCAScore,
  eps = 1e-9,
): boolean {
  return candidate.J <= baseline.J + eps;
}

function clamp01(x: number): number {
  if (!isFinite(x)) return 0;
  return x < 0 ? 0 : x > 1 ? 1 : x;
}
