/**
 * MasterUpdate — canonical Ψ_{t+1} update law (RHUFT §10 master equation).
 *
 *   Ψ_{t+1} = α·Ψ_t
 *           + β·G_{φ,σ}(Ψ_t)     // golden-angle directional scan
 *           + γ·M(I_t)            // sensory projection
 *           + δ·H(M_t)            // memory re-entry
 *           + ε·C(Ψ_t)            // closure / toroidal coherence
 *           + ζ·S(Ψ̂_t, Ψ_t)     // self-reflection correction
 *
 * Weights are coherence-preserving:
 *   α is a free decay in [0,1]
 *   (β + γ + δ + ε + ζ) is normalized to 1 for the additive operators
 *
 * Determinism: identical inputs ⇒ identical Ψ_{t+1} bit-for-bit.
 * Pure — never mutates engine state; caller decides where to store output.
 *
 * This is the auditable unification of the previously-fragmented operators
 * (goldenScan, sensory projection, HebbianMatrix.recall, toroidalCoherence,
 * applyReflect). It does NOT replace them — it composes them behind a
 * single tunable weight vector so the whole update is one signature.
 */

import { goldenScan, toroidalCoherence, type ToroidalMemory } from '@/core/field/Torus';

export interface MasterWeights {
  alpha: number;   // persistence (decay)
  beta: number;    // golden scan
  gamma: number;   // sensory
  delta: number;   // memory
  epsilon: number; // closure / toroidal
  zeta: number;    // self-reflection
  /** σ passed to golden-scan blend (0 = identity, 1 = full rotation). */
  sigma: number;
}

export const DEFAULT_WEIGHTS: MasterWeights = Object.freeze({
  alpha: 0.55,
  beta:  0.15,
  gamma: 0.15,
  delta: 0.10,
  epsilon: 0.05,
  zeta: 0.05,
  sigma: 1 / 1.6180339887498949, // 1/φ
});

export interface MasterInputs {
  psi: Float64Array;                    // Ψ_t
  sensory: Float64Array | null;         // M(I_t) — pre-projected
  memoryRecall: Float64Array | null;    // H(M_t) — pre-recalled
  reflect: Float64Array | null;         // S(Ψ̂_t, Ψ_t) correction
  ring: ToroidalMemory | null;          // toroidal history for C(Ψ_t)
  weights?: Partial<MasterWeights>;
}

export interface MasterMetrics {
  toroidalC: number;      // coherence contribution
  scanNorm: number;       // ‖β·G(Ψ)‖₁ / N
  sensoryNorm: number;
  memoryNorm: number;
  reflectNorm: number;
  outNorm: number;        // ‖Ψ_{t+1}‖₂
  weightsUsed: MasterWeights;
}

/** Normalize additive weights to sum=1; α held separately. */
export function normalizeWeights(w: MasterWeights): MasterWeights {
  const sum = w.beta + w.gamma + w.delta + w.epsilon + w.zeta;
  if (sum <= 1e-12) return w;
  const k = 1 / sum;
  return {
    ...w,
    beta: w.beta * k,
    gamma: w.gamma * k,
    delta: w.delta * k,
    epsilon: w.epsilon * k,
    zeta: w.zeta * k,
  };
}

/**
 * Compute Ψ_{t+1} into `out`. All operator terms are optional — nulls are
 * treated as zero contribution and their weight is redistributed by
 * `normalizeWeights` before the composition.
 */
export function masterUpdate(inputs: MasterInputs, out: Float64Array): MasterMetrics {
  const n = inputs.psi.length;
  if (out.length !== n) throw new Error('masterUpdate: out length mismatch');

  const raw: MasterWeights = { ...DEFAULT_WEIGHTS, ...(inputs.weights ?? {}) };
  const w = normalizeWeights(raw);

  // Golden-angle scan Ψ_t → tmp.
  const scan = new Float64Array(n);
  goldenScan(inputs.psi, scan, w.sigma);

  // Toroidal coherence coefficient — modulates the ε term.
  const cCoef = inputs.ring ? Math.max(0, toroidalCoherence(inputs.psi, inputs.ring)) : 0;

  let scanNorm = 0, sensNorm = 0, memNorm = 0, refNorm = 0, outNorm = 0;

  for (let i = 0; i < n; i++) {
    const persist = w.alpha * inputs.psi[i];
    const gTerm   = w.beta  * scan[i];
    const mTerm   = w.gamma * (inputs.sensory ? inputs.sensory[i] : 0);
    const hTerm   = w.delta * (inputs.memoryRecall ? inputs.memoryRecall[i] : 0);
    const cTerm   = w.epsilon * cCoef * inputs.psi[i];
    const sTerm   = w.zeta  * (inputs.reflect ? inputs.reflect[i] : 0);

    const y = persist + gTerm + mTerm + hTerm + cTerm + sTerm;
    out[i] = y;

    scanNorm += Math.abs(gTerm);
    sensNorm += Math.abs(mTerm);
    memNorm  += Math.abs(hTerm);
    refNorm  += Math.abs(sTerm);
    outNorm  += y * y;
  }

  const invN = 1 / Math.max(1, n);
  return {
    toroidalC: cCoef,
    scanNorm: scanNorm * invN,
    sensoryNorm: sensNorm * invN,
    memoryNorm: memNorm * invN,
    reflectNorm: refNorm * invN,
    outNorm: Math.sqrt(outNorm),
    weightsUsed: w,
  };
}
