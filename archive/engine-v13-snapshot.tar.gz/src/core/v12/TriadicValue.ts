/**
 * TriadicValue — V = (Stability · Complexity) / Friction  (RHUFT structural law).
 *
 * Wolfram-verified closed forms (φ = golden ratio):
 *   S = C = 1/φ, F = 1/φ²   → V = 1            (STABLE)
 *   S = C = 1,   F = 1/φ    → V = φ ≈ 1.618    (GOLDEN)
 *   S = C = 1,   F = 1/φ²   → V = φ² ≈ 2.618   (REVERSIBLE ceiling)
 *
 * Log-domain dual: log V = log S + log C − log F (Friston free-energy form).
 *
 * Verdict ladder (with 1e-9 epsilon boundary tolerance):
 *   REVERSIBLE ≥ φ²   GOLDEN ≥ φ   STABLE ≥ 1   DEGRADING ≥ 1/φ   COLLAPSING < 1/φ
 */

import { PHI } from '@/core/constants/WolframVerified';

export type TriadicVerdict =
  | 'REVERSIBLE'
  | 'GOLDEN'
  | 'STABLE'
  | 'DEGRADING'
  | 'COLLAPSING';

export interface TriadicInput {
  /** Stability ∈ [0,1]. */
  S: number;
  /** Complexity ∈ [0,1]. */
  C: number;
  /** Friction ∈ [0,1]; floored at ε to avoid divide-by-zero. */
  F: number;
}

export interface TriadicOutput {
  V: number;
  logV: number;
  verdict: TriadicVerdict;
}

export const V_EPS = 1e-9;
export const V_FRICTION_FLOOR = 1e-6;

const PHI_INV = 1 / PHI;
const PHI_SQ = PHI * PHI;

function clamp01(x: number): number {
  if (!isFinite(x)) return 0;
  return x < 0 ? 0 : x > 1 ? 1 : x;
}

export function triadicValue(input: TriadicInput): TriadicOutput {
  const S = clamp01(input.S);
  const C = clamp01(input.C);
  const F = Math.max(V_FRICTION_FLOOR, clamp01(input.F));
  const V = (S * C) / F;
  const logV = Math.log(Math.max(V_EPS, S)) + Math.log(Math.max(V_EPS, C)) - Math.log(F);
  return { V, logV, verdict: verdictOf(V) };
}

export function verdictOf(V: number): TriadicVerdict {
  if (!isFinite(V)) return 'COLLAPSING';
  if (V >= PHI_SQ - V_EPS) return 'REVERSIBLE';
  if (V >= PHI - V_EPS) return 'GOLDEN';
  if (V >= 1 - V_EPS) return 'STABLE';
  if (V >= PHI_INV - V_EPS) return 'DEGRADING';
  return 'COLLAPSING';
}

/**
 * Learning-rate gate: returns true iff the candidate update would keep the
 * system at STABLE tier or above (V ≥ 1) OR strictly increase V.
 * Enforces the RHUFT axiom "Existence = Stabilized Distinction".
 */
export function admitsUpdate(before: TriadicInput, after: TriadicInput): boolean {
  const vAfter = triadicValue(after).V;
  if (vAfter >= 1 - V_EPS) return true;
  const vBefore = triadicValue(before).V;
  return vAfter > vBefore + V_EPS;
}
