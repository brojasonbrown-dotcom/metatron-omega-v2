/**
 * V12 — ScaleSlices (back-compat shim over ScaleGrid)
 * ────────────────────────────────────────────────────────────────────────
 * Original 3×9 anchor slice surface preserved for callers that only need
 * F4/F2/F7.  Internally delegates to computeScaleGrid (9×9) and projects.
 */

import type { MetatronInput } from '@/core/MetatronCore';
import { V12_ORDER, type V12Framework } from './LogScaleWeights';
import type { PropagatedChain } from './PropagateScaleOrder';
import { computeScaleGrid, CANONICAL_SOURCE, type ScaleGridResult } from './ScaleGrid';

export type AnchorId = 'F4' | 'F2' | 'F7';

export interface AnchorSlice {
  sourceFramework: V12Framework;
  upstream: number;
  masterMetric: number;
  closureResidual: number;
  chainUpCoupling: number;
}
export interface AnchorScaleSlices {
  anchor: AnchorId;
  canonicalSource: V12Framework;
  slices: AnchorSlice[];
  selfConsistencyResidual: number;
}
export interface ScaleSlicesResult {
  F4: AnchorScaleSlices;
  F2: AnchorScaleSlices;
  F7: AnchorScaleSlices;
  worstSelfConsistency: number;
  /** New: full grid (re-exposed for new UI panels). */
  grid: ScaleGridResult;
}

function projectAnchor(grid: ScaleGridResult, a: AnchorId): AnchorScaleSlices {
  const row = grid.rows[a];
  const slices: AnchorSlice[] = V12_ORDER.map((src) => {
    const cell = row.cells.find((c) => c.source === src)!;
    return {
      sourceFramework: cell.source,
      upstream: cell.upstream,
      masterMetric: cell.masterMetric,
      closureResidual: cell.closureResidual,
      chainUpCoupling: cell.chainUpCoupling,
    };
  });
  return {
    anchor: a,
    canonicalSource: CANONICAL_SOURCE[a],
    slices,
    selfConsistencyResidual: row.selfConsistencyResidual,
  };
}

export function computeScaleSlices(
  input: MetatronInput,
  propagated: PropagatedChain,
): ScaleSlicesResult {
  const grid = computeScaleGrid(input, propagated);
  // Worst across the 3 legacy anchors (UI-compat) AND the full grid.
  const legacyAnchors: AnchorId[] = ['F4', 'F2', 'F7'];
  const worstLegacy = Math.max(
    ...legacyAnchors.map((a) => grid.rows[a].selfConsistencyResidual),
  );
  return {
    F4: projectAnchor(grid, 'F4'),
    F2: projectAnchor(grid, 'F2'),
    F7: projectAnchor(grid, 'F7'),
    worstSelfConsistency: Math.max(worstLegacy, grid.worstSelfConsistency),
    grid,
  };
}
