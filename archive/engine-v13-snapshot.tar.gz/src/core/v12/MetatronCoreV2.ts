/**
 * V12 — Metatron Core (Sandbox)
 * ────────────────────────────────────────────────────────────────────────────
 * Runs the SAME compute bodies as V11 (no math rewritten, no depth removed)
 * but:
 *   1. Reorders the chain by physical length scale (LogScaleWeights.ts).
 *   2. RE-PROPAGATES chainUpCoupling through the new ordering by calling
 *      each compute function with the previous V12 rung's coupling fed
 *      into its upstream slot (PropagateScaleOrder.ts).
 *   3. Splits F5 into F5a (EM/photon/color) + F5b (acoustic/music) via
 *      input-band masking; the F5 compute body itself is untouched.
 *   4. Treats F6 (Hebrew/tree) as a SCALE-FREE OVERLAY, not a ladder rung.
 *   5. Uses log-scale-derived φ-weights for closure & coherence means.
 *
 * The live V11 engine (`MetatronCore.ts`) is untouched. This file is only
 * imported by `/sandbox`.
 */

import {
  computeMetatron,
  computeMetatronMemo,
  type MetatronInput,
  type MetatronOutput,
} from '@/core/MetatronCore';
import {
  V12_ORDER,
  LOG10_SCALE,
  DEFAULT_F6_HOSTS,
  computeLogScaleWeights,
  type V12Framework,
  type RungWeight,
} from './LogScaleWeights';
import { propagateScaleOrder, type PropagatedChain, type RungBias } from './PropagateScaleOrder';
import { buildF6Overlay, type F6Overlay } from './frameworks/F6_Overlay';

export interface V12RungDiagnostic {
  framework: V12Framework;
  log10Scale: number;
  weight: number;            // log-scale-derived φ-weight, normalized
  chainUpCoupling: number;   // re-propagated through V12 ordering
  closureResidual: number;
  masterMetric: number;
  /** V11's value for the same framework rung, for side-by-side diffing. */
  v11ChainUpCoupling: number | null;
}

export interface V12Output {
  /** Untouched V11 result, threaded through so panels can diff side-by-side. */
  v11: MetatronOutput;
  /** Full re-propagated chain (V12 ordering). */
  propagated: PropagatedChain;
  /** Ordered (smallest → largest ℓ) diagnostics for the 9-rung V12 chain. */
  chain: V12RungDiagnostic[];
  /** F6 overlay (scale-free), not in the rung chain. */
  f6Overlay: F6Overlay;
  /** Log-scale-weighted geometric mean of all rung closure residuals. */
  metatronClosure: number;
  /** Log-scale-weighted geometric mean of all rung master metrics. */
  metatronCoherence: number;
  /**
   * Torus loop closure F9 ↔ F8 against the V12 chain.
   * → 0 means perfect closure; → 1 means broken loop.
   */
  torusClosure: number;
  /** Adjacent-rung Δcoupling sum, normalized — toroidal flow smoothness. */
  phaseCirculation: number;
  /** The rung-weight table actually used this tick (audit-friendly). */
  weights: RungWeight[];
}

// Persistent F9 → F8 toroidal feedback across ticks. The V12 chain runs
// F8 before F9, so the cosmic loop can only close by feeding the PREVIOUS
// tick's F9 metric back into the NEXT tick's F8. Module-scoped so the
// driver doesn't have to thread it manually; reset via resetMetatronV12().
let _prevF9Feedback = 0;
export function resetMetatronV12(): void {
  _prevF9Feedback = 0;
  _v12Lru.clear();
}

// Lightweight V12 LRU on top of the V11 memo. The bias object is folded
// into the key by JSON-stringify (small, ≤9 numeric entries).
const V12_LRU_MAX = 8;
const _v12Lru = new Map<string, V12Output>();
function v12Key(input: MetatronInput, bias: RungBias | null, fb: number): string {
  // Reuse the V11 input fingerprint indirectly: cheap signature of the
  // primitive driver values plus bias+feedback. Full input identity is
  // already covered by computeMetatronMemo below; this LRU just avoids
  // re-running propagateScaleOrder + aggregation when inputs repeat.
  const e = input.extensions;
  const eSig = e ? `${e.chakraModes ?? '_'},${e.atomicShells ?? '_'},${e.metatronNodes ?? '_'},${e.chromaticSemitones ?? '_'},${(e.multipoles ?? []).join('.')},${e.subPlanckianRings ?? '_'},${e.subPlanckianModes ?? '_'},${e.subPlanckianSpheres ?? '_'}` : '_';
  return `${input.coherence}|${input.energy ?? '_'}|${input.time}|${input.recursionDepth ?? '_'}|${eSig}|${bias ? JSON.stringify(bias) : '_'}|${fb}`;
}

export interface V12Options {
  /**
   * Re-run the F8 → … → F9 chain inside the same tick until the F9 cosmic-web
   * coherence (which feeds back into F8 with Lipschitz ≤ 0.15) converges
   * within `f8FeedbackEps` or `f8FeedbackMaxIter` is reached. Default `false`
   * preserves V10/V12 parity (single pass with prev-tick stale feedback).
   *
   * Wolfram-verified contractivity: the F9→F8 coupling kernel is
   * `K(x) = min(1, base + 0.15·x)` with x ∈ [0,1], so |K'| ≤ 0.15 < 1 and
   * the Banach fixed-point theorem guarantees convergence with error bound
   * `0.15^n · |x₀ − x*|`. n=4 ⇒ ≤ 5e-4, n=8 ⇒ ≤ 3e-7.
   */
  f8SameTickFeedback?: boolean;
  f8FeedbackEps?: number;     // default 1e-6
  f8FeedbackMaxIter?: number; // default 8
}

export function computeMetatronV12(
  input: MetatronInput,
  rungBias: RungBias | null = null,
  options: V12Options = {},
): V12Output {
  const sameTick = options.f8SameTickFeedback === true;
  const eps = options.f8FeedbackEps ?? 1e-6;
  const maxIter = Math.max(1, options.f8FeedbackMaxIter ?? 8);

  // Cache key must include the feedback-mode flag — single-pass and
  // fixed-point passes produce different outputs at the same inputs.
  const key = v12Key(input, rungBias, _prevF9Feedback) + `|st=${sameTick ? 1 : 0}`;
  const hit = _v12Lru.get(key);
  if (hit !== undefined) {
    _v12Lru.delete(key); _v12Lru.set(key, hit);
    return hit;
  }

  // 1. Run V11 once for side-by-side reference (memoised — cache hit skips
  //    all 9 framework calls when inputs repeat across ticks).
  const v11 = computeMetatronMemo(input);

  // 2. Run the re-propagated V12 chain. Default (parity) path: single pass
  //    with prev-tick F9 feedback. Same-tick path: iterate to a fixed point
  //    on F9.cosmicWebCoherence so the cosmic loop closes within this tick.
  let p = propagateScaleOrder(input, rungBias, _prevF9Feedback);
  if (sameTick) {
    let prevFb = _prevF9Feedback;
    for (let iter = 0; iter < maxIter; iter++) {
      const nextFb = isFinite(p.F9.cosmicWebCoherence) ? p.F9.cosmicWebCoherence : 0;
      if (Math.abs(nextFb - prevFb) <= eps) break;
      prevFb = nextFb;
      p = propagateScaleOrder(input, rungBias, nextFb);
    }
  }

  // 3. Per-rung metric extraction in V12 order.
  const rungMetrics: Record<V12Framework, {
    chainUpCoupling: number;
    closureResidual: number;
    masterMetric: number;
    v11ChainUpCoupling: number | null;
  }> = {
    F8:  { chainUpCoupling: p.F8.chainUpCoupling,  closureResidual: p.F8.closureResidual,  masterMetric: p.F8.superpositionMComposite, v11ChainUpCoupling: v11.F8.chainUpCoupling },
    F4:  { chainUpCoupling: p.F4.chainUpCoupling,  closureResidual: p.F4.closureResidual,  masterMetric: p.F4.geometricCoherence,      v11ChainUpCoupling: v11.F4.chainUpCoupling },
    F2:  { chainUpCoupling: p.F2.chainUpCoupling,  closureResidual: p.F2.closureResidual,  masterMetric: p.F2.quantumCoherence,        v11ChainUpCoupling: v11.F2.chainUpCoupling },
    F5a: { chainUpCoupling: p.F5a.chainUpCoupling, closureResidual: p.F5a.closureResidual, masterMetric: p.F5a.colorMusicCoherence,    v11ChainUpCoupling: null },
    F3:  { chainUpCoupling: p.F3.chainUpCoupling,  closureResidual: p.F3.closureResidual,  masterMetric: p.F3.atomicCoherence,         v11ChainUpCoupling: v11.F3.chainUpCoupling },
    F1:  { chainUpCoupling: p.F1.chainUpCoupling,  closureResidual: p.F1.closureResidual,  masterMetric: p.F1.heptagonCoherence,       v11ChainUpCoupling: v11.F1.chainUpCoupling },
    F5b: { chainUpCoupling: p.F5b.chainUpCoupling, closureResidual: p.F5b.closureResidual, masterMetric: p.F5b.colorMusicCoherence,    v11ChainUpCoupling: null },
    F7:  { chainUpCoupling: p.F7.chainUpCoupling,  closureResidual: p.F7.closureResidual,  masterMetric: p.F7.galacticCoherence,       v11ChainUpCoupling: v11.F7.chainUpCoupling },
    F9:  { chainUpCoupling: p.F9.chainUpCoupling,  closureResidual: p.F9.closureResidual,  masterMetric: p.F9.cosmicWebCoherence,      v11ChainUpCoupling: v11.F9.chainUpCoupling },
  };

  const weights = computeLogScaleWeights();
  const chain: V12RungDiagnostic[] = weights.map((w) => ({
    framework: w.framework,
    log10Scale: w.log10Scale,
    weight: w.weight,
    ...rungMetrics[w.framework],
  }));

  // 4. F6 overlay — distribute across host rungs using their chain-up coupling.
  const hostCouplings: Partial<Record<V12Framework, number>> = {};
  for (const h of DEFAULT_F6_HOSTS) hostCouplings[h] = rungMetrics[h].chainUpCoupling;
  const f6Overlay = buildF6Overlay(p.F6, hostCouplings, DEFAULT_F6_HOSTS);

  // 5. Log-scale-weighted geometric means.
  let logResid = 0, logMaster = 0, wSum = 0;
  for (const r of chain) {
    logResid  += r.weight * Math.log(Math.max(1e-12, r.closureResidual));
    logMaster += r.weight * Math.log(Math.max(1e-12, r.masterMetric));
    wSum += r.weight;
  }
  const metatronClosure   = wSum > 0 ? Math.exp(logResid  / wSum) : 0;
  const metatronCoherence = wSum > 0 ? Math.exp(logMaster / wSum) : 0;

  // 6. Torus closure (F9 ↔ F8) and phase circulation against the V12 ordering.
  const c8 = rungMetrics.F8.chainUpCoupling;
  const c9 = rungMetrics.F9.chainUpCoupling;
  const meanEnds = 0.5 * (c8 + c9);
  const torusClosure = meanEnds > 1e-12
    ? Math.min(1, Math.abs(c9 - c8) / meanEnds)
    : 0;

  const ladder = V12_ORDER.map((f) => rungMetrics[f].chainUpCoupling);
  ladder.push(c8); // close the loop back to F8
  let circ = 0;
  for (let i = 1; i < ladder.length; i++) circ += Math.abs(ladder[i] - ladder[i - 1]);
  const phaseCirculation = Math.min(1, circ / (2 * (ladder.length - 1)));

  void LOG10_SCALE; // keep import live for audit-table consumers
  void computeMetatron; // legacy reference kept for audit/diffing tooling
  const out: V12Output = {
    v11,
    propagated: p,
    chain,
    f6Overlay,
    metatronClosure,
    metatronCoherence,
    torusClosure,
    phaseCirculation,
    weights,
  };

  // Persist F9 feedback for the next tick's F8 input (closes the cosmic loop
  // across ticks even when same-tick mode is off).
  _prevF9Feedback = isFinite(p.F9.cosmicWebCoherence) ? p.F9.cosmicWebCoherence : 0;

  _v12Lru.set(key, out);
  if (_v12Lru.size > V12_LRU_MAX) {
    const oldest = _v12Lru.keys().next().value;
    if (oldest !== undefined) _v12Lru.delete(oldest);
  }
  return out;
}
