/**
 * V12 — Shared parity-safe default generators (P0.1)
 * ────────────────────────────────────────────────────────────────────────
 * Single source of truth for the synthetic inputs used by both
 * PropagateScaleOrder and ScaleGrid/ScaleSlices. Both files MUST import
 * from here — duplicating these locally silently breaks the
 * slice-vs-propagated self-consistency invariant when an edit drifts.
 *
 * Pure, deterministic, allocation-light. No I/O.
 */

import { PHI_INV } from '@/core/frameworks/constants';

export function defaultPhases(seed: number): Float64Array {
  const out = new Float64Array(44);
  for (let i = 0; i < 44; i++) out[i] = Math.sin((i + 1) * PHI_INV + seed * 1e-3);
  return out;
}

export function defaultPineal(seed: number): Float64Array {
  const out = new Float64Array(55);
  for (let k = 0; k < 55; k++) out[k] = 0.5 + 0.4 * Math.sin(k * PHI_INV * 1.7 + seed * 1e-3);
  return out;
}

export function defaultNodeAmps(): Float64Array {
  const out = new Float64Array(7);
  for (let n = 0; n < 7; n++) out[n] = Math.pow(PHI_INV, n);
  return out;
}

export function defaultNodeCoh(n: number): number[] {
  return Array.from({ length: n }, (_, i) => 0.5 + 0.4 * Math.cos(i * PHI_INV * 1.1));
}

export function defaultFlower(): number[] {
  return Array.from({ length: 55 }, (_, i) => 0.5 + 0.4 * Math.cos(i * PHI_INV * 1.3));
}

export function defaultSolfeggio(): number[] {
  return [0.5, 0.4, 0.6, 0.7, 0.55, 0.45, 0.65, 0.5, 0.6];
}

/** F5 solfeggio band masks — photon (upper) vs acoustic (lower).
 *  Indices: 0..8 → [174, 285, 396, 417, 528, 639, 741, 852, 963] Hz.
 *  Must be DISJOINT (prior versions double-counted index 4 / 528 Hz in
 *  both bands). 528 Hz is mechanical-acoustic Solfeggio — it belongs to
 *  the acoustic band only. The photon band starts at the next octave
 *  (639 Hz and above, then carried up by F5's φ-octave bridges). */
export const PHOTON_MASK   = [0, 0, 0, 0, 0, 1, 1, 1, 1];
export const ACOUSTIC_MASK = [1, 1, 1, 1, 1, 0, 0, 0, 0];

export function maskSolfeggio(src: number[], mask: number[]): number[] {
  let sum = 0, n = 0;
  for (let i = 0; i < src.length; i++) {
    if (mask[i % mask.length]) { sum += src[i]; n++; }
  }
  const mean = n > 0 ? sum / n : 0;
  return src.map((v, i) => (mask[i % mask.length] ? v : mean));
}
