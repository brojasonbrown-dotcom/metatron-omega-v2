/**
 * V12 — True Scale-Ordered Re-Propagation (now P2.3 bias-aware)
 * ────────────────────────────────────────────────────────────────────────────
 * Same compute bodies as V11; threads chainUpCoupling through the physical
 * scale ordering.  Optionally accepts a per-rung bias vector (length 9,
 * indexed by V12_ORDER) that is added to each rung's upstream slot before
 * the framework body runs.  bias = null/0 ⇒ outputs bit-identical to the
 * previous bias-free pipeline.
 *
 * NO live-engine path.
 */

import { computeF1, type F1Input, type F1Output } from '@/core/frameworks/F1_Septenary';
import { computeF2, type F2Input, type F2Output } from '@/core/frameworks/F2_Quantum';
import { computeF3, type F3Input, type F3Output } from '@/core/frameworks/F3_Atomic';
import { computeF4, type F4Input, type F4Output } from '@/core/frameworks/F4_Geometric';
import { computeF5, type F5Input, type ColorMusicOutput as F5Output } from '@/core/frameworks/F5_ColorMusic';
import { computeF6, type F6Input, type F6OutputV11 as F6Output } from '@/core/frameworks/F6_Hebrew';
import { computeF7, type F7Input, type F7OutputV11 as F7Output } from '@/core/frameworks/F7_Galactic';
import { computeF8, type F8Input, type F8Output } from '@/core/frameworks/F8_SubPlanckian';
import { computeF9, type F9Input, type F9OutputV11 as F9Output } from '@/core/frameworks/F9_HyperGalactic';
import type { MetatronInput } from '@/core/MetatronCore';
import { V12_ORDER, type V12Framework } from './LogScaleWeights';
import {
  defaultPhases, defaultPineal, defaultNodeAmps, defaultNodeCoh,
  defaultFlower, defaultSolfeggio, maskSolfeggio, PHOTON_MASK, ACOUSTIC_MASK,
} from './defaults';

export interface PropagatedChain {
  F8:  F8Output;
  F4:  F4Output;
  F2:  F2Output;
  F5a: F5Output;
  F3:  F3Output;
  F1:  F1Output;
  F5b: F5Output;
  F7:  F7Output;
  F9:  F9Output;
  F6:  F6Output;
}

/** Per-rung additive bias on the upstream slot. Indexed by V12 framework. */
export type RungBias = Partial<Record<V12Framework, number>>;

function biasFor(bias: RungBias | null | undefined, fw: V12Framework): number {
  if (!bias) return 0;
  const b = bias[fw];
  return typeof b === 'number' && isFinite(b) ? b : 0;
}

export function propagateScaleOrder(
  input: MetatronInput,
  bias: RungBias | null = null,
  /** Previous-tick F9 → F8 toroidal feedback (closes the cosmic loop).
   *  Default 0 keeps prior callers bit-identical. The MetatronCoreV2
   *  driver can persist `p.F9.cosmicWebCoherence` (or equivalent) across
   *  ticks and pass it in here to re-activate the F9 ↔ F8 torus closure
   *  that the original V11 propagation order silently suppressed. */
  prevTickF9Feedback: number = 0,
): PropagatedChain {
  const {
    coherence, time,
    energy = coherence,
    phases = defaultPhases(time),
    pinealField = defaultPineal(time),
    nodeAmps = defaultNodeAmps(),
    nodeCoherences = defaultNodeCoh(13),
    pinealCoherences = defaultNodeCoh(22),
    flowerCoherences = defaultFlower(),
    solfeggioCoherences = defaultSolfeggio(),
    recursionDepth = 5,
    extensions = {},
  } = input;

  // F8 — sub-Planckian foam. Receives bias[F8] AND the previous-tick F9
  // toroidal feedback, since the cosmic loop closes F9 → F8 by topology
  // and F9 of THIS tick cannot run before F8.
  const f8In: F8Input = {
    coherence: coherence + biasFor(bias, 'F8'),
    energy, pinealField, solfeggioCoherences, time, flowerCoherences,
    hyperGalacticToroidalFeedback: prevTickF9Feedback,
    targetModes: extensions.subPlanckianModes,
    targetRings: extensions.subPlanckianRings,
    targetSpheres: extensions.subPlanckianSpheres,
  };
  const F8 = computeF8(f8In);
  let upstream = F8.chainUpCoupling;

  const f4In: F4Input = {
    coherence, nodeCoherences, time, solfeggioCoherences, flowerCoherences,
    atomicChainUp: upstream + biasFor(bias, 'F4'),
    extensionMetatronNodes: extensions.metatronNodes,
  };
  const F4 = computeF4(f4In);
  upstream = F4.chainUpCoupling;

  const f2In: F2Input = {
    coherence, energy, pinealField, solfeggioCoherences, time, flowerCoherences,
    septenaryChainUp: upstream + biasFor(bias, 'F2'),
    extensionParticles: extensions.quantumParticles,
  };
  const F2 = computeF2(f2In);
  upstream = F2.chainUpCoupling;

  // V12 audit fix: F3 (atomic, log₁₀ −9) sits BELOW F5a (EM, log₁₀ −7)
  // on the physical ladder, so it must propagate first. Prior order
  // (F5a → F3) walked the scale backwards.
  const f3In: F3Input = {
    coherence, nodeAmps, solfeggioCoherences, time, flowerCoherences,
    quantumChainUp: upstream + biasFor(bias, 'F3'),
    extensionShells: extensions.atomicShells,
  };
  const F3 = computeF3(f3In);
  upstream = F3.chainUpCoupling;

  const f5aIn: F5Input = {
    coherence,
    solfeggioCoherences: maskSolfeggio(solfeggioCoherences, PHOTON_MASK),
    time, flowerCoherences,
    geometricChainUp: upstream + biasFor(bias, 'F5a'),
    extensionChromaticSemitones: extensions.chromaticSemitones,
  };
  const F5a = computeF5(f5aIn);
  upstream = F5a.chainUpCoupling;

  const f1In: F1Input = {
    coherence, phases, time, flowerCoherences,
    subPlanckianChainUp: upstream + biasFor(bias, 'F1'),
    targetModes: extensions.chakraModes,
  };
  const F1 = computeF1(f1In);
  upstream = F1.chainUpCoupling;

  const f5bIn: F5Input = {
    coherence,
    solfeggioCoherences: maskSolfeggio(solfeggioCoherences, ACOUSTIC_MASK),
    time, flowerCoherences,
    geometricChainUp: upstream + biasFor(bias, 'F5b'),
    extensionChromaticSemitones: extensions.chromaticSemitones,
  };
  const F5b = computeF5(f5bIn);
  upstream = F5b.chainUpCoupling;

  const f7In: F7Input = {
    coherence, energy, time, recursionDepth, flowerCoherences, solfeggioCoherences,
    hebrewChainUp: upstream + biasFor(bias, 'F7'),
    extensionBodies: extensions.bodies,
  };
  const F7 = computeF7(f7In);
  upstream = F7.chainUpCoupling;

  const f9In: F9Input = {
    coherence, energy, pinealField, solfeggioCoherences, time,
    recursionDepth, flowerCoherences,
    galacticChainUp: upstream + biasFor(bias, 'F9'),
    extensionMultipoles: extensions.multipoles,
  };
  const F9 = computeF9(f9In);

  const f6In: F6Input = {
    coherence, pinealCoherences, time, flowerCoherences, solfeggioCoherences,
    colorMusicChainUp: F5a.chainUpCoupling,
    septenaryCentralColumn: F1.centralColumn,
    extensionLetters: extensions.letters,
  };
  const F6 = computeF6(f6In);

  void V12_ORDER;
  return { F8, F4, F2, F5a, F3, F1, F5b, F7, F9, F6 };
}
