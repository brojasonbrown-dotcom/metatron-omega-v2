/**
 * V12 — Per-Rung Qualia (P3.2 + P7.1)
 * ──────────────────────────────────────────────────────────────────────────
 * Spatial / temporal subspace SPLIT embedding:
 *   - spatial: φ-rotated cosine basis of length EMBED_DIM (no history)
 *   - temporal: φ-decayed history of length HISTORY
 * Each subspace is qualia-correlated independently; combined Q is the
 * geometric mean of the two Q values.  Eliminates the dominance of the
 * spatial wave term over history in the old single-vector embedding.
 *
 * Numerical stability: weighted reductions use NeumaierSum (compensated).
 */

import { QualiaTracker, type QualiaVector } from '@/core/field/Qualia';
import { computeQualiaCorrelate, type QualiaCorrelate } from './QualiaCorrelate';
import {
  V12_ORDER,
  computeLogScaleWeights,
  type V12Framework,
} from './LogScaleWeights';
import type { V12Output, V12RungDiagnostic } from './MetatronCoreV2';
import { NeumaierSum } from '@/core/numerics/StableSum';

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV = 1 / PHI;
const EMBED_DIM = 13;
const HISTORY = 16;
/** Soft floor for log-domain global reduction: 1/φ⁴ ≈ 0.1459.
 *  Prevents a single near-zero rung from collapsing the geometric mean to 0
 *  while still penalising weak rungs (a hard floor of 1e-12 produces
 *  log = −27 which dominates the reduction). */
const SOFT_FLOOR = 1 / (PHI * PHI * PHI * PHI);

export interface RungQualia extends QualiaVector {
  framework: V12Framework;
  weight: number;
  Q: number;
  Q_inc: number;
  Q_stab: number;
  Q_res: number;
  /** Spatial-subspace Q (no history). */
  Q_spatial: number;
  /** Temporal-subspace Q (history only). */
  Q_temporal: number;
}

export interface GlobalQualia extends QualiaVector {
  Q: number;
  priorityFramework: V12Framework;
  priorityScore: number;
  /** Log-space cross-source argmax (for audit cross-check). */
  priorityFrameworkLog: V12Framework;
  priorityScoreLog: number;
}

export interface PerRungQualiaResult {
  perRung: RungQualia[];
  global: GlobalQualia;
}

/** Spatial embedding (NO history term). Each harmonic component is
 *  zero-mean-centered across i so the resulting vector's energy reflects
 *  φ-structured oscillation rather than the DC level driven by |a|+|b|+|c|. */
function embedSpatial(d: V12RungDiagnostic): Float64Array {
  const out = new Float64Array(EMBED_DIM);
  const a = d.chainUpCoupling;
  const b = Math.max(0, 1 - d.closureResidual);
  const c = d.masterMetric;
  // Precompute harmonic means so each cos(h·θ_i) family is centered.
  const mean = [0, 0, 0];
  for (let i = 0; i < EMBED_DIM; i++) {
    const theta = (i + 1) * PHI_INV;
    mean[0] += Math.cos(theta);
    mean[1] += Math.cos(2 * theta);
    mean[2] += Math.cos(3 * theta);
  }
  mean[0] /= EMBED_DIM; mean[1] /= EMBED_DIM; mean[2] /= EMBED_DIM;
  for (let i = 0; i < EMBED_DIM; i++) {
    const theta = (i + 1) * PHI_INV;
    out[i] =
      a * (Math.cos(theta)     - mean[0]) +
      b * (Math.cos(2 * theta) - mean[1]) +
      c * (Math.cos(3 * theta) - mean[2]);
  }
  return out;
}

/** Temporal embedding (history, φ-decayed). Warm-start: when history is
 *  empty or short, the current chainUpCoupling sample is prepended so the
 *  first tick produces a non-zero subspace (avoids cold-start Q=0 collapse).
 */
function embedTemporal(history: number[], warmSample: number): Float64Array {
  const out = new Float64Array(HISTORY);
  if (history.length === 0 && warmSample !== 0) {
    out[0] = warmSample;
    return out;
  }
  for (let i = 0; i < HISTORY; i++) {
    const h = history[i] ?? (i === 0 ? warmSample : 0);
    out[i] = h * Math.pow(PHI_INV, i);
  }
  return out;
}

export class PerRungQualiaTracker {
  private trackers = new Map<V12Framework, QualiaTracker>();
  private histories = new Map<V12Framework, number[]>();

  constructor() {
    for (const f of V12_ORDER) {
      this.trackers.set(f, new QualiaTracker(HISTORY));
      this.histories.set(f, []);
    }
  }

  update(v12: V12Output): PerRungQualiaResult {
    const weights = computeLogScaleWeights();
    const wMap = new Map(weights.map((w) => [w.framework, w.weight] as const));

    const perRung: RungQualia[] = [];

    // Stable accumulators (Neumaier compensated) for global reduction.
    const accLogC = new NeumaierSum();
    const accLogQ = new NeumaierSum();
    const accN = new NeumaierSum();
    const accS = new NeumaierSum();
    const accV = new NeumaierSum();
    const accI = new NeumaierSum();
    const accW = new NeumaierSum();

    let topScore = -Infinity, topFw: V12Framework = V12_ORDER[0];
    let topLogScore = -Infinity, topLogFw: V12Framework = V12_ORDER[0];

    for (const r of v12.chain) {
      const fw = r.framework;
      const hist = this.histories.get(fw)!;
      const tracker = this.trackers.get(fw)!;
      const weight = wMap.get(fw) ?? 0;

      const spatial  = embedSpatial(r);
      const temporal = embedTemporal(hist, r.chainUpCoupling);

      // Per-subspace qualia correlation, then geometric mean.
      const qcS: QualiaCorrelate = computeQualiaCorrelate(spatial);
      const qcT: QualiaCorrelate = computeQualiaCorrelate(temporal);
      const Q_spatial = qcS.Q;
      const Q_temporal = qcT.Q;
      const Q = Math.sqrt(Math.max(0, Q_spatial) * Math.max(0, Q_temporal));
      // Composite Q_inc/Q_stab/Q_res = geometric mean of subspace values
      // (kept for audit traceability).
      const Q_inc  = Math.sqrt(Math.max(0, qcS.Q_inc)  * Math.max(0, qcT.Q_inc));
      const Q_stab = Math.sqrt(Math.max(0, qcS.Q_stab) * Math.max(0, qcT.Q_stab));
      const Q_res  = Math.sqrt(Math.max(0, qcS.Q_res)  * Math.max(0, qcT.Q_res));

      // 5-axis qualia on combined modes (concatenation) for stability of
      // novelty/salience temporal axes (which already use the tracker's
      // own ring buffer internally).
      const combined = new Float64Array(EMBED_DIM + HISTORY);
      combined.set(spatial, 0);
      combined.set(temporal, EMBED_DIM);
      const energy = Math.max(1e-9, Math.abs(r.masterMetric) + Math.abs(r.chainUpCoupling));
      const q5: QualiaVector = tracker.compute(
        combined,
        Math.max(0, Math.min(1, r.masterMetric)),
        Math.abs(r.chainUpCoupling),
        Math.abs(r.closureResidual),
        energy,
      );

      const row: RungQualia = {
        framework: fw, weight,
        C: q5.C, N: q5.N, S: q5.S, V: q5.V, I: q5.I,
        Q, Q_inc, Q_stab, Q_res,
        Q_spatial, Q_temporal,
      };
      perRung.push(row);

      // Attention head (direct).
      const score = weight * q5.S * (1 + q5.N) * Q;
      if (score > topScore) { topScore = score; topFw = fw; }

      // Attention head (log-space, cross-source check).
      const eps = 1e-30;
      const logScore =
        Math.log(Math.max(eps, weight)) +
        Math.log(Math.max(eps, q5.S)) +
        Math.log(Math.max(eps, 1 + q5.N)) +
        Math.log(Math.max(eps, Q));
      if (logScore > topLogScore) { topLogScore = logScore; topLogFw = fw; }

      // Global reduction.
      accLogC.add(weight * Math.log(Math.max(SOFT_FLOOR, q5.C)));
      accLogQ.add(weight * Math.log(Math.max(SOFT_FLOOR, Q)));
      accN.add(weight * q5.N);
      accS.add(weight * q5.S);
      accV.add(weight * q5.V);
      accI.add(weight * q5.I);
      accW.add(weight);

      hist.unshift(r.chainUpCoupling);
      if (hist.length > HISTORY) hist.length = HISTORY;
    }

    const wSum = accW.value();
    const global: GlobalQualia = {
      C: wSum > 0 ? Math.exp(accLogC.value() / wSum) : 0,
      N: wSum > 0 ? accN.value() / wSum : 0,
      S: wSum > 0 ? accS.value() / wSum : 0,
      V: wSum > 0 ? accV.value() / wSum : 0,
      I: wSum > 0 ? accI.value() / wSum : 0,
      Q: wSum > 0 ? Math.exp(accLogQ.value() / wSum) : 0,
      priorityFramework: topFw,
      priorityScore: isFinite(topScore) ? topScore : 0,
      priorityFrameworkLog: topLogFw,
      priorityScoreLog: isFinite(topLogScore) ? Math.exp(topLogScore) : 0,
    };
    return { perRung, global };
  }

  reset(): void {
    for (const f of V12_ORDER) {
      this.trackers.set(f, new QualiaTracker(HISTORY));
      this.histories.set(f, []);
    }
  }
}
