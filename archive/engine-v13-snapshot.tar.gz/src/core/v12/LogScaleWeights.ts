/**
 * V12 — Log-Scale φ-Weights for the Metatron Chain
 * ────────────────────────────────────────────────────────────────────────────
 * The V11 ladder weights rungs by *narrative distance* from F4 (geometric
 * centre). V12 weights them by *physical length scale* (log₁₀ ℓ in metres),
 * so adjacent-rung distance in the weighted geometric mean reflects real
 * scale spacing instead of file numbering.
 *
 * Reference scales (centre of each rung's band, log₁₀ ℓ / m):
 *   F8   sub-Planck / pre-geometric foam   ~ −36
 *   F4   Planck-geometric substrate         ~ −34
 *   F2   quantum field (QCD / EW)           ~ −17
 *   F5a  EM / photon (visible λ, color)     ~ −7
 *   F3   atomic / molecular                 ~ −9   (Bohr radius band)
 *   F1   septenary / bio-body               ~ −1
 *   F5b  acoustic / music (mech. λ)         ~ +1
 *   F7   galactic                           ~ +21
 *   F9   hyper-galactic / cosmic web        ~ +25
 *
 *   F6   Hebrew / tree-of-life              scale-free OVERLAY (no rung slot)
 *
 * All math is verbatim re-use; no compute body is rewritten.
 */

import { PHI_INV } from '@/core/frameworks/constants';

export type V12Framework =
  | 'F8' | 'F4' | 'F2' | 'F5a' | 'F3' | 'F1' | 'F5b' | 'F7' | 'F9';

/** Length-scale anchors, log₁₀ ℓ in metres. Centre of each rung's band. */
export const LOG10_SCALE: Record<V12Framework, number> = {
  F8:  -36,
  F4:  -34,
  F2:  -17,
  F5a:  -7,
  F3:   -9,
  F1:   -1,
  F5b:  +1,
  F7:  +21,
  F9:  +25,
};

/** Canonical V12 ordering, strictly ascending log₁₀ ℓ. */
//   F8 −36 · F4 −34 · F2 −17 · F3 −9 · F5a −7 · F1 −1 · F5b +1 · F7 +21 · F9 +25
// Bug fix (V12 audit): prior order had F5a before F3, propagating EM→atomic
// against the physical scale gradient. Re-ordered to match LOG10_SCALE.
export const V12_ORDER: readonly V12Framework[] = [
  'F8','F4','F2','F3','F5a','F1','F5b','F7','F9',
] as const;

/**
 * φ-weights derived from log-scale distance to the geometric substrate (F4).
 * Each rung gets weight = φ⁻ᵏ where k = round(|Δlog₁₀ℓ_F4| / log₁₀(φ)).
 * Result is then normalized so Σ wᵢ = 1.
 *
 * log₁₀(φ) ≈ 0.20898764024997873  →  one φ-octave ≈ 4.785 decades.
 * That puts F2 / F5a / F3 each ~3–4 φ-octaves from F4, F1 ~7, F7 ~12, F9 ~13.
 */
export interface RungWeight {
  framework: V12Framework;
  log10Scale: number;
  /** φ-octave distance from F4 (signed; closer = smaller). */
  phiOctaveDist: number;
  /** Unnormalized weight φ⁻ᵏ. */
  rawWeight: number;
  /** Normalized weight (Σ = 1). */
  weight: number;
}

const LOG10_PHI = Math.log10((1 + Math.sqrt(5)) / 2); // 0.20898764024997873...

export function computeLogScaleWeights(): RungWeight[] {
  const f4 = LOG10_SCALE.F4;
  const raw = V12_ORDER.map((fw) => {
    const dist = Math.abs(LOG10_SCALE[fw] - f4) / LOG10_PHI;
    const k = Math.round(dist);
    return {
      framework: fw,
      log10Scale: LOG10_SCALE[fw],
      phiOctaveDist: dist,
      rawWeight: Math.pow(PHI_INV, k),
    };
  });
  const sum = raw.reduce((s, r) => s + r.rawWeight, 0);
  return raw.map((r) => ({ ...r, weight: r.rawWeight / sum }));
}

/** φ-weighted geometric mean over a value-per-rung map, using V12 weights. */
export function phiWeightedGeoMean(
  values: Partial<Record<V12Framework, number>>,
  floor = 1e-12,
): number {
  const weights = computeLogScaleWeights();
  let logSum = 0;
  let wSum = 0;
  for (const w of weights) {
    const v = values[w.framework];
    if (v === undefined) continue;
    logSum += w.weight * Math.log(Math.max(floor, v));
    wSum += w.weight;
  }
  return wSum > 0 ? Math.exp(logSum / wSum) : 0;
}

/**
 * F6 (Hebrew / tree) is scale-free. Its overlay coupling is the φ-weighted
 * mean of the rungs its 22 letters map to. Default mapping uses all rungs
 * equally (uniform overlay); the caller can supply a custom sephirotic map.
 */
export const DEFAULT_F6_HOSTS: readonly V12Framework[] = [
  'F4','F2','F5a','F3','F1',
];
