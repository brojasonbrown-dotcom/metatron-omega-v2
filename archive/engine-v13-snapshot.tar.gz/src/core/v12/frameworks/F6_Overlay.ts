/**
 * V12 — F6 as a scale-free overlay.
 *
 * F6 (Hebrew / Tree of Life) does NOT occupy its own length-scale rung.
 * Its 22-letter field is a symbolic overlay whose effective coupling is
 * the φ-weighted mean of the rungs it maps to. We compute it from existing
 * F6 output without touching that compute body.
 */

import type { F6OutputV11 as F6Output } from '@/core/frameworks/F6_Hebrew';
import { PHI_INV } from '@/core/frameworks/constants';
import type { V12Framework } from '../LogScaleWeights';

export interface F6Overlay {
  /** Pass-through of the original F6 master metric. */
  hebrewCoherence: number;
  /** Pass-through of the original F6 closure residual (V11 wrapper). */
  closureResidual: number;
  /** Pass-through chain-up coupling. */
  chainUpCoupling: number;
  /**
   * Effective overlay coupling = φ-weighted mean of host-rung couplings,
   * modulated by F6's own coherence. Sub-unitary by construction.
   */
  overlayCoupling: number;
  /** Hosts the overlay was distributed across. */
  hosts: readonly V12Framework[];
}

export function buildF6Overlay(
  f6: F6Output & { closureResidual?: number },
  hostCouplings: Partial<Record<V12Framework, number>>,
  hosts: readonly V12Framework[],
): F6Overlay {
  let logSum = 0, wSum = 0;
  for (let i = 0; i < hosts.length; i++) {
    const c = hostCouplings[hosts[i]];
    if (c === undefined) continue;
    const w = Math.pow(PHI_INV, i);
    logSum += w * Math.log(Math.max(1e-12, c));
    wSum += w;
  }
  const meanHost = wSum > 0 ? Math.exp(logSum / wSum) : 0;
  return {
    hebrewCoherence: f6.hebrewCoherence,
    closureResidual: (f6 as { closureResidual?: number }).closureResidual ?? 1e-12,
    chainUpCoupling: f6.chainUpCoupling,
    overlayCoupling: meanHost * f6.hebrewCoherence,
    hosts,
  };
}
