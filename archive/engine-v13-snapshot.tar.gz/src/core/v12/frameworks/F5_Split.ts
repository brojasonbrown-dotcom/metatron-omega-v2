/**
 * V12 — F5 split into F5a (EM / photon / color) and F5b (acoustic / music).
 *
 * The existing computeF5 is run UNCHANGED. We split its inputs along the
 * solfeggio band: the upper octaves (≥528 Hz analog) drive the photon view,
 * the lower octaves drive the acoustic view. Output headlines are derived
 * by re-running computeF5 with masked solfeggio vectors so no math inside
 * F5_ColorMusic.ts is rewritten.
 */

import { computeF5, type F5Input, type ColorMusicOutput as F5Output } from '@/core/frameworks/F5_ColorMusic';

// Re-export the canonical disjoint masks + helper from defaults so this
// helper module can never drift out of sync with PropagateScaleOrder /
// ScaleGrid (single source of truth = src/core/v12/defaults.ts).
import { PHOTON_MASK, ACOUSTIC_MASK, maskSolfeggio } from '../defaults';

export function computeF5a(input: F5Input): F5Output {
  return computeF5({
    ...input,
    solfeggioCoherences: maskSolfeggio(input.solfeggioCoherences, PHOTON_MASK),
  });
}

export function computeF5b(input: F5Input): F5Output {
  return computeF5({
    ...input,
    solfeggioCoherences: maskSolfeggio(input.solfeggioCoherences, ACOUSTIC_MASK),
  });
}
