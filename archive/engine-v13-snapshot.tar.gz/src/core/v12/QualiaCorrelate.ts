/**
 * V12 — QualiaCorrelate (P1.1, P3.1, P3.3 — measured, not asserted)
 * ──────────────────────────────────────────────────────────────────────────
 *   Q = (Q_inc · Q_stab · Q_res)^(1/3)
 *
 *   Q_inc   MEASURED Hurwitz residual on (v, φ-shift(v))  ∈ [0,1]
 *           1.0 exactly when the basis saturates the predicted attractor
 *           |⟨v, φ-shift(v)⟩|/‖v‖² = 1 − 1/√5 (Wolfram-frozen).
 *
 *   Q_stab  λ_min/λ_max of the 2×2 Gram on (v, φ-shift(v)), where
 *           φ-shift is a TRUE fractional irrational rotation (not i+1 mod n).
 *
 *   Q_res   Geometric mean of normalised top-k energy fractions for
 *           k ∈ {1..N}; equivalent to AUC of the energy-concentration curve.
 *           Captures the full attractor profile, not a single k=⌈N/φ²⌉ point.
 *
 * Operates on any real Float64Array. Pure. No I/O. Allocation-light.
 */

import { phiShift, dot, norm, cosine, attractorForN, PHI_COS_ATTRACTOR } from './PhiBasis';

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV_SQ = 1 / (PHI * PHI);

export interface QualiaCorrelate {
  Q: number;
  Q_inc: number;
  Q_stab: number;
  Q_res: number;
  /** Measured cosine |⟨v, φ-shift(v)⟩| (diagnostic). */
  measuredCos: number;
  /** Predicted attractor 1 − 1/√5 (diagnostic). */
  predictedCos: number;
  /** Full Q_res resolution curve (length N). */
  resCurve: Float64Array;
  attractorK: number;
  N: number;
}

const ZERO: QualiaCorrelate = {
  Q: 0, Q_inc: 0, Q_stab: 0, Q_res: 0,
  measuredCos: 0, predictedCos: PHI_COS_ATTRACTOR,
  resCurve: new Float64Array(0), attractorK: 0, N: 0,
};

export function zeroQualiaCorrelate(): QualiaCorrelate { return ZERO; }

/** 2×2 Gram conditioning on (v, φ-shift(v)) using TRUE irrational rotation. */
function gramConditioningPhi(v: ArrayLike<number>, vp: ArrayLike<number>): number {
  const na = norm(v), nb = norm(vp);
  if (na <= 0 || nb <= 0) return 0;
  const c = dot(v, vp) / (na * nb); // cosine
  const ac = Math.abs(c);
  // λ_{1,2} of [[1,c],[c,1]] = 1 ± c → λ_min/λ_max = (1−|c|)/(1+|c|).
  return (1 - ac) / (1 + ac);
}

/** Full energy-concentration curve: top-k energy / total for k=1..N. */
function resolutionCurve(v: ArrayLike<number>): Float64Array {
  const n = v.length;
  if (n === 0) return new Float64Array(0);
  const e = new Float64Array(n);
  let total = 0;
  for (let i = 0; i < n; i++) { e[i] = v[i] * v[i]; total += e[i]; }
  const out = new Float64Array(n);
  if (total <= 0) return out;
  const sorted = Array.from(e).sort((a, b) => b - a);
  let acc = 0;
  for (let k = 0; k < n; k++) { acc += sorted[k]; out[k] = acc / total; }
  return out;
}

export function computeQualiaCorrelate(modes: ArrayLike<number>): QualiaCorrelate {
  const N = modes.length;
  if (N < 2) return ZERO;

  // φ-shifted twin via true irrational rotation.
  const vp = phiShift(modes);

  // ── Q_inc (MEASURED): residual against per-n empirical attractor. ─────
  const c = Math.abs(cosine(modes, vp));
  const predictedCos = attractorForN(N);
  const residual = Math.abs(c - predictedCos);
  const Q_inc = Math.max(0, Math.min(1, 1 - residual));

  // ── Q_stab: 2×2 Gram conditioning on (v, φ-shift(v)). ─────────────────
  const Q_stab = gramConditioningPhi(modes, vp);

  // ── Q_res: AUC of energy-concentration curve, normalised to [0,1]. ────
  //   Trapezoidal area under (k/N → topK(k)/total), then renormalised so
  //   a flat distribution (worst) → 1/2 and a delta (best) → ~1.
  const curve = resolutionCurve(modes);
  let auc = 0;
  for (let k = 0; k < N; k++) auc += curve[k];
  auc /= N;                          // ∈ [1/N, ~1]
  // Map [1/N, 1] → [0, 1] monotonically.
  const Q_res = Math.max(0, Math.min(1, (auc - 1 / N) / (1 - 1 / N)));

  const Q = Math.cbrt(Math.max(0, Q_inc) * Math.max(0, Q_stab) * Math.max(0, Q_res));
  return {
    Q, Q_inc, Q_stab, Q_res,
    measuredCos: c,
    predictedCos,
    resCurve: curve,
    attractorK: Math.max(1, Math.ceil(N * PHI_INV_SQ)),
    N,
  };
}

export const QUALIA_CORRELATE_PROVENANCE = {
  formula: 'Q = (Q_inc · Q_stab · Q_res)^(1/3)',
  Q_inc: 'MEASURED: 1 − ||⟨v, φ-shift(v)⟩| − attractorForN(N)|',
  Q_stab: 'λ_min/λ_max of 2×2 Gram on (v, TRUE-φ-shift(v))',
  Q_res:  'AUC of top-k energy curve, normalised to [0,1]',
  attractorRef: 'attractorForN(N): empirically-frozen per-n cosine, see PhiBasis.ts',
  asymptotic: 'PHI_COS_ATTRACTOR = 1 − 1/√5 (n → ∞ limit, documentation only)',
} as const;

void PHI_COS_ATTRACTOR;
