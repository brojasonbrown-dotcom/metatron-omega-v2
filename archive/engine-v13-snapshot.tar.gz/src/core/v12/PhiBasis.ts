/**
 * V12 — φ-Basis Generators (P0.2)
 * ────────────────────────────────────────────────────────────────────────
 * Canonical φ-rotated bases used by qualia embedding, slice evaluators,
 * and the measured Q_inc / Q_stab tests. All bases are deterministic,
 * unit-friendly, and reference-checked against the Hurwitz bound
 * (1/√5 ≈ 0.4472135954…) for irrationality of rotation angles.
 *
 * Pure. No I/O. No randomness.
 */

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV = 1 / PHI;
const TAU = 2 * Math.PI;

/** Build φ-rotated cosine basis of length n with k harmonics. */
export function phiCosineBasis(n: number, k = 3): Float64Array {
  const out = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let h = 1; h <= k; h++) s += Math.cos(h * (i + 1) * PHI_INV);
    out[i] = s / k;
  }
  return out;
}

/** True φ-shift via fractional linear interpolation (irrational rotation). */
export function phiShift(v: ArrayLike<number>): Float64Array {
  const n = v.length;
  const out = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const x = ((i * PHI) % n + n) % n;
    const lo = Math.floor(x);
    const hi = (lo + 1) % n;
    const t = x - lo;
    out[i] = (1 - t) * v[lo] + t * v[hi];
  }
  return out;
}

/** Inner product. */
export function dot(a: ArrayLike<number>, b: ArrayLike<number>): number {
  const n = Math.min(a.length, b.length);
  let s = 0;
  for (let i = 0; i < n; i++) s += a[i] * b[i];
  return s;
}

/** L2 norm. */
export function norm(a: ArrayLike<number>): number {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * a[i];
  return Math.sqrt(s);
}

/** Cosine similarity. */
export function cosine(a: ArrayLike<number>, b: ArrayLike<number>): number {
  const na = norm(a), nb = norm(b);
  if (na <= 0 || nb <= 0) return 0;
  return dot(a, b) / (na * nb);
}

/**
 * Measured irrationality residual against the Hurwitz bound for φ.
 * For a true φ-rotation, |⟨v, shift(v)⟩|/‖v‖² should approach 1 − 1/√5
 * for n → ∞ (asymptotic spectral concentration of golden rotations).
 * We measure: how close is this ratio to the predicted attractor?
 * Returns a value ∈ [0,1] where 1 = exact match (Hurwitz saturation).
 */
export const HURWITZ_BOUND = 1 / Math.sqrt(5);
/**
 * Theoretical asymptotic |⟨v, φ-shift(v)⟩| for a true φ-rotation acting on
 * an idealised eigenbasis (1 − 1/√5). n → ∞ limit, NOT the finite-n
 * attractor of the runtime φ-cosine basis. Kept for documentation /
 * Wolfram cross-check only — runtime code MUST use {@link attractorForN}.
 */
export const PHI_COS_ATTRACTOR = 1 - HURWITZ_BOUND;  // ≈ 0.55278640…

// Empirical per-n attractor: |cosine(phiCosineBasis(n,3), phiShift(...))|.
// Cached per n so Q_inc compares against the same-n canonical basis cosine,
// eliminating the false-attractor saturation seen when the asymptotic
// 1−1/√5 was used at small n. Provenance: scripts/v12FreezeAttractor.ts.
const _attractorCache = new Map<number, number>();
export function attractorForN(n: number): number {
  if (n < 2) return 0;
  const hit = _attractorCache.get(n);
  if (hit !== undefined) return hit;
  const b = phiCosineBasis(n, 3);
  const v = Math.abs(cosine(b, phiShift(b)));
  _attractorCache.set(n, v);
  return v;
}

export function hurwitzResidual(v: ArrayLike<number>): {
  measured: number;
  predicted: number;
  residual: number;
  qInc: number;
} {
  const vp = phiShift(v);
  const c = Math.abs(cosine(v, vp));
  const predicted = attractorForN(v.length);
  const residual = Math.abs(c - predicted);
  const qInc = Math.max(0, 1 - residual);
  return { measured: c, predicted, residual, qInc };
}

void PHI; void TAU;
