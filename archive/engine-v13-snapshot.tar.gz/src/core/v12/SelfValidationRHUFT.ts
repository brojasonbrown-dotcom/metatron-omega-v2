/**
 * SelfValidationRHUFT — unbiased structural validation.
 *
 * Predicts three closed-form fixed points from the RHUFT master equation
 * geometry alone (no Wolfram, no CODATA, no external anchor):
 *
 *   1. Fibonacci friction floor  → F* = 1/φ²   (Hurwitz ceiling → V = φ²)
 *   2. Torus recursion eigenvalue → λ_torus* = φ    (golden-scan step)
 *   3. Sphere-of-spheres closure → V_ceil* = φ²   (REVERSIBLE tier)
 *
 * For each prediction we compute:
 *   gap = |measured − predicted| / |predicted|
 *
 * `selfTruthScore` is the φ-weighted geometric mean of (1 − gap) across
 * all predictions with gap < 1. This is Metatron's honest structural
 * intelligence signal — high only when internal geometry reproduces its
 * own predicted fixed points.
 */

import { PHI } from '@/core/constants/WolframVerified';

export interface RHUFTMeasured {
  frictionFloor: number;     // observed F at STABLE-tier lock
  torusEigenvalue: number;   // dominant eigenvalue of goldenScan operator
  vCeiling: number;          // observed maximum V across recent history
}

export interface RHUFTPrediction {
  name: string;
  predicted: number;
  measured: number;
  gap: number;               // relative gap ∈ [0, ∞)
  verdict: 'STRUCTURALLY_VALID' | 'PARTIAL' | 'FRONTIER' | 'WEAK';
}

export interface RHUFTValidationReport {
  predictions: RHUFTPrediction[];
  selfTruthScore: number;    // ∈ [0,1]
  honestyVerdict: 'STRUCTURALLY_VALID' | 'PARTIAL' | 'WEAK';
}

const PHI_INV_SQ = 1 / (PHI * PHI);
const PHI_SQ = PHI * PHI;

function verdictFor(gap: number): RHUFTPrediction['verdict'] {
  if (!isFinite(gap)) return 'WEAK';
  if (gap < 0.02) return 'STRUCTURALLY_VALID';
  if (gap < 0.05) return 'PARTIAL';
  if (gap < 0.20) return 'FRONTIER';
  return 'WEAK';
}

function relativeGap(measured: number, predicted: number): number {
  const denom = Math.abs(predicted);
  if (denom < 1e-15) return Math.abs(measured);
  return Math.abs(measured - predicted) / denom;
}

export function validateRHUFT(m: RHUFTMeasured): RHUFTValidationReport {
  const predictions: RHUFTPrediction[] = [
    (() => {
      const gap = relativeGap(m.frictionFloor, PHI_INV_SQ);
      return { name: 'fibonacci_friction_floor', predicted: PHI_INV_SQ, measured: m.frictionFloor, gap, verdict: verdictFor(gap) };
    })(),
    (() => {
      const gap = relativeGap(m.torusEigenvalue, PHI);
      return { name: 'torus_eigenvalue', predicted: PHI, measured: m.torusEigenvalue, gap, verdict: verdictFor(gap) };
    })(),
    (() => {
      const gap = relativeGap(m.vCeiling, PHI_SQ);
      return { name: 'sphere_of_spheres_v_ceiling', predicted: PHI_SQ, measured: m.vCeiling, gap, verdict: verdictFor(gap) };
    })(),
  ];

  // φ-weighted geometric mean of (1 − min(gap, 1)).
  let logSum = 0, wSum = 0;
  predictions.forEach((p, i) => {
    const gapClamped = Math.min(1, Math.max(0, p.gap));
    const truth = Math.max(1e-6, 1 - gapClamped);
    const w = Math.pow(1 / PHI, i);
    logSum += w * Math.log(truth);
    wSum += w;
  });
  const selfTruthScore = wSum > 0 ? Math.exp(logSum / wSum) : 0;

  let honestyVerdict: RHUFTValidationReport['honestyVerdict'] = 'WEAK';
  const maxGap = Math.max(...predictions.map(p => p.gap));
  if (selfTruthScore >= 0.85 && maxGap < 0.02) honestyVerdict = 'STRUCTURALLY_VALID';
  else if (selfTruthScore >= 0.60) honestyVerdict = 'PARTIAL';

  return { predictions, selfTruthScore, honestyVerdict };
}
