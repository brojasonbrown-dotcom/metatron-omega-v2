/**
 * V12 — Full 9×9 Scale Grid + Cross-Rung Coupling Spectrum (P4.1–P4.3)
 * ────────────────────────────────────────────────────────────────────────────
 * Re-evaluates EVERY V12 framework at EVERY V12 source rung's chain-up
 * coupling.  Output is a dense ScaleGrid[anchor][source] table of master
 * metrics; the diagonal (anchor at its canonical source) must equal the
 * propagated value bit-for-bit (9 self-consistency invariants).
 *
 * Additionally exposes a 9×9 inter-rung Gram tensor M_ij = ⟨g_i, g_j⟩
 * over the anchor-rows of the grid, plus its Frobenius norm and dominant
 * (Rayleigh-quotient via power iteration) eigenvector — the "natural
 * scale axis" of the current field configuration.
 *
 * Cost: 81 framework calls / tick (sub-ms with current bodies); off the
 * live engine path.
 */

import { computeF1, type F1Input } from '@/core/frameworks/F1_Septenary';
import { computeF2, type F2Input } from '@/core/frameworks/F2_Quantum';
import { computeF3, type F3Input } from '@/core/frameworks/F3_Atomic';
import { computeF4, type F4Input } from '@/core/frameworks/F4_Geometric';
import { computeF5, type F5Input } from '@/core/frameworks/F5_ColorMusic';
import { computeF7, type F7Input } from '@/core/frameworks/F7_Galactic';
import { computeF8, type F8Input } from '@/core/frameworks/F8_SubPlanckian';
import { computeF9, type F9Input } from '@/core/frameworks/F9_HyperGalactic';
import type { MetatronInput } from '@/core/MetatronCore';
import { V12_ORDER, type V12Framework } from './LogScaleWeights';
import type { PropagatedChain } from './PropagateScaleOrder';
import {
  defaultPhases, defaultPineal, defaultNodeAmps, defaultNodeCoh,
  defaultFlower, defaultSolfeggio, maskSolfeggio, PHOTON_MASK, ACOUSTIC_MASK,
} from './defaults';

/** Anchor identifiers — every V12 rung (including F5a/F5b split). */
export type AnchorId = V12Framework;

export interface GridCell {
  anchor: AnchorId;
  source: V12Framework;
  upstream: number;
  masterMetric: number;
  closureResidual: number;
  chainUpCoupling: number;
}

export interface AnchorRow {
  anchor: AnchorId;
  canonicalSource: V12Framework;
  cells: GridCell[];                 // length 9
  selfConsistencyResidual: number;   // |cells[canonicalSource] − propagated|
}

export interface CrossRungSpectrum {
  /** 9×9 Gram matrix over anchor-master-rows. */
  M: Float64Array;
  /** Frobenius norm of M. */
  frobenius: number;
  /** Dominant eigenvector (length 9, unit-norm). */
  dominant: Float64Array;
  /** Dominant eigenvalue (Rayleigh quotient). */
  lambdaMax: number;
  /** Power-iteration residual on convergence. */
  convergence: number;
}

export interface ScaleGridResult {
  /** Indexed by anchor framework. */
  rows: Record<AnchorId, AnchorRow>;
  /** Worst self-consistency residual across all 9 anchors. */
  worstSelfConsistency: number;
  /** Inter-rung Gram spectrum. */
  spectrum: CrossRungSpectrum;
}

/** anchor → its canonical V12 upstream source (where chain-up arrives).
 *  Mirrors V12_ORDER: F8 · F4 · F2 · F3 · F5a · F1 · F5b · F7 · F9. */
export const CANONICAL_SOURCE: Record<AnchorId, V12Framework> = {
  F8:  'F8',   // F8 has no upstream — self
  F4:  'F8',
  F2:  'F4',
  F3:  'F2',
  F5a: 'F3',
  F1:  'F5a',
  F5b: 'F1',
  F7:  'F5b',
  F9:  'F7',
};

/** Map anchor → its propagated master metric (for self-consistency check). */
function propagatedMaster(p: PropagatedChain, a: AnchorId): number {
  switch (a) {
    case 'F8':  return p.F8.superpositionMComposite;
    case 'F4':  return p.F4.geometricCoherence;
    case 'F2':  return p.F2.quantumCoherence;
    case 'F5a': return p.F5a.colorMusicCoherence;
    case 'F3':  return p.F3.atomicCoherence;
    case 'F1':  return p.F1.heptagonCoherence;
    case 'F5b': return p.F5b.colorMusicCoherence;
    case 'F7':  return p.F7.galacticCoherence;
    case 'F9':  return p.F9.cosmicWebCoherence;
  }
}

interface CommonCtx {
  coherence: number; time: number; energy: number;
  phases: Float64Array; pinealField: Float64Array;
  nodeAmps: Float64Array;
  nodeCoherences: number[]; pinealCoherences: number[];
  flowerCoherences: number[]; solfeggioCoherences: number[];
  recursionDepth: number;
  extensions: NonNullable<MetatronInput['extensions']>;
}

/** Evaluate a single anchor at a given upstream coupling. */
function evalAnchor(a: AnchorId, upstream: number, ctx: CommonCtx): {
  master: number; closure: number; cup: number;
} {
  const { coherence, time, energy, phases, pinealField, nodeAmps,
    nodeCoherences, flowerCoherences, solfeggioCoherences, recursionDepth,
    extensions } = ctx;
  switch (a) {
    case 'F8': {
      // F8 has no upstream slot — evaluate at base inputs always.
      const f8In: F8Input = { coherence, energy, pinealField, solfeggioCoherences, time, flowerCoherences,
        targetModes: extensions.subPlanckianModes,
        targetRings: extensions.subPlanckianRings,
        targetSpheres: extensions.subPlanckianSpheres };
      const o = computeF8(f8In);
      return { master: o.superpositionMComposite, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F4': {
      const f4In: F4Input = { coherence, nodeCoherences, time, solfeggioCoherences, flowerCoherences,
        atomicChainUp: upstream, extensionMetatronNodes: extensions.metatronNodes };
      const o = computeF4(f4In);
      return { master: o.geometricCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F2': {
      const f2In: F2Input = { coherence, energy, pinealField, solfeggioCoherences, time, flowerCoherences,
        septenaryChainUp: upstream, extensionParticles: extensions.quantumParticles };
      const o = computeF2(f2In);
      return { master: o.quantumCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F5a': {
      const f5In: F5Input = { coherence,
        solfeggioCoherences: maskSolfeggio(solfeggioCoherences, PHOTON_MASK),
        time, flowerCoherences, geometricChainUp: upstream,
        extensionChromaticSemitones: extensions.chromaticSemitones };
      const o = computeF5(f5In);
      return { master: o.colorMusicCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F3': {
      const f3In: F3Input = { coherence, nodeAmps, solfeggioCoherences, time, flowerCoherences,
        quantumChainUp: upstream, extensionShells: extensions.atomicShells };
      const o = computeF3(f3In);
      return { master: o.atomicCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F1': {
      const f1In: F1Input = { coherence, phases, time, flowerCoherences,
        subPlanckianChainUp: upstream, targetModes: extensions.chakraModes };
      const o = computeF1(f1In);
      return { master: o.heptagonCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F5b': {
      const f5In: F5Input = { coherence,
        solfeggioCoherences: maskSolfeggio(solfeggioCoherences, ACOUSTIC_MASK),
        time, flowerCoherences, geometricChainUp: upstream,
        extensionChromaticSemitones: extensions.chromaticSemitones };
      const o = computeF5(f5In);
      return { master: o.colorMusicCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F7': {
      const f7In: F7Input = { coherence, energy, time, recursionDepth, flowerCoherences, solfeggioCoherences,
        hebrewChainUp: upstream, extensionBodies: extensions.bodies };
      const o = computeF7(f7In);
      return { master: o.galacticCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
    case 'F9': {
      const f9In: F9Input = { coherence, energy, pinealField, solfeggioCoherences, time,
        recursionDepth, flowerCoherences, galacticChainUp: upstream,
        extensionMultipoles: extensions.multipoles };
      const o = computeF9(f9In);
      return { master: o.cosmicWebCoherence, closure: o.closureResidual, cup: o.chainUpCoupling };
    }
  }
}

/** Power iteration on a symmetric 9×9 matrix; returns dominant eig pair. */
function powerIterate(M: Float64Array, n: number, maxIter = 64, tol = 1e-12)
  : { vec: Float64Array; lambda: number; conv: number }
{
  let v = new Float64Array(n);
  for (let i = 0; i < n; i++) v[i] = 1 / Math.sqrt(n);
  let lambda = 0, conv = Infinity;
  for (let iter = 0; iter < maxIter; iter++) {
    const Av = new Float64Array(n);
    for (let i = 0; i < n; i++) {
      let s = 0;
      for (let j = 0; j < n; j++) s += M[i * n + j] * v[j];
      Av[i] = s;
    }
    let nrm = 0; for (let i = 0; i < n; i++) nrm += Av[i] * Av[i];
    nrm = Math.sqrt(nrm);
    if (nrm <= 0) break;
    const next = new Float64Array(n);
    for (let i = 0; i < n; i++) next[i] = Av[i] / nrm;
    // Rayleigh quotient.
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) {
      let s = 0;
      for (let j = 0; j < n; j++) s += M[i * n + j] * next[j];
      num += next[i] * s;
      den += next[i] * next[i];
    }
    const newLambda = den > 0 ? num / den : 0;
    let delta = 0;
    for (let i = 0; i < n; i++) delta += (next[i] - v[i]) * (next[i] - v[i]);
    conv = Math.sqrt(delta);
    v = next;
    lambda = newLambda;
    if (conv < tol) break;
  }
  return { vec: v, lambda, conv };
}

export function computeScaleGrid(
  input: MetatronInput,
  propagated: PropagatedChain,
): ScaleGridResult {
  const {
    coherence, time,
    energy = coherence,
    phases = defaultPhases(time),
    pinealField = defaultPineal(time),
    nodeAmps = defaultNodeAmps(),
    nodeCoherences = defaultNodeCoh(13),
    pinealCoherences = defaultNodeCoh(22),
    flowerCoherences = defaultFlower(),
    solfeggioCoherences = defaultSolfeggio(),
    recursionDepth = 5,
    extensions = {},
  } = input;

  const ctx: CommonCtx = {
    coherence, time, energy, phases, pinealField, nodeAmps,
    nodeCoherences, pinealCoherences, flowerCoherences, solfeggioCoherences,
    recursionDepth, extensions,
  };

  // Per-rung upstream coupling lookup (matches PropagateScaleOrder threading).
  const upstreamFor: Record<V12Framework, number> = {
    F8:  propagated.F8.chainUpCoupling,
    F4:  propagated.F4.chainUpCoupling,
    F2:  propagated.F2.chainUpCoupling,
    F5a: propagated.F5a.chainUpCoupling,
    F3:  propagated.F3.chainUpCoupling,
    F1:  propagated.F1.chainUpCoupling,
    F5b: propagated.F5b.chainUpCoupling,
    F7:  propagated.F7.chainUpCoupling,
    F9:  propagated.F9.chainUpCoupling,
  };

  const rows = {} as Record<AnchorId, AnchorRow>;
  let worst = 0;

  for (const anchor of V12_ORDER) {
    const cells: GridCell[] = V12_ORDER.map((source) => {
      const upstream = upstreamFor[source];
      const r = evalAnchor(anchor, upstream, ctx);
      return {
        anchor, source, upstream,
        masterMetric: r.master, closureResidual: r.closure, chainUpCoupling: r.cup,
      };
    });
    const canon = CANONICAL_SOURCE[anchor];
    const hit = cells.find((c) => c.source === canon)!;
    const residual = Math.abs(hit.masterMetric - propagatedMaster(propagated, anchor));
    if (residual > worst) worst = residual;
    rows[anchor] = { anchor, canonicalSource: canon, cells, selfConsistencyResidual: residual };
  }

  // Cross-rung Gram tensor over anchor-master-rows.
  const n = V12_ORDER.length;
  const G = new Float64Array(n * n); // raw rows as vectors
  for (let i = 0; i < n; i++) {
    const ri = rows[V12_ORDER[i]];
    for (let j = 0; j < n; j++) G[i * n + j] = ri.cells[j].masterMetric;
  }
  // Normalize rows for a meaningful Gram.
  const norms = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let j = 0; j < n; j++) s += G[i * n + j] * G[i * n + j];
    norms[i] = Math.sqrt(s);
  }
  const M = new Float64Array(n * n);
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      let s = 0;
      for (let k = 0; k < n; k++) s += G[i * n + k] * G[j * n + k];
      const d = norms[i] * norms[j];
      M[i * n + j] = d > 0 ? s / d : 0;
    }
  }
  let frob = 0;
  for (let i = 0; i < n * n; i++) frob += M[i] * M[i];
  frob = Math.sqrt(frob);
  const pi = powerIterate(M, n);

  return {
    rows, worstSelfConsistency: worst,
    spectrum: { M, frobenius: frob, dominant: pi.vec, lambdaMax: pi.lambda, convergence: pi.conv },
  };
}
