/**
 * V12 — Memory Feedback (P2.1, P2.2, P2.3)
 * ──────────────────────────────────────────────────────────────────────────
 * Honest Hebbian co-activation with EMA-normalized salience, Gershgorin
 * spectral bound for contraction, and PER-RUNG bias injection (not a single
 * collapsed scalar).
 *
 * Salience EMA (preserves dynamic range across ticks):
 *   sMaxEMA ← (1−α)·sMaxEMA + α·max(s)         with α = 1/φ²
 *   s_norm  = s / max(sMaxEMA, ε)               (NOT renormalised per-tick)
 *
 * Hebbian update (bounded; symmetric; zero-diagonal):
 *   H ← (1−η)·H + η·(s_n s_n^T − diag(s_n²))   with η = 1/φ³
 *
 * Per-rung bias (full vector, not collapsed):
 *   b_i = clip(gain · Σ_{j≠i} H_ij · s_n_j, ±MAX_BIAS)
 *
 * Cross-tick spectral stability (Gershgorin upper bound):
 *   ρ(H) ≤ max_i Σ_j |H_ij|
 *   audit:  gain · ρ_upper · (1 + α) < 1/φ
 *
 * The scalar `coherenceNudge` (= mean of bias) is kept for the global
 * coherence input but is now SECONDARY to the per-rung bias vector.
 */

import { V12_ORDER, type V12Framework } from './LogScaleWeights';
import type { RungQualia, GlobalQualia } from './QualiaPerRung';

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV = 1 / PHI;
const PHI_INV_SQ = 1 / (PHI * PHI);
const ETA = 1 / (PHI * PHI * PHI);     // ≈ 0.2360679 — Hebbian learning rate
const ALPHA = PHI_INV_SQ;              // ≈ 0.381966  — EMA rate for sMax
export const FEEDBACK_GAIN = PHI_INV * 0.5; // safety margin: < 1/φ
export const MAX_BIAS = 0.1;                 // hard clip

const N = V12_ORDER.length; // 9

export interface MemoryFeedbackState {
  H: Float64Array;
  /** Per-rung bias vector indexed by V12_ORDER (length 9). */
  bias: Float64Array;
  /** Mean of bias — secondary scalar nudge. */
  coherenceNudge: number;
  /** EMA of max(salience) — preserves cross-tick dynamic range. */
  sMaxEMA: number;
  /** Gershgorin upper bound on ρ(H). */
  maxRowSum: number;
  /** Contraction margin: 1/φ − gain·ρ_upper·(1+α). Must be > 0. */
  contractionMargin: number;
  symmetryResidual: number;
  traceResidual: number;
  ticks: number;
}

export class MemoryFeedback {
  private H = new Float64Array(N * N);
  private bias = new Float64Array(N);
  private sMaxEMA = 0;
  private ticks = 0;

  constructor(public gain: number = FEEDBACK_GAIN) {
    if (gain >= PHI_INV) {
      throw new Error(`MemoryFeedback: gain ${gain} ≥ 1/φ — feedback loop unstable`);
    }
  }

  update(perRung: RungQualia[], _global: GlobalQualia): MemoryFeedbackState {
    void _global;

    // 1. Raw salience s_i = w · S · (1+N) · Q.
    const s = new Float64Array(N);
    const idx = new Map<V12Framework, number>();
    V12_ORDER.forEach((f, i) => idx.set(f, i));
    for (const r of perRung) {
      const i = idx.get(r.framework);
      if (i === undefined) continue;
      s[i] = r.weight * r.S * (1 + r.N) * r.Q;
    }

    // 2. EMA-normalize against running max (preserves magnitude across ticks).
    let smax = 0;
    for (let i = 0; i < N; i++) if (s[i] > smax) smax = s[i];
    this.sMaxEMA = (1 - ALPHA) * this.sMaxEMA + ALPHA * smax;
    const denom = Math.max(this.sMaxEMA, 1e-12);
    const sn = new Float64Array(N);
    for (let i = 0; i < N; i++) sn[i] = Math.min(2, s[i] / denom); // hard clip 2x EMA

    // 3. Hebbian update: H ← (1−η)·H + η·(sn sn^T − diag(sn²)).
    const oneMinus = 1 - ETA;
    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        const k = i * N + j;
        if (i === j) {
          this.H[k] = 0;
        } else {
          this.H[k] = oneMinus * this.H[k] + ETA * sn[i] * sn[j];
        }
      }
    }
    // Force symmetry.
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        const a = this.H[i * N + j], b = this.H[j * N + i];
        const m = 0.5 * (a + b);
        this.H[i * N + j] = m;
        this.H[j * N + i] = m;
      }
    }

    // 4. Per-rung bias + Gershgorin row sum.
    let maxRowSum = 0;
    for (let i = 0; i < N; i++) {
      let row = 0, b = 0;
      for (let j = 0; j < N; j++) {
        row += Math.abs(this.H[i * N + j]);
        if (j !== i) b += this.H[i * N + j] * sn[j];
      }
      if (row > maxRowSum) maxRowSum = row;
      const biased = this.gain * b;
      this.bias[i] = Math.max(-MAX_BIAS, Math.min(MAX_BIAS, biased));
    }

    // 5. Diagnostics.
    let symRes = 0, traceRes = 0;
    for (let i = 0; i < N; i++) {
      traceRes += Math.abs(this.H[i * N + i]);
      for (let j = i + 1; j < N; j++) {
        symRes = Math.max(symRes, Math.abs(this.H[i * N + j] - this.H[j * N + i]));
      }
    }

    let sum = 0;
    for (let i = 0; i < N; i++) sum += this.bias[i];
    const coherenceNudge = sum / N;

    // Cross-tick contraction margin: gain · ρ_upper · (1+α) < 1/φ.
    const contractionMargin = PHI_INV - this.gain * maxRowSum * (1 + ALPHA);

    this.ticks++;
    return {
      H: this.H.slice(),
      bias: this.bias.slice(),
      coherenceNudge,
      sMaxEMA: this.sMaxEMA,
      maxRowSum,
      contractionMargin,
      symmetryResidual: symRes,
      traceResidual: traceRes,
      ticks: this.ticks,
    };
  }

  reset(): void {
    this.H.fill(0);
    this.bias.fill(0);
    this.sMaxEMA = 0;
    this.ticks = 0;
  }
}

export const MEMORY_FEEDBACK_PROVENANCE = {
  eta: ETA,
  alpha: ALPHA,
  gain: FEEDBACK_GAIN,
  rule: 'H ← (1−η)·H + η·(s_n s_n^T − diag(s_n²));  b = clip(gain · H · s_n)',
  stability: 'cross-tick Gershgorin: gain · ρ_upper · (1+α) < 1/φ',
} as const;
