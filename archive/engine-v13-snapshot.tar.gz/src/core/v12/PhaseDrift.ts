/**
 * PhaseDrift — deviation of an actual recursive state Ψ_t from an ideal /
 * frictionless attractor Ψ̂_t. Canonical form: RHUFT §00_thesis_v2 Ch. 8.
 *
 *   d_t   = ‖ Ψ_{t+1} − Ψ̂_{t+1} ‖² / N          [FORMAL, Ch. 8]
 *   δφ_t  = 1 − cos∠(Ψ_{t+1}, Ψ̂_{t+1})           [FORMAL, phase-metric variant]
 *   ξ_t   = | 1 − ‖Ψ‖ / ‖Ψ̂‖ |                    [FORMAL, closure-defect proxy]
 *   ℓ_t   = α·d_t + β·δφ_t + γ·ξ_t                [FORMAL, Ch. 8 friction sum]
 *
 * The *choice* of ideal predictor Ψ̂_t is not fixed by the thesis. Two
 * predictors are provided; both are [SIMULATION]-tagged conveniences, not
 * formal derivations:
 *
 *   • persistencePredictor(Ψ_t)                — Ψ̂ := α·Ψ_t   (α from
 *     MasterUpdate weights). Cheapest, framework-agnostic baseline.
 *   • suppliedPredictor(Ψ̂)                    — caller supplies Ψ̂ from any
 *     source (e.g. MasterUpdate output with noise terms zeroed, a golden
 *     trace, or a Wolfram-derived reference).
 *
 * This module is PURE and READ-ONLY: it never mutates engine state, never
 * touches workers, and has no side effects. Import it from any diagnostic
 * panel or CI check. Not wired into the hot path — wiring is a separate,
 * reversible decision.
 *
 * Scale weighting (the "density of the field" the user described): callers
 * that want a burden-weighted ℓ across scales can multiply per-scale ℓ_t by
 * their own density proxy (ρ, memory occupancy, stabilization cost) before
 * summing. That aggregation belongs to the caller, not this module — because
 * the correct weight depends on what the caller is measuring (matter,
 * information, cognition, planetary structure — Ch. 11).
 */

import { DEFAULT_WEIGHTS, type MasterWeights } from '@/core/v12/MasterUpdate';

export interface PhaseDriftWeights {
  /** weight on squared distance d_t */
  a: number;
  /** weight on phase deviation δφ_t */
  b: number;
  /** weight on closure defect ξ_t */
  g: number;
}

export const DEFAULT_DRIFT_WEIGHTS: PhaseDriftWeights = Object.freeze({
  a: 1 / 3,
  b: 1 / 3,
  g: 1 / 3,
});

export interface PhaseDriftMetrics {
  /** ‖Ψ − Ψ̂‖² / N — mean-squared drift (unit-agnostic). */
  d: number;
  /** 1 − cos∠(Ψ, Ψ̂) ∈ [0, 2]; 0 = perfect phase alignment. */
  deltaPhi: number;
  /** |1 − ‖Ψ‖ / ‖Ψ̂‖| — closure defect; 0 = magnitude-matched. */
  xi: number;
  /** Composite friction ℓ = a·d + b·δφ + g·ξ. */
  ell: number;
  /** ‖Ψ‖₂ — magnitude of actual state. */
  psiNorm: number;
  /** ‖Ψ̂‖₂ — magnitude of ideal state. */
  psiHatNorm: number;
  /** Vector length N (for downstream scale aggregation). */
  n: number;
}

/**
 * Persistence-predictor: Ψ̂ := α·Ψ, where α is the MasterUpdate decay.
 * This is the *simplest* frictionless prediction — "if nothing new happened,
 * what would Ψ be next tick?" [SIMULATION]-tagged: it is a baseline, not a
 * thesis-derived attractor. Callers with a stronger predictor (e.g. golden
 * trace, MasterUpdate no-noise projection) should pass it directly.
 */
export function persistencePredictor(
  psi: Float64Array,
  out: Float64Array,
  weights: Partial<MasterWeights> = {},
): void {
  const alpha = weights.alpha ?? DEFAULT_WEIGHTS.alpha;
  const n = psi.length;
  if (out.length !== n) throw new Error('persistencePredictor: length mismatch');
  for (let i = 0; i < n; i++) out[i] = alpha * psi[i];
}

/**
 * Core drift computation. Both Ψ and Ψ̂ must be the same length. Uses
 * compensated single-pass accumulation for numerical stability at large N.
 * All finite; NaN inputs produce NaN outputs (caller's responsibility).
 */
export function phaseDrift(
  psi: Float64Array,
  psiHat: Float64Array,
  weights: PhaseDriftWeights = DEFAULT_DRIFT_WEIGHTS,
): PhaseDriftMetrics {
  const n = psi.length;
  if (psiHat.length !== n) throw new Error('phaseDrift: length mismatch');

  let sumSqDiff = 0;
  let dot = 0;
  let sqA = 0;
  let sqB = 0;

  for (let i = 0; i < n; i++) {
    const a = psi[i];
    const b = psiHat[i];
    const diff = a - b;
    sumSqDiff += diff * diff;
    dot += a * b;
    sqA += a * a;
    sqB += b * b;
  }

  const psiNorm = Math.sqrt(sqA);
  const psiHatNorm = Math.sqrt(sqB);
  const d = n > 0 ? sumSqDiff / n : 0;

  // Phase deviation via cosine similarity. Degenerate cases (either norm 0)
  // produce δφ = 0 by convention — no defined angle, so no measurable drift.
  const denom = psiNorm * psiHatNorm;
  const cosSim = denom > 1e-300 ? dot / denom : 1;
  // Clamp before subtraction to defend against 1 + 1e-16 rounding.
  const clamped = cosSim > 1 ? 1 : cosSim < -1 ? -1 : cosSim;
  const deltaPhi = 1 - clamped;

  const xi = psiHatNorm > 1e-300 ? Math.abs(1 - psiNorm / psiHatNorm) : 0;

  const ell = weights.a * d + weights.b * deltaPhi + weights.g * xi;

  return { d, deltaPhi, xi, ell, psiNorm, psiHatNorm, n };
}

/**
 * Convenience: measure drift against the persistence predictor in one call.
 * Allocates a scratch buffer of length N. For hot-path use, pre-allocate
 * and call persistencePredictor + phaseDrift directly to avoid GC pressure.
 */
export function phaseDriftFromPersistence(
  psi: Float64Array,
  masterWeights: Partial<MasterWeights> = {},
  driftWeights: PhaseDriftWeights = DEFAULT_DRIFT_WEIGHTS,
): PhaseDriftMetrics {
  const hat = new Float64Array(psi.length);
  persistencePredictor(psi, hat, masterWeights);
  return phaseDrift(psi, hat, driftWeights);
}

/**
 * Multiscale friction aggregator. Given per-scale drift metrics and per-scale
 * density/burden weights (caller-supplied), returns:
 *
 *   ℓ̄  = Σ w_n · ℓ_n  /  Σ w_n         weighted mean friction
 *   ℓ_max, ℓ_argmax                      worst offending scale (and its index)
 *
 * This is the aggregation Ch. 11 describes but does not prescribe — the
 * weight vector is the free parameter that encodes *what* is being measured
 * (matter density, memory occupancy, prediction cost, ...). Kept separate
 * from `phaseDrift` so per-scale results remain interpretable on their own.
 */
export interface MultiscaleFriction {
  meanEll: number;
  maxEll: number;
  argMax: number;
  totalWeight: number;
}

export function aggregateMultiscaleFriction(
  perScale: readonly PhaseDriftMetrics[],
  weights: readonly number[],
): MultiscaleFriction {
  if (perScale.length !== weights.length) {
    throw new Error('aggregateMultiscaleFriction: length mismatch');
  }
  let wSum = 0;
  let wEll = 0;
  let maxEll = -Infinity;
  let argMax = -1;
  for (let i = 0; i < perScale.length; i++) {
    const w = weights[i];
    const ell = perScale[i].ell;
    if (w > 0 && Number.isFinite(ell)) {
      wSum += w;
      wEll += w * ell;
    }
    if (ell > maxEll) {
      maxEll = ell;
      argMax = i;
    }
  }
  return {
    meanEll: wSum > 0 ? wEll / wSum : 0,
    maxEll: maxEll === -Infinity ? 0 : maxEll,
    argMax,
    totalWeight: wSum,
  };
}
