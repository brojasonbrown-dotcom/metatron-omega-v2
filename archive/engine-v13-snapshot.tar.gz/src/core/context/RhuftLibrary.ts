/**
 * RhuftLibrary — read-only access to ingested RHUFT chapters.
 *
 * Provides chapter retrieval as pure addressable memory. No behavioral rules,
 * no output shaping — it merely surfaces structured documents (front-matter +
 * body) so any consumer (LLM glue, diagnostics, UI) can reason from grounded
 * source material instead of speculation.
 *
 * The corpus is bundled at build time via Vite's `import.meta.glob` so the
 * library works in both Node (parity script) and the browser (preview).
 */

const RAW_MODULES = import.meta.glob('../../context/rhuft/*.md', {
  eager: true,
  query: '?raw',
  import: 'default',
}) as Record<string, string>;

export type ChapterScope = 'concept' | 'derivation' | 'phenomenon' | 'tech';
export type ChapterConfidence = 'derivation' | 'empirical' | 'unvalidated';

export interface ChapterFrontMatter {
  id: string;
  scope: ChapterScope;
  confidence: ChapterConfidence;
  source: string;
}

export interface Chapter {
  id: string;
  frontMatter: ChapterFrontMatter;
  body: string;
  raw: string;
}

function parseFrontMatter(raw: string): { fm: Partial<ChapterFrontMatter>; body: string } {
  const m = raw.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
  if (!m) return { fm: {}, body: raw };
  const fm: Record<string, string> = {};
  for (const line of m[1].split('\n')) {
    const kv = line.match(/^(\w+):\s*(.*)$/);
    if (kv) fm[kv[1]] = kv[2].trim();
  }
  return { fm: fm as Partial<ChapterFrontMatter>, body: m[2] };
}

const CHAPTERS: Chapter[] = Object.entries(RAW_MODULES)
  .map(([path, raw]) => {
    const id = path.split('/').pop()!.replace(/\.md$/, '');
    const { fm, body } = parseFrontMatter(raw);
    return {
      id,
      frontMatter: {
        id: fm.id ?? id,
        scope: (fm.scope as ChapterScope) ?? 'concept',
        confidence: (fm.confidence as ChapterConfidence) ?? 'unvalidated',
        source: fm.source ?? 'rhuft',
      },
      body,
      raw,
    };
  })
  .sort((a, b) => a.id.localeCompare(b.id));

const BY_ID = new Map(CHAPTERS.map((c) => [c.id, c]));

export function listChapters(): Chapter[] {
  return CHAPTERS.slice();
}

export function getChapter(id: string): Chapter | undefined {
  return BY_ID.get(id);
}

export function searchChapters(query: string): Chapter[] {
  const q = query.toLowerCase().trim();
  if (!q) return [];
  return CHAPTERS.filter(
    (c) => c.id.toLowerCase().includes(q) || c.body.toLowerCase().includes(q),
  );
}

export function chapterCount(): number {
  return CHAPTERS.length;
}
