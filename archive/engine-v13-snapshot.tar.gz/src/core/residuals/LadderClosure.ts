/**
 * LadderClosure — Wolfram-grade five-axis identity audit.
 *
 * Ported from vendor/v10-reference/src/engine/v10/LadderClosure.ts and
 * adapted to V11's `WolframVerified` bank. Each axis is a different unit
 * measuring the same φ-self-similar identity. All five must agree up to
 * floating-point round-off (~1e-12) because they are restatements of the
 * same equation in different bases:
 *
 *   φ² = φ + 1                       (golden recurrence)
 *   φ · φ⁻¹ = 1                      (inversion identity)
 *   φ⁻¹ + φ⁻² = 1                    (continued-fraction identity)
 *   κ · φ · π = 1                    (engine closure constant)
 *   Ω_c · φ² = 1                     (crystalline coherence threshold)
 *
 * Pure derivation from the constant bank — no engine state, no I/O.
 * Consumed by the Reality-Drift panel and the AI snapshot helper.
 */

import {
  PHI, PHI_INV, PHI_SQ, KAPPA, PI, OMEGA_C,
} from '@/core/constants/WolframVerified';

export type ClosureGrade = 'IDENTITY' | 'EXCELLENT' | 'GOOD' | 'DRIFTING';

export interface AxisClosure {
  /** Human label. */
  axis: string;
  /** What the identity restates symbolically. */
  identity: string;
  /** Closed-form expected value. */
  expected: number;
  /** Value recomputed from the live constant bank. */
  recomputed: number;
  /** |expected − recomputed| / max(|expected|, 1e-30). */
  relativeDrift: number;
  /** Audit grade. */
  grade: ClosureGrade;
}

const gradeOf = (d: number): ClosureGrade => {
  if (d < 1e-12) return 'IDENTITY';
  if (d < 1e-6)  return 'EXCELLENT';
  if (d < 1e-3)  return 'GOOD';
  return 'DRIFTING';
};

function audit(axis: string, identity: string, expected: number, recomputed: number): AxisClosure {
  const relativeDrift = Math.abs(expected - recomputed) / Math.max(Math.abs(expected), 1e-30);
  return { axis, identity, expected, recomputed, relativeDrift, grade: gradeOf(relativeDrift) };
}

export interface LadderClosureReport {
  axes: AxisClosure[];
  worstDrift: number;
  meanDrift: number;
  overallGrade: ClosureGrade;
}

/**
 * Run the full five-axis identity audit. Pure function; result is cached
 * once at module load because every input is a compile-time constant from
 * the WolframVerified bank — re-running per render burned cycles for an
 * answer that cannot change without a constants edit (which already triggers
 * a full rebuild).
 */
function computeLadderClosureAudit(): LadderClosureReport {
  const axes: AxisClosure[] = [
    audit('φ²',     'φ² = φ + 1',         PHI_SQ,        PHI + 1),
    audit('φ⁻¹',    'φ · φ⁻¹ = 1',        1,             PHI * PHI_INV),
    audit('φ⁻²',    'φ⁻¹ + φ⁻² = 1',      1,             PHI_INV + PHI_INV * PHI_INV),
    audit('κ',      'κ · φ · π = 1',      1,             KAPPA * PHI * PI),
    audit('Ω_c',    'Ω_c · φ² = 1',       1,             OMEGA_C * PHI_SQ),
  ];

  const drifts = axes.map(a => a.relativeDrift);
  const worstDrift = Math.max(...drifts);
  const meanDrift  = drifts.reduce((s, d) => s + d, 0) / drifts.length;
  const order: ClosureGrade[] = ['IDENTITY', 'EXCELLENT', 'GOOD', 'DRIFTING'];
  const overallGrade = axes.reduce<ClosureGrade>(
    (worst, a) => (order.indexOf(a.grade) > order.indexOf(worst) ? a.grade : worst),
    'IDENTITY',
  );

  return { axes, worstDrift, meanDrift, overallGrade };
}

const LADDER_CLOSURE_CACHED: LadderClosureReport = computeLadderClosureAudit();

/** Cached five-axis identity audit. Safe to call at any frequency. */
export function ladderClosureAudit(): LadderClosureReport {
  return LADDER_CLOSURE_CACHED;
}
