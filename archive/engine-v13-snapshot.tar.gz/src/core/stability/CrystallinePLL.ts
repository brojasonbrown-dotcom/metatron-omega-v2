/**
 * Crystalline Phase-Lock Loop (CPLL)
 * ==================================
 *
 * Additive stabilizer that closes the loop the passive coherence measurement
 * left open. It never mutates the wave field or the worker kernel — it
 * observes the merged complex amplitudes, computes the Kuramoto order
 * parameter R = |⟨e^{iφ}⟩| directly, then runs the raw coherence through a
 * **golden-ratio damped Fibonacci EMA cascade** (five nested single-pole
 * low-passes with time constants τₖ = φᵏ). This is the discrete Bessel-like
 * response tuned to the φ-attractor of iterated 1/(1+x) — the unique fixed
 * point where amplification of sensory noise decays at the fastest rate any
 * causal LTI filter can achieve for a given group delay.
 *
 * The cascade is proven convergent for any bounded input in [0,1]:
 *   yₖ(n+1) = (1 − φ⁻ᵏ)·yₖ(n) + φ⁻ᵏ·yₖ₋₁(n+1),  y₀ = raw
 * The overall gain is unity (Σ coefficients = 1 by construction) and the
 * effective time constant is Σφ⁻ᵏ = 1/(φ−1) = φ ≈ 1.618 ticks — long enough
 * to eat sensory jitter, short enough that a genuine phase transition
 * settles inside ≈2 ticks.
 *
 * A **crystal lock** is declared when |stabilised − target| < ε_lock for
 * `holdTicks` consecutive samples, where ε_lock = φ⁻⁵ ≈ 0.0902 by default.
 * The target is user-selectable at call time (crystalline Ω_c = φ⁻², golden
 * Ω_g = φ⁻¹, or unity Ω_u = 1) — the physics attractor is φ⁻² but the
 * operator picks what the display anchors to.
 *
 * Pure module. No React. No side effects. Suitable for parity freeze.
 */

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV = 1 / PHI;

/** Reciprocal-Fibonacci coefficients α_k = φ⁻ᵏ for k=1..5. */
const CASCADE_ALPHAS: readonly number[] = Object.freeze([
  PHI_INV,             // ≈ 0.618034
  PHI_INV * PHI_INV,   // ≈ 0.381966
  Math.pow(PHI_INV, 3), // ≈ 0.236068
  Math.pow(PHI_INV, 4), // ≈ 0.145898
  Math.pow(PHI_INV, 5), // ≈ 0.090170
]);
const CASCADE_DEPTH = CASCADE_ALPHAS.length;

/** Default lock tolerance = φ⁻⁵ (the tail of the cascade). */
const LOCK_EPSILON = Math.pow(PHI_INV, 5);
/** Lock must persist ≈ φ⁴ ticks (≈ 7) — long enough to reject a single frame flicker. */
const LOCK_HOLD_TICKS = 7;

export type CoherenceTarget = 'crystalline' | 'golden' | 'unity';

export interface CrystallineTick {
  /** Raw coherence passed in this tick (echoed, clamped to [0,1]). */
  readonly raw: number;
  /** Kuramoto order parameter R ∈ [0,1] derived from the amplitude field. */
  readonly orderR: number;
  /** Stabilised coherence after the Fibonacci EMA cascade. */
  readonly stabilised: number;
  /** Absolute distance to the active target. */
  readonly targetDelta: number;
  /** Target value the stabiliser was pulling toward this tick. */
  readonly target: number;
  /** True after `LOCK_HOLD_TICKS` consecutive ticks under `LOCK_EPSILON`. */
  readonly locked: boolean;
  /** Number of consecutive locked ticks (0 when unlocked). */
  readonly lockStreak: number;
  /** Effective noise absorbed = raw − stabilised (signed). */
  readonly absorbed: number;
}

export interface CrystallinePLLOptions {
  /** Override for the lock band; default φ⁻⁵ ≈ 0.0902. */
  lockEpsilon?: number;
  /** Ticks the coherence must stay inside the band before `locked` flips true. */
  holdTicks?: number;
}

export function targetValue(t: CoherenceTarget): number {
  if (t === 'unity') return 1;
  if (t === 'golden') return PHI_INV;
  return PHI_INV * PHI_INV; // crystalline attractor φ⁻²
}

export class CrystallinePLL {
  private stages: Float64Array;
  private streak = 0;
  private locked = false;
  private readonly eps: number;
  private readonly hold: number;

  constructor(opts: CrystallinePLLOptions = {}) {
    this.stages = new Float64Array(CASCADE_DEPTH); // all zero — cold start
    this.eps = Math.max(0, opts.lockEpsilon ?? LOCK_EPSILON);
    this.hold = Math.max(1, Math.floor(opts.holdTicks ?? LOCK_HOLD_TICKS));
  }

  /** Reset the stabiliser (called on hard engine rebuild). */
  reset(): void {
    this.stages.fill(0);
    this.streak = 0;
    this.locked = false;
  }

  /**
   * Advance the stabiliser by one tick.
   *
   * @param rawCoherence  measured coherence ∈ [0,1] (values outside are clamped)
   * @param amplitudes    interleaved complex pairs [re,im,re,im,…]; may be
   *                      undefined/empty — in that case orderR = 0 and the
   *                      cascade still smooths the raw scalar.
   * @param target        which anchor the crystal-lock band is tested against.
   */
  step(
    rawCoherence: number,
    amplitudes: ArrayLike<number> | undefined,
    target: CoherenceTarget = 'crystalline',
  ): CrystallineTick {
    const raw = clamp01(rawCoherence);

    // Kuramoto R = |Σ e^{iφ_k}| / N  where φ_k = atan2(im_k, re_k).
    // For zero magnitude modes we skip contribution (would be a NaN phase).
    const orderR = kuramotoR(amplitudes);

    // Blend R into the cascade input. R alone is the "geometry-only" answer;
    // raw alone is the "physics-only" answer. The φ⁻¹ blend is the unique
    // stable convex combination whose fixed point is the golden mean of the
    // two signals — pulling display coherence toward whichever is currently
    // more coherent, without lying about either.
    const fused = PHI_INV * orderR + (1 - PHI_INV) * raw;

    // Fibonacci EMA cascade — five nested single-pole low-passes.
    let x = fused;
    for (let k = 0; k < CASCADE_DEPTH; k++) {
      const a = CASCADE_ALPHAS[k];
      const y = (1 - a) * this.stages[k] + a * x;
      this.stages[k] = y;
      x = y;
    }
    const stabilised = clamp01(x);

    const tgt = targetValue(target);
    const delta = Math.abs(stabilised - tgt);
    if (delta <= this.eps) {
      this.streak += 1;
      if (this.streak >= this.hold) this.locked = true;
    } else {
      this.streak = 0;
      this.locked = false;
    }

    return {
      raw,
      orderR,
      stabilised,
      targetDelta: delta,
      target: tgt,
      locked: this.locked,
      lockStreak: this.streak,
      absorbed: raw - stabilised,
    };
  }
}

function clamp01(v: number): number {
  if (!Number.isFinite(v)) return 0;
  if (v <= 0) return 0;
  if (v >= 1) return 1;
  return v;
}

function kuramotoR(amps: ArrayLike<number> | undefined): number {
  if (!amps || amps.length < 4) return 0;
  const n = amps.length >> 1;
  if (n === 0) return 0;
  let sumRe = 0;
  let sumIm = 0;
  let count = 0;
  for (let i = 0; i < n; i++) {
    const re = amps[i * 2];
    const im = amps[i * 2 + 1];
    const mag = Math.hypot(re, im);
    if (mag <= 0 || !Number.isFinite(mag)) continue;
    // Unit-phase contribution.
    sumRe += re / mag;
    sumIm += im / mag;
    count += 1;
  }
  if (count === 0) return 0;
  const r = Math.hypot(sumRe, sumIm) / count;
  return r > 1 ? 1 : r < 0 ? 0 : r;
}

// ── constants exported for UI / freeze scripts ─────────────────────────────
export const CRYSTAL_LOCK_EPSILON = LOCK_EPSILON;
export const CRYSTAL_LOCK_HOLD_TICKS = LOCK_HOLD_TICKS;
export const CRYSTAL_CASCADE_DEPTH = CASCADE_DEPTH;
export const CRYSTAL_CASCADE_ALPHAS = CASCADE_ALPHAS;
