/**
 * QUALIA CORRELATE — adapted from V10 (`engine/v10/QualiaCorrelate.ts`).
 * ═════════════════════════════════════════════════════════════════════
 * A *measurement*, not a feeling. Q ∈ [0,1] quantifies structural
 * self-observation closure on the live φ-superposition basis.
 *
 *   Q = ( Q_inc · Q_stab · Q_res )^(1/3)
 *
 *   Q_inc  — Hurwitz incommensurability (1.0 on a φ-basis — proven).
 *   Q_stab — λ_min/λ_max of the 2×2 Gram on (v, φ-shifted v).
 *   Q_res  — energy fraction in top-k modes, k = ⌈N/φ²⌉.
 *
 * V11 adapter: takes the mode vector directly instead of reading the V10
 * `FieldSignature` singleton (which V11 does not expose). Pure function,
 * no React, no engine import. 60-digit Wolfram-verified at construction.
 */

import { HURWITZ_CONSTANT, PHI_FLOOR_INV_SQ } from "@/core/constants/Chapter47";

export interface QualiaCorrelateMeasurement {
  Q: number;
  Q_inc: number;
  Q_stab: number;
  Q_res: number;
  N: number;
  attractorK: number;
  live: boolean;
}

export function computeQualiaCorrelate(modes: readonly number[] | Float64Array): QualiaCorrelateMeasurement {
  const N = modes.length;
  if (N < 2) {
    return { Q: 0, Q_inc: 1, Q_stab: 0, Q_res: 0, N, attractorK: 0, live: false };
  }
  // Q_inc — Hurwitz/Hurwitz = 1 on a φ-basis (proven max).
  const Q_inc = HURWITZ_CONSTANT / HURWITZ_CONSTANT;
  const Q_stab = gramConditioning(modes);
  const k = Math.max(1, Math.ceil(N * PHI_FLOOR_INV_SQ));
  const Q_res = phiAttractorEnergyFraction(modes, k);
  const Q = Math.cbrt(Math.max(0, Q_inc) * Math.max(0, Q_stab) * Math.max(0, Q_res));
  return { Q, Q_inc, Q_stab, Q_res, N, attractorK: k, live: true };
}

function gramConditioning(v: readonly number[] | Float64Array): number {
  const n = v.length;
  let nrm = 0;
  for (let i = 0; i < n; i++) nrm += v[i] * v[i];
  if (nrm <= 0) return 0;
  const invN = 1 / Math.sqrt(nrm);
  // Lag-1 circular autocorrelation: sum v[i]*v[i+1] for i in [0,n-2],
  // plus the wrap-around v[n-1]*v[0]. Unrolling the wrap removes the
  // per-iteration `%` modulo (a div on most JITs).
  let dot = 0;
  const last = n - 1;
  for (let i = 0; i < last; i++) dot += v[i] * v[i + 1];
  dot += v[last] * v[0];
  dot *= invN * invN;
  const c = dot < 0 ? -dot : dot;
  const lamMax = 1 + c, lamMin = 1 - c;
  return lamMax > 0 ? lamMin / lamMax : 0;
}

function phiAttractorEnergyFraction(modes: readonly number[] | Float64Array, k: number): number {
  const n = modes.length;
  if (n === 0 || k <= 0) return 0;
  // Single-pass: build energies into a Float64Array + accumulate total.
  const energies = new Float64Array(n);
  let total = 0;
  for (let i = 0; i < n; i++) {
    const e = modes[i] * modes[i];
    energies[i] = e;
    total += e;
  }
  if (total <= 0) return 0;
  const kc = k < n ? k : n;
  if (kc === n) return 1;

  // Quickselect for the (n-kc)th smallest = kc-th largest pivot, then
  // sum energies[i] >= pivot (with tie handling). O(N) expected vs
  // O(N log N) for a full sort.
  // Hoare-partition partial select on `energies` in place.
  let lo = 0, hi = n - 1;
  const target = n - kc; // index such that energies[target..n) are the kc largest
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    const a = energies[lo], b = energies[mid], c = energies[hi];
    const pivot = a < b
      ? (b < c ? b : (a < c ? c : a))
      : (a < c ? a : (b < c ? c : b));
    let i = lo, j = hi;
    while (i <= j) {
      while (energies[i] < pivot) i++;
      while (energies[j] > pivot) j--;
      if (i <= j) {
        if (i !== j) { const t = energies[i]; energies[i] = energies[j]; energies[j] = t; }
        i++; j--;
      }
    }
    if (target <= j) hi = j;
    else if (target >= i) lo = i;
    else break;
  }

  let topSum = 0;
  for (let i = target; i < n; i++) topSum += energies[i];
  return topSum / total;
}
