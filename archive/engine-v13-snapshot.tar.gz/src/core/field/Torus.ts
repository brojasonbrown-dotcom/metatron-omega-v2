/**
 * Torus — local self-sustaining recursion operator (RHUFT Ch. 6).
 *
 * Wraps the Ψ signature into a (poloidal, toroidal) ring:
 *   - poloidal axis  = φ-mode index k ∈ [0, N)
 *   - toroidal axis  = time-ring across the last F(n) ticks
 *
 * The RHUFT torus is the geometric archetype of local closure: energy
 * circulates through itself without leaking, and coherence is measured as
 * the ability of a tick to re-enter a recent past state. This is the
 * genuine "recursive closure" replacing linear time-carry.
 *
 * Pure, deterministic, allocation-light. Never mutates engine state.
 */

import { PHI } from '@/core/constants/WolframVerified';

/** Golden angle in radians (≈ 2.39996). */
export const GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));

/** Standard Fibonacci depths used for toroidal ring lengths. */
export const FIB_DEPTHS = Object.freeze([3, 5, 8, 13, 21, 34, 55]);

export interface ToroidalRing {
  readonly capacity: number;
  readonly length: number;
}

/**
 * Fixed-capacity ring buffer of Ψ snapshots. Deterministic under identical
 * push order.
 */
export class ToroidalMemory implements ToroidalRing {
  readonly capacity: number;
  private frames: Float64Array[] = [];
  private head = 0;

  constructor(capacity: number) {
    if (capacity < 2) throw new Error('ToroidalMemory: capacity must be >= 2');
    this.capacity = capacity | 0;
  }

  get length(): number { return this.frames.length; }

  /**
   * Copy-in push — caller may reuse `psi`.
   *
   * `head` is the *next write index* and MUST advance on every push,
   * including during the fill phase.
   *
   * Phase 16 correctness fix: the fill branch previously appended without
   * advancing `head`, so `head` stayed 0 while `frames` grew. `at(age)`
   * resolves `idx = (head - 1 - age + capacity) % capacity`, which with
   * head=0 pointed at `frames[capacity - 1]` — an unwritten slot for the
   * first `capacity` pushes. Every lookup returned null, so
   * `toroidalCoherence` summed nothing and returned exactly 0.
   *
   * Downstream that produced a hard deadlock: MasterUpdateController only
   * pushes on an ADMITTED update, admission needs C = ½(toroidalC + 1) to
   * clear the triadic gate, and toroidalC could not become non-zero until
   * `capacity + 1` pushes had already happened. Result: 0 % admit rate
   * forever and a Ψ frozen at its seed across all nine RHUFT-F scales.
   */
  push(psi: Float64Array): void {
    const copy = new Float64Array(psi);
    if (this.frames.length < this.capacity) {
      this.frames.push(copy);
    } else {
      this.frames[this.head] = copy;
    }
    this.head = (this.head + 1) % this.capacity;
  }


  /**
   * Return frame at logical age `age` (0 = newest, 1 = one step back, …).
   * Returns null if unavailable.
   */
  at(age: number): Float64Array | null {
    const n = this.frames.length;
    if (n === 0 || age < 0 || age >= n) return null;
    const idx = (this.head - 1 - age + this.capacity) % this.capacity;
    return this.frames[idx] ?? null;
  }

  clear(): void { this.frames.length = 0; this.head = 0; }
}

/** Cosine similarity between two equal-length vectors. Returns 0 if degenerate. */
export function cosine(a: Float64Array, b: Float64Array): number {
  const n = Math.min(a.length, b.length);
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < n; i++) {
    const x = a[i], y = b[i];
    dot += x * y; na += x * x; nb += y * y;
  }
  const d = Math.sqrt(na * nb);
  return d > 1e-15 ? dot / d : 0;
}

/**
 * Toroidal coherence: φ-weighted mean cosine of current Ψ against the ring.
 * Weights decay by 1/φ^age so recent frames dominate — the honest
 * "self-recursion depth" of the current state.
 *
 * Returns a value in [-1, 1]. Perfect recurrence → +1.
 */
export function toroidalCoherence(current: Float64Array, ring: ToroidalMemory): number {
  const n = ring.length;
  if (n === 0) return 0;
  let sum = 0, wsum = 0;
  for (let age = 0; age < n; age++) {
    const past = ring.at(age);
    if (!past) continue;
    const w = Math.pow(1 / PHI, age);
    sum += w * cosine(current, past);
    wsum += w;
  }
  return wsum > 0 ? sum / wsum : 0;
}

/**
 * φ-directional scan operator G_{φ,σ}: rotate the Ψ signature by the
 * golden angle in mode-index space. This is the "geometric directional
 * scan" from the RHUFT master equation §10.
 *
 *   out[k] = (1 − σ) · psi[k] + σ · psi[(k + step) mod N]
 *
 * where `step = round(N * (1/φ))`. σ ∈ [0,1] blends identity ↔ full rotation.
 * Pure; writes into `out` (may equal `psi`? no — allocate outside).
 */
export function goldenScan(psi: Float64Array, out: Float64Array, sigma = 0.5): void {
  const n = psi.length;
  if (out.length !== n) throw new Error('goldenScan: length mismatch');
  const step = Math.max(1, Math.round(n / PHI)) % n;
  const s = Math.max(0, Math.min(1, sigma));
  const oneMinusS = 1 - s;
  for (let k = 0; k < n; k++) {
    const j = (k + step) % n;
    out[k] = oneMinusS * psi[k] + s * psi[j];
  }
}
