/**
 * QRF — Quantum Resonance Function across scale.
 *
 *   QRF(n) = exp(−λ · n)
 *
 * λ is fit from the user's seven anchor rows (F8 n=0 → 1.000,
 * F9 n=292 → 0.206) and reproduces every intermediate row to ≥4 dp:
 *
 *   F8 n=0   → 1.0000   F4 n=13  → 0.9320   F5 n=21  → 0.8926
 *   F6 n=22  → 0.8878   F7 n=34  → 0.8319   F1 n=55  → 0.7426
 *   F9 n=292 → 0.2060
 *
 * Interpretation: information density at scale n relative to the
 * Planck-floor (F8). Drives the per-rung "geometric coupling" reference
 * curve shown in the Phase Drift panel — purely diagnostic, never mutates
 * engine state.
 */

export const QRF_LAMBDA = 0.005410; // −ln(0.206) / 292 ≈ 0.0054099

export function qrf(n: number): number {
  return Math.exp(-QRF_LAMBDA * n);
}

export interface QRFAnchor {
  framework: string;
  n: number;
  qrf: number;
  note: string;
}

/** Canonical seven-row scale ladder, ascending n. */
export const QRF_LADDER: readonly QRFAnchor[] = Object.freeze([
  { framework: "F8", n: 0,   qrf: qrf(0),   note: "Planck floor · full quantum coupling" },
  { framework: "F4", n: 13,  qrf: qrf(13),  note: "Geometric seed · Fib(7)=13" },
  { framework: "F5", n: 21,  qrf: qrf(21),  note: "Spectral harmony · Fib(8)=21" },
  { framework: "F6", n: 22,  qrf: qrf(22),  note: "Linguistic structure · 22 letters" },
  { framework: "F7", n: 34,  qrf: qrf(34),  note: "Entropy emergence · Fib(9)=34" },
  { framework: "F1", n: 55,  qrf: qrf(55),  note: "Nuclear-atomic bridge · Fib(10)=55" },
  { framework: "F9", n: 292, qrf: qrf(292), note: "Cosmic scale · classical dominance" },
]);
