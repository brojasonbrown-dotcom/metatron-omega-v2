/**
 * MemoryFeedback — discrete-time memory recursion
 * ================================================
 *
 * Implements the chapter-04 invariant
 *
 *     Ψ_memory(t) = λ · Ψ_total(t − τ),     λ = 1/φ²
 *
 * as a pure, deterministic ring-buffer. No I/O, no globals, no side effects.
 * The module is *available* to higher layers (MetatronCore extensions, the
 * sentience substrate) but is NOT wired into the V10 chain by default —
 * surfacing it would change golden outputs.
 *
 * Mathematical guarantees (covered by stability tests):
 *   1. Spectral radius of the memory operator = 1/φ² (contractive).
 *   2. Pure-memory recursion (no drive) converges to 0 from any seed.
 *   3. Driven recursion Ψ_{n+1} = λ·Ψ_{n−τ+1} + d converges to d/(1−λ)
 *      = d · φ²/(φ²−1)  = d · φ² · φ⁻¹ · 1/(φ−1·…) → closed-form fixed point.
 *   4. Determinism: identical (seed, drive, τ, λ) → identical trajectory.
 */

import { PHI_INV } from '../frameworks/constants';

export const LAMBDA_MEMORY = PHI_INV * PHI_INV; // 1/φ²

export interface MemoryFeedbackOptions {
  /** Delay τ in discrete steps. Must be ≥ 1. */
  tau?: number;
  /** Contraction coefficient λ. Defaults to 1/φ². Must satisfy 0 < λ < 1. */
  lambda?: number;
  /** Ring-buffer seed for the first τ steps. Defaults to 0. */
  seed?: number;
}

export interface MemoryFeedbackState {
  /** Ring buffer of the last τ Ψ_total values. Index 0 = oldest. */
  buffer: number[];
  lambda: number;
  tau: number;
  /** Step count since construction (monotone). */
  step: number;
}

export function createMemoryFeedback(opts: MemoryFeedbackOptions = {}): MemoryFeedbackState {
  const tau = Math.max(1, Math.floor(opts.tau ?? 1));
  const lambda = opts.lambda ?? LAMBDA_MEMORY;
  if (!(lambda > 0 && lambda < 1)) {
    throw new Error(`MemoryFeedback: lambda must be in (0,1), got ${lambda}`);
  }
  const seed = Number.isFinite(opts.seed) ? (opts.seed as number) : 0;
  return {
    buffer: Array(tau).fill(seed),
    lambda,
    tau,
    step: 0,
  };
}

/**
 * Apply one recursion step.
 *
 *   Ψ_memory(t) = λ · Ψ_total(t − τ)         (looked up from ring buffer)
 *   Ψ_total(t) = drive + Ψ_memory(t)         (caller-supplied drive)
 *
 * Returns the new Ψ_total and updates the buffer in place.
 */
export function stepMemoryFeedback(state: MemoryFeedbackState, drive: number): number {
  const delayed = state.buffer[state.step % state.tau];
  const memory = state.lambda * delayed;
  const total = drive + memory;
  state.buffer[state.step % state.tau] = total;
  state.step += 1;
  return total;
}

/**
 * Closed-form fixed point of the driven recursion with constant drive d.
 *
 *   Ψ* = d / (1 − λ)
 *
 * For λ = 1/φ², this collapses to  d · φ²/(φ² − 1) = d · φ².
 */
export function memoryFixedPoint(drive: number, lambda: number = LAMBDA_MEMORY): number {
  return drive / (1 - lambda);
}

/**
 * Run N steps with a constant drive and return the final Ψ_total.
 * Useful for tests and for the higher-level extension that wants a single
 * scalar `memoryCoherence` ∈ [0,1] from a sustained input.
 */
export function runMemoryFeedback(
  drive: number,
  steps: number,
  opts: MemoryFeedbackOptions = {},
): number {
  const state = createMemoryFeedback(opts);
  let last = 0;
  for (let i = 0; i < steps; i++) last = stepMemoryFeedback(state, drive);
  return last;
}

// ──────────────────────────────────────────────────────────────────────────
// V13 — Saturation-bias feedback (additive, sandbox-only)
// ──────────────────────────────────────────────────────────────────────────
//
// Per-rung saturation labels currently never feed back into the chain. V13
// closes the loop: rungs reporting `under` get a small additive drive on
// the next tick; `over` rungs are damped; `divergent` rungs contribute
// nothing AND increment a divergence counter. If the counter exceeds
// φ⁵ ≈ 11 ticks the rung is quarantined and the caller may emit an audit
// event.
//
// All biases are bounded by ±1/φ³ ≈ 0.236, so the chain can never be
// driven into a runaway state by the feedback alone.

import type { SaturationLabel } from '../residuals/ChapterResiduals';
import { PHI } from '../frameworks/constants';

export const SATURATION_BIAS_AMPLITUDE = 1 / (PHI * PHI * PHI); // ≈ 0.2361
export const QUARANTINE_THRESHOLD_TICKS = Math.ceil(Math.pow(PHI, 5));

export interface SaturationBiasState {
  /** Per-rung divergence-counter (resets to 0 on a non-divergent tick). */
  divergenceTicks: Record<string, number>;
  /** Rungs whose divergence-counter exceeded QUARANTINE_THRESHOLD_TICKS. */
  quarantined: Set<string>;
}

export function createSaturationBiasState(): SaturationBiasState {
  return { divergenceTicks: {}, quarantined: new Set() };
}

/**
 * Compute the per-rung additive bias for the next tick.
 * Updates `state.divergenceTicks` and `state.quarantined` as a side effect.
 *
 * Quarantined rungs always return 0 bias (until cleared by caller).
 */
export function saturationBias(
  framework: string,
  label: SaturationLabel,
  state: SaturationBiasState,
): number {
  if (state.quarantined.has(framework)) return 0;
  if (label === 'divergent') {
    const n = (state.divergenceTicks[framework] ?? 0) + 1;
    state.divergenceTicks[framework] = n;
    if (n >= QUARANTINE_THRESHOLD_TICKS) {
      state.quarantined.add(framework);
    }
    return 0;
  }
  // Non-divergent → reset the divergence counter.
  state.divergenceTicks[framework] = 0;
  if (label === 'under') return +SATURATION_BIAS_AMPLITUDE;
  if (label === 'over')  return -SATURATION_BIAS_AMPLITUDE;
  return 0;
}
