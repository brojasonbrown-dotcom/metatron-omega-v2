/**
 * RhuftMetricBank — Phase 2 · Step 5.
 *
 * Read-only consumer of the ShadowStateTape. Publishes per-tick unclamped
 * metric snapshots + Lyapunov energy + ΔE. Ring buffer of the last 512
 * snapshots for stability monitoring.
 *
 * Guarded by `FLAG_RHUFTF_METRICS` (default OFF): when off, `computeSnapshot`
 * returns null and no work is done.
 */

import type { FieldStateN, GraphSnapshot } from '@metatron/field-kernel-core';
import {
  measureDrift,
  measureTemporalCoherence,
  measureClosure,
  measureInformationDensity,
  measureBurden,
  measureInertia,
  lyapunovEnergy,
  LYAPUNOV_WEIGHTS_VERSION,
  portFlag,
} from '@metatron/field-kernel-core';
import type { ShadowStateTape } from './ShadowStateTape';
import { scaleMeasurementRegistry } from './rhuftf/ScaleMeasurement';
import type { ScaleMeasurementContext } from './rhuftf/ScaleMeasurement';

export interface MetricRow {
  readonly scale: number;
  readonly drift: number;
  readonly temporalCoherence: number;
  readonly closure: number;
  readonly informationDensity: number;
  readonly burden: number;
  readonly inertia: number;
  readonly psiPower: number;
  /** Populated when a ScaleMeasurement module is registered for this scale. */
  readonly frameworkName: string | null;
  readonly frameworkClosureScore: number | null;
  readonly frameworkClosureResidual: number | null;
  readonly frameworkInvariantScore: number | null;
}

export interface RhuftMetricsSnapshot {
  readonly tick: number;
  readonly perScale: readonly MetricRow[];
  readonly energy: number;
  readonly deltaEnergy: number;
  readonly weightsVersion: string;
}

const RING_CAP = 512;

const DEFAULT_CTX: ScaleMeasurementContext = Object.freeze({
  tSeconds: 0,
  carrierHz: 0,
  tick: 0,
});

export class RhuftMetricBank {
  private readonly ring: RhuftMetricsSnapshot[] = [];
  private tickCounter = 0;
  private lastEnergy: number | null = null;

  /** Force-enable regardless of flag (offline scripts). */
  constructor(private readonly opts: { forceEnabled?: boolean } = {}) {}

  get enabled(): boolean {
    return this.opts.forceEnabled === true || portFlag('FLAG_RHUFTF_METRICS');
  }

  /**
   * @param tape    ShadowStateTape (source of FieldStateN snapshots).
   * @param graphs  Optional per-scale read-only graph snapshots (same order as `states`).
   * @param targets Optional per-scale Phase-3 closure targets (same order as `states`).
   * @param ctx     Optional measurement context (t, carrier, tick). Defaults to zeros.
   */
  computeSnapshot(
    tape: ShadowStateTape,
    graphs?: readonly (GraphSnapshot | null)[],
    targets?: readonly (Float64Array | null)[],
    ctx?: Partial<ScaleMeasurementContext>,
  ): RhuftMetricsSnapshot | null {
    if (!this.enabled || !tape.enabled) return null;
    const states = tape.snapshot();
    const prev = tape.previousSnapshot();
    if (states.length === 0) return null;

    const mCtx: ScaleMeasurementContext = ctx
      ? {
          tSeconds: ctx.tSeconds ?? DEFAULT_CTX.tSeconds,
          carrierHz: ctx.carrierHz ?? DEFAULT_CTX.carrierHz,
          tick: ctx.tick ?? this.tickCounter,
        }
      : { ...DEFAULT_CTX, tick: this.tickCounter };

    const perScale: MetricRow[] = states.map((s: FieldStateN, i: number) => {
      const p = prev[i];
      const psi = s.psi;
      let power = 0;
      for (let k = 0; k < psi.length; k++) power += psi[k] * psi[k];
      const framework = scaleMeasurementRegistry.get(s.scale);
      let fName: string | null = null;
      let fClosureScore: number | null = null;
      let fClosureResidual: number | null = null;
      let fInvariant: number | null = null;
      if (framework) {
        // measure() is read-only on ψ/ψ̂/u/y (contract enforced by Phase-4
        // truth tests). Writes to state.m/gamma are intentional per spec.
        const r = framework.measure(s, mCtx);
        fName = framework.name;
        fClosureScore = r.closureScore;
        fClosureResidual = r.closureResidual;
        fInvariant = r.invariantScore;
      }
      return {
        scale: s.scale,
        drift: measureDrift(s),
        temporalCoherence: p ? measureTemporalCoherence(psi, p.psi) : NaN,
        closure: measureClosure(s, targets?.[i] ?? null),
        informationDensity: measureInformationDensity(s),
        burden: measureBurden(s),
        inertia: p ? measureInertia(s, p) : NaN,
        psiPower: power,
        frameworkName: fName,
        frameworkClosureScore: fClosureScore,
        frameworkClosureResidual: fClosureResidual,
        frameworkInvariantScore: fInvariant,
      };
    });


    const energy = lyapunovEnergy(states, graphs);
    const deltaEnergy = this.lastEnergy === null ? 0 : energy - this.lastEnergy;
    this.lastEnergy = energy;

    const snap: RhuftMetricsSnapshot = {
      tick: this.tickCounter++,
      perScale,
      energy,
      deltaEnergy,
      weightsVersion: LYAPUNOV_WEIGHTS_VERSION,
    };
    this.ring.push(snap);
    if (this.ring.length > RING_CAP) this.ring.shift();
    return snap;
  }

  history(): readonly RhuftMetricsSnapshot[] { return this.ring; }
  latest(): RhuftMetricsSnapshot | null { return this.ring[this.ring.length - 1] ?? null; }
  reset(): void { this.ring.length = 0; this.tickCounter = 0; this.lastEnergy = null; }
}
