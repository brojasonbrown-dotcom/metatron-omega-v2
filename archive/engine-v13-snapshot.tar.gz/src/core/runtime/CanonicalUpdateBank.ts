/**
 * CanonicalUpdateBank — Phase 5 · Step 4.
 *
 * Phase-5 analog of `RhuftMetricBank`. Read side is the `ShadowStateTape`;
 * write side is the `localUpdateRegistry` from `@metatron/field-kernel-core`
 * populated by `registerAllRhuftfLocalUpdates()` in Step 3. Iterates every
 * registered U_n exactly once per tick into a private "next tape" pool
 * owned by the bank and emits a `CanonicalUpdateSnapshot`.
 *
 * Guarded by `FLAG_RHUFTF_CANONICAL_UPDATE` (default OFF): when off,
 * `step()` returns null and no U_n is invoked ⇒ runtime is byte-identical
 * to end-of-Phase-4.
 *
 * Invariants (enforced by the Step-4 truth suite and the U_n write
 * contract in `packages/field-kernel-core/src/localUpdate.ts`):
 *
 *   • Bank never writes into the ShadowStateTape or any physics buffer.
 *     The "next tape" is a bank-private allocation; no caller consumes it
 *     until Step 8's MasterUpdateController cut-over.
 *   • Bank never mutates the input `FieldStateN` from `tape.snapshot()`.
 *   • Per U_n:  next.psi/m/gamma written; next.psiHat/u/y untouched
 *     (measurement-owned). Bank additionally copies state.psiHat/u/y into
 *     next.psiHat/u/y on the FIRST tick only, so the next-tape channel
 *     views remain consistent shapes for future readers.
 *   • Non-admitted reports collapse to `next.psi := state.psi`,
 *     `psiDelta := 0`, `energyContribution := 0` — per the LocalUpdate
 *     interface contract.
 *
 * Ring buffer of 512 snapshots. No allocations on the hot path beyond
 * one `UpdateRow[]` per `step()`; the shadow next-tape and per-scale
 * `FieldStateN` are allocated once at construction.
 */

import {
  portFlag,
  listLocalUpdates,
  createFieldStateN,
  copyFieldStateN,
} from '@metatron/field-kernel-core';
import type {
  FieldStateN,
  LocalUpdate,
  LocalUpdateContext,
} from '@metatron/field-kernel-core';
import type { ShadowStateTape, ScaleShape } from './ShadowStateTape';

export interface UpdateRow {
  readonly scale: number;
  readonly name: string;
  readonly psiDelta: number;
  readonly energyContribution: number;
  readonly admitted: boolean;
  readonly gamma: number;
}

export interface CanonicalUpdateSnapshot {
  readonly tick: number;
  readonly perScale: readonly UpdateRow[];
  /**
   * Sum of `energyContribution` across all admitted rows. By the Lyapunov
   * dissipation contract of the U_n kernels (α∈[0,1]), this quantity is
   * ≤ 0 at equilibrium and non-positive off-equilibrium under
   * `relaxTowardsTemplate`.
   */
  readonly totalEnergyContribution: number;
  /**
   * `totalEnergyContribution` − previous tick's total. Zero on the first
   * observed tick (no baseline).
   */
  readonly deltaEnergy: number;
}

const RING_CAP = 512;

const DEFAULT_CTX: LocalUpdateContext = Object.freeze({
  tSeconds: 0,
  carrierHz: 0,
  dt: 0,
  tick: 0,
});

export class CanonicalUpdateBank {
  private readonly ring: CanonicalUpdateSnapshot[] = [];
  private readonly nextByScale = new Map<number, FieldStateN>();
  private tickCounter = 0;
  private lastTotal: number | null = null;
  /** Tracks whether we've hydrated psiHat/u/y for a given scale yet. */
  private readonly bootstrapped = new Set<number>();

  /**
   * @param shapes  Per-scale (scale, nodes) ladder — MUST match the
   *                shapes passed to `createShadowStateTape` on the same
   *                tape instance. Node counts drive the private next
   *                tape allocation; a mismatch would either truncate or
   *                over-allocate silently.
   * @param opts    `forceEnabled: true` bypasses `FLAG_RHUFTF_CANONICAL_UPDATE`
   *                for offline scripts (Step-5 parity suite, Step-6
   *                cross-runtime harness). Never enable in client code.
   */
  constructor(
    shapes: readonly ScaleShape[],
    private readonly opts: { forceEnabled?: boolean } = {},
  ) {
    for (const s of shapes) {
      this.nextByScale.set(s.scale, createFieldStateN(s.scale, s.nodes));
    }
  }

  get enabled(): boolean {
    return this.opts.forceEnabled === true || portFlag('FLAG_RHUFTF_CANONICAL_UPDATE');
  }

  /**
   * Read-only view onto the bank-private next tape. Exposed for the
   * Step-5 parity suite; MUST NOT be aliased back into the physics tape.
   */
  nextTape(): readonly FieldStateN[] {
    return Array.from(this.nextByScale.values()).sort((a, b) => a.scale - b.scale);
  }

  /**
   * Compute one canonical update tick.
   *
   * @param tape  ShadowStateTape whose `snapshot()` supplies each U_n's
   *              input `FieldStateN`.
   * @param ctx   Partial LocalUpdateContext; missing fields default to
   *              zero except `tick` which defaults to the bank's own
   *              monotone counter.
   */
  step(
    tape: ShadowStateTape,
    ctx?: Partial<LocalUpdateContext>,
  ): CanonicalUpdateSnapshot | null {
    if (!this.enabled || !tape.enabled) return null;
    const updates = listLocalUpdates();
    if (updates.length === 0) return null;

    const states = tape.snapshot();
    if (states.length === 0) return null;

    // Build scale → state lookup (bounded map, no per-node allocation).
    const stateByScale = new Map<number, FieldStateN>();
    for (const s of states) stateByScale.set(s.scale, s);

    const uCtx: LocalUpdateContext = ctx
      ? {
          tSeconds:  ctx.tSeconds  ?? DEFAULT_CTX.tSeconds,
          carrierHz: ctx.carrierHz ?? DEFAULT_CTX.carrierHz,
          dt:        ctx.dt        ?? DEFAULT_CTX.dt,
          tick:      ctx.tick      ?? this.tickCounter,
          weights:   ctx.weights,
        }
      : { ...DEFAULT_CTX, tick: this.tickCounter };

    const perScale: UpdateRow[] = [];
    let total = 0;

    for (const u of updates as readonly LocalUpdate[]) {
      const state = stateByScale.get(u.scale);
      const next  = this.nextByScale.get(u.scale);
      if (!state || !next) continue; // registry / tape mismatch — skip silently.

      // First-tick hydrate of measurement-owned channels into next tape so
      // downstream readers see a consistent tuple shape. U_n MUST NOT touch
      // these channels; we mirror them exactly once.
      if (!this.bootstrapped.has(u.scale)) {
        copyFieldStateN(next, state);
        this.bootstrapped.add(u.scale);
      }

      const report = u.step(state, uCtx, next);

      let psiDelta = report.psiDelta;
      let energyContribution = report.energyContribution;
      const admitted = report.admitted === true;

      if (!admitted) {
        // Contract: non-admitted rows collapse to `next.psi := state.psi`.
        // The kernel already does this for its own reject path; we enforce
        // idempotently so third-party U_n cannot violate the invariant.
        const n = Math.min(next.psi.length, state.psi.length);
        for (let i = 0; i < n; i++) next.psi[i] = state.psi[i];
        psiDelta = 0;
        energyContribution = 0;
      }

      perScale.push({
        scale: u.scale,
        name:  u.name,
        psiDelta,
        energyContribution,
        admitted,
        gamma: report.gamma,
      });

      if (Number.isFinite(energyContribution)) total += energyContribution;
    }

    if (perScale.length === 0) return null;

    const deltaEnergy = this.lastTotal === null ? 0 : total - this.lastTotal;
    this.lastTotal = total;

    const snap: CanonicalUpdateSnapshot = {
      tick: this.tickCounter++,
      perScale,
      totalEnergyContribution: total,
      deltaEnergy,
    };
    this.ring.push(snap);
    if (this.ring.length > RING_CAP) this.ring.shift();
    return snap;
  }

  history(): readonly CanonicalUpdateSnapshot[] { return this.ring; }
  latest(): CanonicalUpdateSnapshot | null { return this.ring[this.ring.length - 1] ?? null; }
  reset(): void {
    this.ring.length = 0;
    this.tickCounter = 0;
    this.lastTotal = null;
    this.bootstrapped.clear();
    // Zero the next tape without reallocating — deterministic reset.
    for (const st of this.nextByScale.values()) {
      st.psi.fill(0); st.psiHat.fill(0); st.m.fill(0);
      st.u.fill(0);   st.y.fill(0);      st.gamma.fill(0);
    }
  }
}
