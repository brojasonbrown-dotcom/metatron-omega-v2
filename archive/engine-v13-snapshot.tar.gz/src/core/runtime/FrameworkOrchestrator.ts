/**
 * Wave H2 — Framework live-recurrence orchestrator (main-thread wrapper).
 *
 * Behind `FLAG_FRAMEWORKS_LIVE`. When OFF: `tryCompute` is a no-op and no
 * worker is ever instantiated, preserving bit-exact parity with the prior
 * engine. When ON: each tick pushes the current field snapshot inputs into a
 * dedicated worker that runs F1..F9 in the chain order, returning scalar
 * chainUp metrics and an honest op-count.
 *
 * Fire-and-forget semantics: the engine never awaits the framework worker on
 * its hot path. The latest completed `FrameworkMetrics` is held in a slot the
 * caller reads next tick. This way framework compute happens in parallel with
 * the next field tick — true layered work.
 */

import type { SharedInputs, FrameworkMetrics } from './frameworkOrchestrator.worker';
import { portFlag } from '@metatron/field-kernel-core/portFlags';

type WorkerPacket =
  | { id: number; type: 'ready' }
  | { id: number; type: 'result'; metrics: FrameworkMetrics; elapsedMs: number }
  | { id: number; type: 'error'; message: string };

export class FrameworkOrchestrator {
  private worker: Worker | null = null;
  private seq = 0;
  private latest: FrameworkMetrics | null = null;
  private latestMs = 0;
  private latestAt = 0;
  private busy = false;
  private failed = false;
  private destroyed = false;
  private timeout: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    if (!portFlag('FLAG_FRAMEWORKS_LIVE')) { this.failed = true; return; }
    if (typeof Worker === 'undefined') { this.failed = true; return; }
    try {
      this.worker = new Worker(
        new URL('./frameworkOrchestrator.worker.ts', import.meta.url),
        { type: 'module' },
      );
      this.worker.onmessage = (ev: MessageEvent<WorkerPacket>) => this.receive(ev.data);
      this.worker.onerror = () => { this.failed = true; this.busy = false; };
    } catch {
      this.failed = true;
    }
  }

  /** Non-blocking. Returns immediately; result available next tick via `latestMetrics()`. */
  tryCompute(inputs: SharedInputs): void {
    if (!this.worker || this.failed || this.busy || this.destroyed) return;
    this.busy = true;
    const id = ++this.seq;
    if (this.timeout) clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      if (!this.busy || this.destroyed) return;
      this.busy = false;
    }, 250);
    // Pineal field is small (≤44 floats). Copying is cheaper than transferring
    // because the caller still needs the original buffer for the next tick.
    try {
      this.worker.postMessage({
        id, type: 'compute',
        inputs: {
          coherence: inputs.coherence,
          energy: inputs.energy,
          timeMs: inputs.timeMs,
          pinealField: new Float64Array(inputs.pinealField),
          flowerCoherences: inputs.flowerCoherences.slice(),
          solfeggioCoherences: inputs.solfeggioCoherences.slice(),
          recursionDepth: inputs.recursionDepth,
        },
      });
    } catch {
      this.busy = false;
      this.failed = true;
    }
  }

  latestMetrics(): { metrics: FrameworkMetrics; elapsedMs: number } | null {
    if (!this.latest) return null;
    return { metrics: this.latest, elapsedMs: this.latestMs };
  }

  status(): { stale: boolean; staleMs: number; busy: boolean; failed: boolean } {
    const staleMs = this.latestAt > 0 ? Math.max(0, performance.now() - this.latestAt) : Number.POSITIVE_INFINITY;
    return { stale: !this.latest || staleMs > 500, staleMs, busy: this.busy, failed: this.failed };
  }

  destroy(): void {
    this.destroyed = true;
    if (this.timeout) { clearTimeout(this.timeout); this.timeout = null; }
    try { this.worker?.terminate(); } catch { /* noop */ }
    this.worker = null;
  }

  private receive(packet: WorkerPacket): void {
    if (this.timeout) { clearTimeout(this.timeout); this.timeout = null; }
    if (packet.type === 'result') {
      this.latest = packet.metrics;
      this.latestMs = packet.elapsedMs;
      this.latestAt = performance.now();
      this.busy = false;
    } else if (packet.type === 'error') {
      this.busy = false;
      this.failed = true;
    }
  }
}
