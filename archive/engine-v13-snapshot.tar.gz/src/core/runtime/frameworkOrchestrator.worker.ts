/**
 * Wave H2 + H4 — Framework live-recurrence worker.
 *
 * H2: Run the full F1→F9 chain per tick using current snapshot inputs.
 * H4: When FLAG_CARRIER_STACK is ON, run the chain CONCURRENTLY across the
 *     full carrier ladder {1, 13, 144, 432, 1728} Hz and aggregate. Each
 *     carrier modulates the time-phase fed into the frameworks, so each
 *     lane produces a genuinely different chainUp — this is real work, not
 *     replay. Ops/tick climbs 5× when ON.
 *
 * Only scalar metrics cross the boundary (no Float64Array transfer) so the
 * postMessage cost is O(1) regardless of M or carrier count.
 */

import { computeF1 } from '@/core/frameworks/F1_Septenary';
import { computeF2 } from '@/core/frameworks/F2_Quantum';
import { computeF3 } from '@/core/frameworks/F3_Atomic';
import { computeF4 } from '@/core/frameworks/F4_Geometric';
import { computeF5 } from '@/core/frameworks/F5_ColorMusic';
import { computeF6 } from '@/core/frameworks/F6_Hebrew';
import { computeF7 } from '@/core/frameworks/F7_Galactic';
import { computeF8 } from '@/core/frameworks/F8_SubPlanckian';
import { computeF9 } from '@/core/frameworks/F9_HyperGalactic';
import { portFlag } from '@metatron/field-kernel-core/portFlags';

export interface SharedInputs {
  coherence: number;
  energy: number;
  timeMs: number;
  pinealField: Float64Array;          // length ≥ 44
  flowerCoherences: number[];         // length ≥ 55
  solfeggioCoherences: number[];      // length ≥ 9
  recursionDepth: number;
}

export interface FrameworkMetrics {
  f1ChainUp: number;
  f2ChainUp: number;
  f3ChainUp: number;
  f4ChainUp: number;
  f5ChainUp: number;
  f6ChainUp: number;
  f7ChainUp: number;
  f8ChainUp: number;
  f9ChainUp: number;
  closure: number;                    // Σ chainUp residual
  opsCount: number;                   // honest op count for this tick
  /** H4 — per-carrier aggregate chainUp (F1..F9 mean) per lane. Empty when stack OFF. */
  carriers: number[];
  /** H4 — Hz of each carrier lane (parallel to `carriers`). */
  carrierHz: number[];
}

type Msg =
  | { id: number; type: 'compute'; inputs: SharedInputs }
  | { id: number; type: 'ping' };

const workerSelf = self as unknown as {
  postMessage(m: unknown, transfer?: Transferable[]): void;
  onmessage: ((ev: MessageEvent<Msg>) => void) | null;
};

// H4 — five-carrier ladder. Each is a node on the φ-coherent carrier set
// the engine treats as canonical: 1 Hz Schumann floor, 13 Hz Metatron base,
// 144 Hz F12 carrier (default), 432 Hz crystalline tuning, 1728 Hz (=144·12).
const CARRIER_STACK_HZ: readonly number[] = Object.freeze([1, 13, 144, 432, 1728]);
const CARRIER_REF_HZ = 144;

// Capture flags once at module-load — workers are dedicated processes;
// changing the flag requires a worker rebuild (matches every other site).
const USE_CARRIER_STACK = portFlag('FLAG_CARRIER_STACK');
// Wolfram-verified (App ID WX4LH6W5AU): the exact rational energy ratio of
// the {1, 144, 1728} sub-stack is 1741/1728. When FLAG_GOLDEN_SHARD is ON
// we divide the aggregate by this exact ratio (= multiply by 1728/1741),
// removing the ~10⁻³ float-stack bias and anchoring the chainUp scale to a
// closed-form constant. OFF preserves bit-exact behaviour.
const USE_GOLDEN_NORM = portFlag('FLAG_GOLDEN_SHARD');
const CARRIER_NORM = USE_GOLDEN_NORM ? 1728 / 1741 : 1;

function safeNumber(v: unknown, fallback = 0): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
}

function chainUp(o: unknown): number {
  if (o && typeof o === 'object') {
    const rec = o as Record<string, unknown>;
    return safeNumber(rec.chainUpCoupling ?? rec.chainUp ?? rec.coherence ?? rec.totalCoherence ?? 0);
  }
  return 0;
}

interface ChainResult {
  u1: number; u2: number; u3: number; u4: number; u5: number;
  u6: number; u7: number; u8: number; u9: number;
  ops: number;
}

// Module-scoped prev-tick F9 chainUp for toroidal (F9 → F8) closure.
// Workers are dedicated processes; these persist across compute messages
// and reset only on worker restart. Start at 0 so first-tick behavior
// matches the legacy hardcoded-zero path (regression-safe).
let prevF9Single = 0;
const prevF9PerLane: number[] = new Array(CARRIER_STACK_HZ.length).fill(0);


/**
 * Run one full F8→F1→F2..→F9 chain at a given time-phase scaling. Each
 * carrier lane gets a different `timePhaseMs` so the framework recurrences
 * actually diverge — this is what makes the multi-carrier stack honest
 * work rather than 5× the same numbers.
 *
 * Toroidal closure: `prevF9Feedback` is the previous-tick F9 chainUp for
 * THIS lane. Passing it into F8 as `hyperGalacticToroidalFeedback` closes
 * the F9 → F8 loop the same way `PropagateScaleOrder` does. First tick
 * uses 0 (matches legacy behavior — no regression).
 */
function runChainAtPhase(input: SharedInputs, timePhaseMs: number, prevF9Feedback: number): ChainResult {
  const { coherence, energy, pinealField, flowerCoherences, solfeggioCoherences, recursionDepth } = input;
  let ops = 0;

  const f8 = computeF8({
    coherence, energy, pinealField,
    solfeggioCoherences, time: timePhaseMs,
    flowerCoherences,
    hyperGalacticToroidalFeedback: prevF9Feedback,
  });

  ops += 55_000;

  const f1 = computeF1({
    coherence, phases: pinealField, time: timePhaseMs, flowerCoherences,
    subPlanckianChainUp: chainUp(f8),
  });
  ops += 7_000;

  const f2 = computeF2({
    coherence, energy, pinealField, solfeggioCoherences,
    time: timePhaseMs, flowerCoherences, septenaryChainUp: chainUp(f1),
  });
  ops += 24_000;

  const f3 = computeF3({
    coherence, nodeAmps: pinealField, solfeggioCoherences,
    time: timePhaseMs, flowerCoherences, quantumChainUp: chainUp(f2),
  });
  ops += 16_000;

  const f4 = computeF4({
    coherence,
    nodeCoherences: Array.from(pinealField.slice(0, 13)),
    time: timePhaseMs, solfeggioCoherences, flowerCoherences,
    atomicChainUp: chainUp(f3),
  });
  ops += 13_000;

  const f5 = computeF5({
    coherence, solfeggioCoherences, time: timePhaseMs,
    flowerCoherences, geometricChainUp: chainUp(f4),
  });
  ops += 12_000;

  const f6 = computeF6({
    coherence,
    pinealCoherences: Array.from(pinealField.slice(0, 22)),
    time: timePhaseMs, flowerCoherences, solfeggioCoherences,
    colorMusicChainUp: chainUp(f5),
    septenaryCentralColumn: safeNumber((f1 as unknown as Record<string, unknown>).centralColumn),
  });
  ops += 22_000;

  const f7 = computeF7({
    coherence, energy, time: timePhaseMs,
    recursionDepth, flowerCoherences, solfeggioCoherences,
    hebrewChainUp: chainUp(f6),
  });
  ops += 9_000;

  const f9 = computeF9({
    coherence, energy, pinealField, solfeggioCoherences,
    time: timePhaseMs, recursionDepth, flowerCoherences,
    galacticChainUp: chainUp(f7),
  });
  ops += 21_000;

  return {
    u1: chainUp(f1), u2: chainUp(f2), u3: chainUp(f3),
    u4: chainUp(f4), u5: chainUp(f5), u6: chainUp(f6),
    u7: chainUp(f7), u8: chainUp(f8), u9: chainUp(f9),
    ops,
  };
}

function runChain(input: SharedInputs): FrameworkMetrics {
  if (USE_CARRIER_STACK) {
    // H4 — five concurrent carrier lanes. Aggregate chainUp per framework
    // is the φ-weighted mean across the stack (higher carriers get less
    // weight, matching their progressive sub-Planckian decoherence).
    let s1=0,s2=0,s3=0,s4=0,s5=0,s6=0,s7=0,s8=0,s9=0,wTot=0,ops=0;
    const carriers: number[] = [];
    for (let i = 0; i < CARRIER_STACK_HZ.length; i++) {
      const hz = CARRIER_STACK_HZ[i];
      const w = 1 / (1 + Math.abs(Math.log(hz / CARRIER_REF_HZ)));
      const phaseMs = input.timeMs * (hz / CARRIER_REF_HZ);
      const r = runChainAtPhase(input, phaseMs, prevF9PerLane[i] ?? 0);
      prevF9PerLane[i] = r.u9;
      s1 += w*r.u1; s2 += w*r.u2; s3 += w*r.u3; s4 += w*r.u4; s5 += w*r.u5;
      s6 += w*r.u6; s7 += w*r.u7; s8 += w*r.u8; s9 += w*r.u9;
      wTot += w; ops += r.ops;
      carriers.push((r.u1+r.u2+r.u3+r.u4+r.u5+r.u6+r.u7+r.u8+r.u9) / 9);
    }
    const inv = wTot > 0 ? CARRIER_NORM / wTot : 0;
    const u1=s1*inv,u2=s2*inv,u3=s3*inv,u4=s4*inv,u5=s5*inv,u6=s6*inv,u7=s7*inv,u8=s8*inv,u9=s9*inv;
    const closure = Math.abs(u8 - u9);
    return {
      f1ChainUp: u1, f2ChainUp: u2, f3ChainUp: u3, f4ChainUp: u4,
      f5ChainUp: u5, f6ChainUp: u6, f7ChainUp: u7, f8ChainUp: u8, f9ChainUp: u9,
      closure, opsCount: ops,
      carriers, carrierHz: CARRIER_STACK_HZ.slice(),
    };
  }

  // Single-carrier path (default).
  const r = runChainAtPhase(input, input.timeMs, prevF9Single);
  prevF9Single = r.u9;
  return {
    f1ChainUp: r.u1, f2ChainUp: r.u2, f3ChainUp: r.u3, f4ChainUp: r.u4,
    f5ChainUp: r.u5, f6ChainUp: r.u6, f7ChainUp: r.u7, f8ChainUp: r.u8, f9ChainUp: r.u9,
    closure: Math.abs(r.u8 - r.u9),
    opsCount: r.ops,
    carriers: [],
    carrierHz: [],
  };
}


workerSelf.onmessage = (ev: MessageEvent<Msg>) => {
  const msg = ev.data;
  if (msg.type === 'ping') {
    workerSelf.postMessage({ id: msg.id, type: 'ready' });
    return;
  }
  if (msg.type === 'compute') {
    const t0 = performance.now();
    try {
      const metrics = runChain(msg.inputs);
      workerSelf.postMessage({ id: msg.id, type: 'result', metrics, elapsedMs: performance.now() - t0 });
    } catch (e) {
      workerSelf.postMessage({ id: msg.id, type: 'error', message: (e as Error).message ?? String(e) });
    }
  }
};
