/**
 * sweepHooks — instrumented wrapper around fieldKernelCore.runShardKernel
 * for the /sandbox/hz route. Used ONLY by sandbox harnesses; never imported
 * by the live engine. Keeps governor / scheduler / sensory completely
 * untouched.
 */

import { runShardKernel, type ShardKernelInput } from '@metatron/field-kernel-core';

export interface SweepConfig {
  carrierHz: number;
  reflectionPeriod: number;   // ticks (not used by kernel directly; reported)
  audioHz: number;            // reported only
  visionFps: number;          // reported only
  nodes: number;
  wallHz: number;             // wall-clock target Hz (capped ≤ 1000)
}

export interface SweepSample {
  t: number;
  coherence: number;
  energy: number;
  dtMs: number;
}

export class SweepRunner {
  private prev: Float64Array;
  private out: Float64Array;
  private tSim = 0;
  private rafHandle: number | null = null;
  private last = 0;
  private samples: SweepSample[] = [];
  private startWall = 0;

  constructor(private cfg: SweepConfig, private onSample: (s: SweepSample) => void) {
    this.prev = new Float64Array(cfg.nodes);
    this.out = new Float64Array(cfg.nodes);
    for (let i = 0; i < cfg.nodes; i++) this.prev[i] = Math.sin(i * 0.3 + 1) * 0.5;
  }

  start(): void {
    if (this.rafHandle !== null) return;
    this.startWall = performance.now();
    this.last = this.startWall;
    const wallMs = 1000 / Math.min(1000, this.cfg.wallHz);
    const substeps = Math.max(1, Math.round(this.cfg.carrierHz / Math.min(1000, this.cfg.wallHz)));
    const dtSim = 1 / this.cfg.carrierHz;

    const loop = () => {
      const now = performance.now();
      let res: ReturnType<typeof runShardKernel> = { term1: 0, term2: 0, term3: 0, term4: 0, energy: 0, coherenceNum: 0, coherenceDen: 1 };
      for (let s = 0; s < substeps; s++) {
        const input: ShardKernelInput = {
          kStart: 1, nodes: this.cfg.nodes, carrierHz: this.cfg.carrierHz,
          tSeconds: this.tSim, qScalar: 0.5, reflectEnabled: true, computePressure: 1,
          prev: this.prev, out: this.out,
        };
        res = runShardKernel(input);
        this.tSim += dtSim;
      }
      const coherence = res.coherenceDen !== 0 ? res.coherenceNum / res.coherenceDen : 0;
      const sample: SweepSample = { t: now, coherence, energy: res.energy, dtMs: now - this.last };
      this.last = now;
      this.samples.push(sample);
      if (this.samples.length > 2048) this.samples.shift();
      this.onSample(sample);

      this.rafHandle = window.setTimeout(loop, wallMs) as unknown as number;
    };
    loop();
  }

  stop(): void {
    if (this.rafHandle !== null) {
      clearTimeout(this.rafHandle);
      this.rafHandle = null;
    }
  }

  getSamples(): SweepSample[] { return this.samples.slice(); }
}
