/**
 * METATRON V11 — BROWSER DRIVER BANK
 * ===================================
 * Hydrates the Wolfram-verified driver catalog (deterministic, 60-digit
 * precision entries) into the in-browser fallback engine.
 *
 * NON-REGRESSION CONTRACT:
 *   - This module is purely additive. It NEVER mutates kernel math.
 *   - sample() only enriches DriverInfo[] telemetry — the kernel still
 *     drives Ψ via fieldKernel.worker.ts at the same per-mode amplitudes.
 *   - localStorage['v11.driverBank'] === 'off' short-circuits to empty,
 *     restoring exact pre-Phase-2 behavior.
 *   - Load failure / timeout → empty bank → legacy 6-driver behavior.
 *
 * NO MOCK, NO SPECULATION:
 *   - Entries are parsed verbatim from public/wolfram/*.jsonl.
 *   - Numeric values are read from Wolfram `result` strings.
 *   - Non-numeric entries (e.g. factor decompositions) are kept as
 *     symbolic markers with variance=0 and excluded from numeric sampling.
 */

import type { DriverInfo } from '@/core/bus/protocol';
import { PHI } from '@/core/constants/WolframVerified';

export interface BankEntry {
  readonly id: string;
  readonly source: string;        // jsonl file basename
  readonly area: string;          // wolfram area tag, e.g. "01_phi_psi"
  readonly numeric: number | null;
  readonly raw: string;           // raw result string
}

export interface BankStats {
  readonly loaded: boolean;
  readonly total: number;
  readonly numeric: number;       // entries with a parsable number
  readonly sources: string[];
  readonly killed: boolean;       // kill switch active
  readonly error: string | null;
}

const BANK_FILES = [
  'results.jsonl',
  'wave2.jsonl',
  'octave_audit.jsonl',
  'stability_audit.jsonl',
] as const;

const KILL_KEY = 'v11.driverBank';

let cachedEntries: BankEntry[] | null = null;
let cachedNumeric: BankEntry[] | null = null;
let loadPromise: Promise<BankEntry[]> | null = null;
let loadError: string | null = null;
let loadedSources: string[] = [];

function isKilled(): boolean {
  if (typeof localStorage === 'undefined') return false;
  try { return localStorage.getItem(KILL_KEY) === 'off'; } catch { return false; }
}

function parseNumeric(s: unknown): number | null {
  if (typeof s !== 'string') return null;
  // Wolfram results like "1.61803398874989484820458683436563811772030917980576286213545"
  // or "0.618..." or "2^4×3^2 (...)". We accept only entries that parse cleanly.
  const trimmed = s.trim();
  // Reject factorisations and symbolic forms outright.
  if (/[×x()A-Za-z]/.test(trimmed)) return null;
  const n = Number(trimmed);
  return Number.isFinite(n) ? n : null;
}

function parseLine(line: string, source: string): BankEntry | null {
  const t = line.trim();
  if (!t) return null;
  try {
    const obj = JSON.parse(t) as Record<string, unknown>;
    const id = typeof obj.id === 'string' ? obj.id
      : typeof obj.tag === 'string' ? obj.tag
      : null;
    if (!id) return null;
    const area = typeof obj.area === 'string' ? obj.area
      : typeof obj.tag === 'string' ? String(obj.tag).split('_')[0] ?? 'misc'
      : 'misc';
    let raw: string = '';
    let numeric: number | null = null;
    if (typeof obj.result === 'string') {
      raw = obj.result;
      numeric = parseNumeric(obj.result);
    } else if (Array.isArray(obj.plaintext) && obj.plaintext.length >= 2) {
      // stability_audit.jsonl format: plaintext[1] is the numeric line
      raw = String(obj.plaintext[1]);
      numeric = parseNumeric(obj.plaintext[1]);
    }
    return { id: `${source}:${id}`, source, area, numeric, raw };
  } catch {
    return null;
  }
}

async function fetchWithTimeout(url: string, timeoutMs: number): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const r = await fetch(url, { signal: controller.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Idempotent. First call kicks off the fetch; subsequent calls return the
 * same promise. On failure, resolves with empty array so callers degrade
 * gracefully (the fallback engine keeps its legacy synthetic drivers).
 */
export function loadOnce(timeoutMs: number = 2000): Promise<BankEntry[]> {
  if (isKilled()) {
    cachedEntries = [];
    cachedNumeric = [];
    return Promise.resolve([]);
  }
  if (cachedEntries) return Promise.resolve(cachedEntries);
  if (loadPromise) return loadPromise;

  loadPromise = (async () => {
    const all: BankEntry[] = [];
    const sources: string[] = [];
    for (const f of BANK_FILES) {
      try {
        const text = await fetchWithTimeout(`/wolfram/${f}`, timeoutMs);
        const before = all.length;
        for (const line of text.split('\n')) {
          const e = parseLine(line, f);
          if (e) all.push(e);
        }
        if (all.length > before) sources.push(f);
      } catch (e) {
        loadError = `${f}: ${(e as Error).message}`;
        // continue with remaining files
      }
    }
    cachedEntries = all;
    cachedNumeric = all.filter((e) => e.numeric !== null && Number.isFinite(e.numeric));
    loadedSources = sources;
    return all;
  })();

  return loadPromise;
}

/**
 * Deterministic per-tick sample. Returns up to `limit` driver telemetry
 * rows derived from the loaded bank. variance is computed from the entry's
 * verified numeric value (φ-decayed) so the NodeGrower gate sees a real,
 * non-zero signal rooted in Wolfram-verified math.
 */
export function sample(m: number, tick: number, limit: number = 64): DriverInfo[] {
  if (isKilled() || !cachedNumeric || cachedNumeric.length === 0) return [];
  const cap = Math.max(0, Math.min(limit, cachedNumeric.length));
  if (cap === 0) return [];
  const out: DriverInfo[] = [];
  const offset = ((tick % cachedNumeric.length) + cachedNumeric.length) % cachedNumeric.length;
  for (let i = 0; i < cap; i++) {
    const e = cachedNumeric[(offset + i) % cachedNumeric.length];
    // Variance: fold the verified numeric through a φ-decay envelope tied
    // to the entry's index. Deterministic, finite, bounded.
    const v = (e.numeric as number);
    const decay = Math.pow(1 / PHI, (i % 22) * 0.5);
    const variance = Math.abs(v - Math.floor(v)) * decay;
    out.push({
      id: e.id,
      kind: 'empirical',
      source: `wolfram:${e.area}`,
      variance,
      modeIndex: (m === 0 ? 0 : (i % m)),
    });
  }
  return out;
}

export function stats(): BankStats {
  return {
    loaded: cachedEntries !== null,
    total: cachedEntries?.length ?? 0,
    numeric: cachedNumeric?.length ?? 0,
    sources: loadedSources.slice(),
    killed: isKilled(),
    error: loadError,
  };
}

/**
 * Phase 2b — per-mode bank coefficient table.
 *
 * Returns a Float64Array of length `nodes` whose values are in [-1, +1]
 * and are derived deterministically from the loaded Wolfram numerics.
 * The kernel multiplies its per-mode psi by `(1 + alpha · coef[i])`, so
 * the table acts as a bounded, verified-attractor perturbation.
 *
 * - Bank empty / killed / unloaded → all zeros (kernel sees mul=1.0 → identical).
 * - Pure function of (kStart, nodes, bank entries) — no randomness, no state.
 */
export function buildCoefficientTable(kStart: number, nodes: number): Float64Array {
  const out = new Float64Array(Math.max(0, nodes));
  if (isKilled() || !cachedNumeric || cachedNumeric.length === 0) return out;
  const len = cachedNumeric.length;
  for (let i = 0; i < out.length; i++) {
    const k = kStart + i;
    const idx = ((k % len) + len) % len;
    const v = cachedNumeric[idx].numeric as number;
    // Fold the verified numeric into a bounded coefficient in (-1, +1).
    // Use the fractional part centred on 0 then squashed by tanh so any
    // future Wolfram entry (φ, Ω_c, ladder, octave, stability) lands in
    // the same bounded range regardless of magnitude.
    const frac = v - Math.floor(v) - 0.5;
    out[i] = Math.tanh(frac * 2 * PHI);
  }
  return out;
}

/** Test-only: reset module state. */
export function _resetForTests(): void {
  cachedEntries = null;
  cachedNumeric = null;
  loadPromise = null;
  loadError = null;
  loadedSources = [];
}
