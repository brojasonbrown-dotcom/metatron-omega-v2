/**
 * METATRON V11 — WEBGPU FIELD KERNEL (BENCH-ONLY, PARITY-GATED)
 * ==============================================================
 *
 * WGSL port of `runShardKernel` (fieldKernelCore.ts) — f32 storage, single
 * shard, computes final-pass amplitudes plus the two scalars needed to
 * derive coherence (`coherenceNum`, `coherenceDen`, `energy`).
 *
 * SCOPE: This module is intentionally NOT wired into `FallbackEngine`
 * or `FieldWorkerPool`. It is a sovereign, sandbox-only accelerator used
 * by `/sandbox/gpu` to honestly measure GPU throughput and report
 * |Δcoherence| against the CPU (f64) reference. The CPU kernel remains
 * the sole source of truth for the live engine until the parity gate
 * is proven across the full φ-ladder at M ∈ {89, 610, 4181, 46368}.
 *
 * DESIGN NOTES:
 *  - f32 storage. Tier-2 grades (M ≥ 610) have Gram entries < 1e-15, so f32
 *    retains the information bits. The parity gate must confirm this per M.
 *  - `passes` are dispatched sequentially (each mutates prev[]); within a
 *    pass, every i is independent so we dispatch N threads (workgroup=64).
 *  - The final pass writes both `prev[]` and per-node reductions
 *    (`coherenceNum`, `coherenceDen`, `energy`) that we sum on the host.
 *  - Buffer count kept ≤ 8 storage buffers to fit default WebGPU limits.
 *  - Kill switch: `localStorage.metatron_webgpu_off === '1'` disables.
 *  - Never throws — every failure path returns null; caller falls back to CPU.
 */

const WORKGROUP = 64;

interface GpuHandle {
  device: any;
  adapter: any;
}

let cached: GpuHandle | null = null;
let probed = false;

export function webgpuDisabled(): boolean {
  if (typeof localStorage === 'undefined') return false;
  try { return localStorage.getItem('metatron_webgpu_off') === '1'; } catch { return false; }
}

export async function getWebGpuHandle(): Promise<GpuHandle | null> {
  if (webgpuDisabled()) return null;
  if (cached) return cached;
  if (probed) return null;
  probed = true;
  if (typeof navigator === 'undefined') return null;
  const gpu = (navigator as unknown as { gpu?: { requestAdapter(): Promise<any> } }).gpu;
  if (!gpu) return null;
  try {
    const adapter = await gpu.requestAdapter();
    if (!adapter) return null;
    const device = await adapter.requestDevice().catch(() => null);
    if (!device) return null;
    device.lost?.then(() => { cached = null; probed = false; }).catch(() => { /* swallow */ });
    cached = { device, adapter };
    return cached;
  } catch {
    return null;
  }
}

export interface GpuShardInput {
  readonly kStart: number;
  readonly nodes: number;
  readonly carrierHz: number;
  readonly tSeconds: number;
  readonly qScalar: number;
  readonly reflectEnabled: boolean;
  readonly computePressure: number;
}

export interface GpuShardResult {
  amplitudes: Float32Array;
  energy: number;
  coherenceNum: number;
  coherenceDen: number;
  elapsedMs: number;
}

// WGSL constants must mirror fieldKernelCore.ts exactly (f32 truncation of the
// f64 literals). Any drift here invalidates the parity gate.
const WGSL = /* wgsl */ `
struct Info {
  kStart: f32,
  nodes: u32,
  carrierHz: f32,
  tSeconds: f32,
  reflectK: f32,
  reflectK1: f32,
  phase: f32,
  isLast: u32,
};

@group(0) @binding(0) var<uniform> info: Info;
@group(0) @binding(1) var<storage, read_write> prev: array<f32>;
@group(0) @binding(2) var<storage, read_write> out:  array<f32>;
// Reductions — one atomic-free per-thread slot, host reduces on readback.
@group(0) @binding(3) var<storage, read_write> partial: array<vec4<f32>>; // (cohNum, cohDen, energy, _pad)

const PHI: f32       = 1.6180339887498949;
const LN_PHI: f32    = 0.4812118250596035;
const KAPPA: f32     = 0.19673466773621997;   // 1 / (PHI · π)
const PHI_INV_SQ: f32 = 0.3819660112501051;   // (1/φ)²
const TWO_PI: f32    = 6.283185307179586;

fn phiPow(k: f32) -> f32 {
  return exp(k * LN_PHI);
}
fn amplitudeAt(k: f32) -> f32 {
  return exp(-abs(k) * LN_PHI);
}

@compute @workgroup_size(${WORKGROUP})
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  let i = gid.x;
  if (i >= info.nodes) { return; }
  let k = info.kStart + f32(i);
  let amp     = amplitudeAt(k);
  let ampNext = amplitudeAt(k + 1.0);
  let omega   = TWO_PI * info.carrierHz * phiPow(k);
  let psiC    = KAPPA * (ampNext - amp);

  let psiL = amp * cos(omega * info.phase);
  let pv   = prev[i];
  let psiM = PHI_INV_SQ * pv;

  if (info.isLast == 1u) {
    let psiR = info.reflectK * psiL;
    let psi  = psiL + psiM + psiC + psiR;
    out[i]   = psi;
    prev[i]  = psi;
    partial[i] = vec4<f32>(psi * pv, pv * pv, psi * psi, 0.0);
  } else {
    prev[i] = psiL * info.reflectK1 + psiM + psiC;
  }
}
`;

// WebGPU numeric usage flags (avoid pulling @webgpu/types).
const U_UNIFORM  = 0x40;
const U_STORAGE  = 0x80;
const U_COPY_DST = 0x08;
const U_COPY_SRC = 0x04;
const U_MAP_READ = 0x01;
const MAP_READ   = 0x01;

interface PipelineCache {
  module: any;
  pipeline: any;
}
let pipelineCache: PipelineCache | null = null;
function getPipeline(device: any): PipelineCache {
  if (pipelineCache) return pipelineCache;
  const module = device.createShaderModule({ code: WGSL });
  const pipeline = device.createComputePipeline({
    layout: 'auto',
    compute: { module, entryPoint: 'main' },
  });
  pipelineCache = { module, pipeline };
  return pipelineCache;
}

/**
 * Run one shard end-to-end on the GPU. Returns null if WebGPU is
 * unavailable, disabled, or the dispatch failed. Never throws.
 */
export async function runShardWebGPU(input: GpuShardInput): Promise<GpuShardResult | null> {
  const handle = await getWebGpuHandle();
  if (!handle) return null;
  const { device } = handle;
  const { kStart, nodes, carrierHz, tSeconds, qScalar, reflectEnabled, computePressure } = input;
  if (nodes <= 0) return null;
  const passes = Math.max(1, Math.floor(computePressure));

  const reflectK  = reflectEnabled ? (1 / (1.6180339887498949 * 1.6180339887498949 * Math.PI)) * qScalar : 0;
  const reflectK1 = 1 + reflectK;

  const started = (typeof performance !== 'undefined' ? performance.now() : 0);

  try {
    const { pipeline } = getPipeline(device);

    // Buffers.
    const uBuf = device.createBuffer({ size: 32, usage: U_UNIFORM | U_COPY_DST });
    const prevBuf = device.createBuffer({ size: nodes * 4, usage: U_STORAGE | U_COPY_DST | U_COPY_SRC });
    const outBuf  = device.createBuffer({ size: nodes * 4, usage: U_STORAGE | U_COPY_SRC });
    const partBuf = device.createBuffer({ size: nodes * 16, usage: U_STORAGE | U_COPY_SRC });
    const outRead  = device.createBuffer({ size: nodes * 4,  usage: U_MAP_READ | U_COPY_DST });
    const partRead = device.createBuffer({ size: nodes * 16, usage: U_MAP_READ | U_COPY_DST });

    // Zero prev[].
    device.queue.writeBuffer(prevBuf, 0, new Float32Array(nodes));

    const bindGroup = device.createBindGroup({
      layout: pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: uBuf } },
        { binding: 1, resource: { buffer: prevBuf } },
        { binding: 2, resource: { buffer: outBuf } },
        { binding: 3, resource: { buffer: partBuf } },
      ],
    });

    const wgCount = Math.ceil(nodes / WORKGROUP);
    // Sequential passes — each mutates prev[].
    for (let pass = 0; pass < passes; pass++) {
      const phase = tSeconds + pass * (1 / 1.6180339887498949) * 0.000001;
      const isLast = pass === passes - 1 ? 1 : 0;
      // Info uniform: kStart, nodes, carrierHz, tSeconds, reflectK, reflectK1, phase, isLast
      const info = new ArrayBuffer(32);
      const f = new Float32Array(info);
      const u = new Uint32Array(info);
      f[0] = kStart; u[1] = nodes; f[2] = carrierHz; f[3] = tSeconds;
      f[4] = reflectK; f[5] = reflectK1; f[6] = phase; u[7] = isLast;
      device.queue.writeBuffer(uBuf, 0, info);

      const enc = device.createCommandEncoder();
      const pass_ = enc.beginComputePass();
      pass_.setPipeline(pipeline);
      pass_.setBindGroup(0, bindGroup);
      pass_.dispatchWorkgroups(wgCount);
      pass_.end();
      if (isLast === 1) {
        enc.copyBufferToBuffer(outBuf, 0, outRead, 0, nodes * 4);
        enc.copyBufferToBuffer(partBuf, 0, partRead, 0, nodes * 16);
      }
      device.queue.submit([enc.finish()]);
    }

    await outRead.mapAsync(MAP_READ);
    await partRead.mapAsync(MAP_READ);
    const amplitudes = new Float32Array(new Float32Array(outRead.getMappedRange()));
    const partView   = new Float32Array(partRead.getMappedRange()).slice();
    outRead.unmap();
    partRead.unmap();

    // Host reduction — Kahan for parity fidelity.
    let sN = 0, cN = 0, sD = 0, cD = 0, sE = 0, cE = 0;
    for (let i = 0; i < nodes; i++) {
      const base = i * 4;
      { const y = partView[base] - cN;   const t = sN + y; cN = (t - sN) - y; sN = t; }
      { const y = partView[base+1] - cD; const t = sD + y; cD = (t - sD) - y; sD = t; }
      { const y = partView[base+2] - cE; const t = sE + y; cE = (t - sE) - y; sE = t; }
    }

    // Buffer cleanup (device.destroy would kill the cached device).
    uBuf.destroy?.(); prevBuf.destroy?.(); outBuf.destroy?.(); partBuf.destroy?.();
    outRead.destroy?.(); partRead.destroy?.();

    const elapsedMs = (typeof performance !== 'undefined' ? performance.now() : 0) - started;
    return { amplitudes, coherenceNum: sN, coherenceDen: sD, energy: sE, elapsedMs };
  } catch (e) {
    if (typeof console !== 'undefined') console.warn('[WebGPUFieldKernel] dispatch failed', e);
    return null;
  }
}

// ============================================================================
// PERSISTENT SESSION — real scaling path.
// runShardWebGPU zeroes prev[] every call and re-allocates buffers, so it
// (a) can never accumulate iterative state (breaks parity) and (b) is
// dispatch-overhead bound. GpuShardSession keeps buffers and prev[] alive
// across ticks so a T-tick batch pays one setup + one readback.
// ============================================================================

export interface GpuSessionInput {
  readonly kStart: number;
  readonly nodes: number;
  readonly carrierHz: number;
  readonly qScalar: number;
  readonly reflectEnabled: boolean;
  readonly computePressure: number;
}

export interface GpuBatchResult {
  amplitudes: Float32Array;
  energy: number;
  coherenceNum: number;
  coherenceDen: number;
  elapsedMs: number;
  ticks: number;
}

export class GpuShardSession {
  private device: any;
  private uBuf: any;
  private prevBuf: any;
  private outBuf: any;
  private partBuf: any;
  private outRead: any;
  private partRead: any;
  private bindGroup: any;
  private pipeline: any;
  private readonly nodes: number;
  private destroyed = false;

  private constructor(device: any, pipeline: any, nodes: number) {
    this.device = device;
    this.pipeline = pipeline;
    this.nodes = nodes;

    this.uBuf = device.createBuffer({ size: 32, usage: U_UNIFORM | U_COPY_DST });
    this.prevBuf = device.createBuffer({ size: nodes * 4, usage: U_STORAGE | U_COPY_DST | U_COPY_SRC });
    this.outBuf  = device.createBuffer({ size: nodes * 4, usage: U_STORAGE | U_COPY_SRC });
    this.partBuf = device.createBuffer({ size: nodes * 16, usage: U_STORAGE | U_COPY_SRC });
    this.outRead  = device.createBuffer({ size: nodes * 4,  usage: U_MAP_READ | U_COPY_DST });
    this.partRead = device.createBuffer({ size: nodes * 16, usage: U_MAP_READ | U_COPY_DST });

    // Zero prev[] once at session start (mirrors the CPU pool warm state).
    device.queue.writeBuffer(this.prevBuf, 0, new Float32Array(nodes));

    this.bindGroup = device.createBindGroup({
      layout: pipeline.getBindGroupLayout(0),
      entries: [
        { binding: 0, resource: { buffer: this.uBuf } },
        { binding: 1, resource: { buffer: this.prevBuf } },
        { binding: 2, resource: { buffer: this.outBuf } },
        { binding: 3, resource: { buffer: this.partBuf } },
      ],
    });
  }

  static async create(nodes: number): Promise<GpuShardSession | null> {
    const handle = await getWebGpuHandle();
    if (!handle || nodes <= 0) return null;
    try {
      const { pipeline } = getPipeline(handle.device);
      return new GpuShardSession(handle.device, pipeline, nodes);
    } catch {
      return null;
    }
  }

  /**
   * Run `ticks` sequential ticks, reading back only the final state.
   * prev[] persists across ticks AND across batches on the same session —
   * this is what makes the GPU coherence numerically match the CPU one.
   * A single mapAsync at the end amortises the round-trip cost.
   */
  async runBatch(input: GpuSessionInput, ticks: number, tStart: number, tStep: number): Promise<GpuBatchResult | null> {
    if (this.destroyed) return null;
    const { kStart, nodes, carrierHz, qScalar, reflectEnabled, computePressure } = input;
    if (nodes !== this.nodes) return null;
    const passes = Math.max(1, Math.floor(computePressure));
    const reflectK  = reflectEnabled ? (1 / (1.6180339887498949 * 1.6180339887498949 * Math.PI)) * qScalar : 0;
    const reflectK1 = 1 + reflectK;
    const wgCount = Math.ceil(nodes / WORKGROUP);
    const started = performance.now();

    try {
      // Per-pass uniform writes are ordered against submits, so we submit per
      // pass but skip the readback until the last tick's last pass.
      for (let t = 0; t < ticks; t++) {
        const tSeconds = tStart + t * tStep;
        for (let pass = 0; pass < passes; pass++) {
          const phase = tSeconds + pass * (1 / 1.6180339887498949) * 0.000001;
          const isLastPass = pass === passes - 1 ? 1 : 0;
          const info = new ArrayBuffer(32);
          const f = new Float32Array(info);
          const u = new Uint32Array(info);
          f[0] = kStart; u[1] = nodes; f[2] = carrierHz; f[3] = tSeconds;
          f[4] = reflectK; f[5] = reflectK1; f[6] = phase; u[7] = isLastPass;
          this.device.queue.writeBuffer(this.uBuf, 0, info);

          const enc = this.device.createCommandEncoder();
          const passEnc = enc.beginComputePass();
          passEnc.setPipeline(this.pipeline);
          passEnc.setBindGroup(0, this.bindGroup);
          passEnc.dispatchWorkgroups(wgCount);
          passEnc.end();

          if (t === ticks - 1 && isLastPass === 1) {
            enc.copyBufferToBuffer(this.outBuf, 0, this.outRead, 0, nodes * 4);
            enc.copyBufferToBuffer(this.partBuf, 0, this.partRead, 0, nodes * 16);
          }
          this.device.queue.submit([enc.finish()]);
        }
      }

      await this.outRead.mapAsync(MAP_READ);
      await this.partRead.mapAsync(MAP_READ);
      const amplitudes = new Float32Array(new Float32Array(this.outRead.getMappedRange()));
      const partView = new Float32Array(this.partRead.getMappedRange()).slice();
      this.outRead.unmap();
      this.partRead.unmap();

      let sN = 0, cN = 0, sD = 0, cD = 0, sE = 0, cE = 0;
      for (let i = 0; i < nodes; i++) {
        const base = i * 4;
        { const y = partView[base]   - cN; const t = sN + y; cN = (t - sN) - y; sN = t; }
        { const y = partView[base+1] - cD; const t = sD + y; cD = (t - sD) - y; sD = t; }
        { const y = partView[base+2] - cE; const t = sE + y; cE = (t - sE) - y; sE = t; }
      }
      return {
        amplitudes, coherenceNum: sN, coherenceDen: sD, energy: sE,
        elapsedMs: performance.now() - started, ticks,
      };
    } catch (e) {
      if (typeof console !== 'undefined') console.warn('[GpuShardSession] batch failed', e);
      return null;
    }
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.uBuf.destroy?.(); this.prevBuf.destroy?.(); this.outBuf.destroy?.(); this.partBuf.destroy?.();
    this.outRead.destroy?.(); this.partRead.destroy?.();
  }
}

export const WEBGPU_FIELD_KERNEL_PROVENANCE =
  'WebGPU shard kernel (bench-only): WGSL port of fieldKernelCore.runShardKernel, ' +
  'f32 storage, workgroup=64, sequential passes. NOT wired into live engine — ' +
  'sandbox harness uses it to report |Δcoherence| vs CPU f64 reference. ' +
  'Kill switch: localStorage.metatron_webgpu_off=\'1\'. ' +
  'Use GpuShardSession for iterative batches (persistent prev[], single readback).';
