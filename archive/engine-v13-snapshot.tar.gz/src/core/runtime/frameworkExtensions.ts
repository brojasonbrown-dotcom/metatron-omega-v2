/**
 * Framework extension deriver — maps the live engine resolution + boot mode
 * to V11 numeric extension knobs for every framework that exposes one.
 *
 * CONTRACT
 * --------
 *  • `legacy` boot mode → returns `undefined`. Every framework collapses to
 *    its V10 floor (F1=7 modes, F3=n≤7, F4=13 nodes, F5=12 semis,
 *    F8=5/7/13). This preserves bit-for-bit V10 golden parity end-to-end.
 *  • `fast`   → mid-tier Fibonacci scaling (≈ F₁₃–F₁₆ envelope).
 *  • `full`   → high-tier Fibonacci scaling (≈ F₁₆–F₁₉ envelope).
 *
 * NOT INCLUDED (intentional — these require real physical data, not numeric
 * scaling, and the user explicitly demanded "TRUE COMPUTATION"):
 *  • F2.extensionParticles  — needs real QuantumParticleSpec entries
 *  • F6.extensionLetters    — needs real {char, gematria} pairs
 *  • F7.extensionBodies     — needs real {name, au} astronomical bodies
 *  • F9.multipoles          — needs real CMB peak multipole numbers
 * These are wired through the orchestrator already; leaving them undefined
 * keeps them on their V10 floors with real data rather than synthetic fake
 * entries.
 *
 * The output is TIER-STABLE: tier crossings only happen at Fibonacci M
 * thresholds (144, 6765), so the result object identity / shape stays the
 * same across thousands of ticks and the MetatronCore LRU stays warm.
 */

import type { BootMode } from './ResourceGovernor';
import type { MetatronInput } from '../MetatronCore';

export type FrameworkExtensions = NonNullable<MetatronInput['extensions']>;

/** Tier of the live resolution M relative to Fibonacci anchors. */
export type ExtensionTier = 'floor' | 'mid' | 'high';

/** Map (bootMode, M) → discrete tier so cache keys stay stable per tier. */
export function extensionTier(bootMode: BootMode, M: number): ExtensionTier {
  if (bootMode === 'legacy') return 'floor';
  // fast / full both honor M-anchored crossings so the extensions track the
  // actual field even when the user toggles modes manually.
  if (M < 144) return 'floor';
  if (M < 6765) return 'mid';
  return 'high';
}

// Frozen tier presets — same object identity per tier so the MetatronCore
// LRU sees a stable cache key.
const TIER_FLOOR: FrameworkExtensions | undefined = undefined;

const TIER_MID: FrameworkExtensions = Object.freeze({
  // F1: total chakra mode count (Math.max(7, value)). 13 ⇒ +6 φ-extension modes.
  chakraModes: 13,
  // F3: extra Bohr orbits past n=7. +6 ⇒ n≤13 (Fibonacci ladder).
  atomicShells: 6,
  // F4: extra Metatron-cube nodes past 13. +8 ⇒ 21 total.
  metatronNodes: 8,
  // F5: extra chromatic semitones past 12. +12 ⇒ 24-EDO.
  chromaticSemitones: 12,
  // F8: total ring/mode/sphere counts.
  //   rings=8  → 1+6+12+18+18 + 30+30+42 = 157 sub-Planck nodes (icosahedral spine)
  //   modes=13 → 7 canonical + 6 φ-extension vacuum modes
  //   spheres=55 → 13 Planck-flower + 42 Fibonacci extension spheres
  subPlanckianRings: 8,
  subPlanckianModes: 13,
  subPlanckianSpheres: 55,
}) as FrameworkExtensions;

const TIER_HIGH: FrameworkExtensions = Object.freeze({
  // F1: 21 total modes.
  chakraModes: 21,
  // F3: +14 ⇒ n≤21.
  atomicShells: 14,
  // F4: +42 ⇒ 55 total Metatron nodes.
  metatronNodes: 42,
  // F5: +36 ⇒ 48-EDO (microtonal full chromatic resolution).
  chromaticSemitones: 36,
  // F8: rings=13 → 451 sub-Planck nodes (V10 spine + icosahedral + hex fallback)
  //     modes=21 → 7 canonical + 14 φ-extension
  //     spheres=144 → 13 + 131 Fibonacci extension
  subPlanckianRings: 13,
  subPlanckianModes: 21,
  subPlanckianSpheres: 144,
}) as FrameworkExtensions;

/**
 * Returns a stable extensions object for the current (bootMode, M).
 * Returns `undefined` for the floor tier so the V10 golden path stays
 * bit-identical (cache key matches the no-extensions branch).
 */
export function deriveFrameworkExtensions(
  bootMode: BootMode,
  M: number,
): FrameworkExtensions | undefined {
  const tier = extensionTier(bootMode, M);
  if (tier === 'floor') return TIER_FLOOR;
  if (tier === 'mid')   return TIER_MID;
  return TIER_HIGH;
}
