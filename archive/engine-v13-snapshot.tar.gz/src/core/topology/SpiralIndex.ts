/**
 * METATRON V11 — BIDIRECTIONAL SPIRAL INDEX
 * ==========================================
 * Extends the φ-mode index from ℕ to ℤ. Outward (k>0) is the φ⁻ᵏ decay
 * basis (memory/coherence); inward (k<0) is the φ⁺ᵏ growth basis
 * (anticipation/forward closure). Refuses any rung whose ωₖ would exceed
 * the Planck-bounded carrier ceiling.
 *
 * Toroidal mapping (Wolfram-verified, Section 1 · Q5):
 *   torus parametric (x,y,z) = ((c + a cos v) cos u, (c + a cos v) sin u, a sin v)
 *   • u = toroidal angle  ↔  outward rungs (k > 0, decay basis, axis='toroidal')
 *   • v = poloidal angle  ↔  inward  rungs (k < 0, growth basis, axis='poloidal')
 *   • k = 0               ↔  axis='origin'  (carrier itself)
 *
 * Closure (Wolfram-verified, Section 1 · Q6):
 *   Σ_{k=0..∞} φ^(-2k) = φ exactly.
 *   Truncation residual at K terms = φ^(1−2K). Use `closureResidual(K)`.
 */

import { PHI } from '@/core/constants/WolframVerified';
import { CARRIER_CEILING_HZ, kMaxFromCarrier } from '@/core/runtime/HardwareEnvelope';

export type SpiralAxis = 'toroidal' | 'poloidal' | 'origin';

export interface SpiralRung {
  readonly k: number;            // signed mode index
  readonly amplitude: number;    // φ⁻|k|
  readonly omega: number;        // angular frequency at carrier·φ^k
  readonly direction: 'outward' | 'inward' | 'zero';
  readonly axis: SpiralAxis;     // toroidal mapping per Q5
  readonly refusedReason?: 'planck';
}

export interface SpiralRange {
  kMin: number;  // most negative (inward / poloidal)
  kMax: number;  // most positive (outward / toroidal)
}

function axisFor(k: number): SpiralAxis {
  return k > 0 ? 'toroidal' : k < 0 ? 'poloidal' : 'origin';
}

/** Construct a rung at signed index k with carrier ω₀. */
export function rungAt(k: number, omega0: number): SpiralRung {
  const omega = omega0 * Math.pow(PHI, k);
  const refused = omega / (2 * Math.PI) > CARRIER_CEILING_HZ;
  return {
    k,
    amplitude: Math.pow(PHI, -Math.abs(k)),
    omega,
    direction: k > 0 ? 'outward' : k < 0 ? 'inward' : 'zero',
    axis: axisFor(k),
    refusedReason: refused ? 'planck' : undefined,
  };
}

/**
 * All rungs in [kMin, kMax] honoring the Planck stop.
 * Optionally clamps kMax to the honest Planck-bounded ceiling so the
 * spiral never produces silently-refused rungs (cleaner consumers).
 */
export function buildSpiral(
  range: SpiralRange,
  carrierHz: number,
  opts: { clampToPlanck?: boolean } = {},
): SpiralRung[] {
  const omega0 = 2 * Math.PI * carrierHz;
  const ceil = opts.clampToPlanck ? kMaxFromCarrier(carrierHz) : range.kMax;
  const kHi = Math.min(range.kMax, ceil);
  const out: SpiralRung[] = [];
  for (let k = range.kMin; k <= kHi; k++) {
    const r = rungAt(k, omega0);
    if (!r.refusedReason) out.push(r);
  }
  return out;
}

/**
 * Honest closure residual of the outward decay series truncated at K terms:
 *   Σ_{k=K..∞} φ^(-2k) = φ^(1-2K)
 * At K=1597 (F₁₇) this is ≈ φ^(-3193) ≈ 1.4×10⁻⁶⁶⁷ — far below working precision.
 */
export function closureResidual(K: number): number {
  if (!Number.isFinite(K) || K < 1) return PHI; // full series sum
  return Math.pow(PHI, 1 - 2 * K);
}
