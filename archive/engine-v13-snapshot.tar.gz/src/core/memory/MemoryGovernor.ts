/**
 * MemoryGovernor — derives per-layer caps from the sovereign ResourceGovernor.
 *
 * v2 shares (sensory-aware, sums to 1.0):
 *   L-S sensory  0.20    audio + video + imu dedup tables
 *   L0 tape      0.30    continuous Ψ ring buffer
 *   L1 hebbian   0.20
 *   L2 episodic  0.12
 *   L3 semantic  0.08
 *   L4 pathway   0.05
 *   L5 journal   0.03
 *   L6 reflect   0.02    (no bytes — counted in episodic)
 */

import { getGovernorSync } from '@/core/runtime/governorSingleton';
import { PHI } from '@/core/constants/WolframVerified';
import { atomBytes } from '@/core/sensory/SensoryAtom';

export interface MemoryCaps {
  maxPatterns: number;
  maxHebbianEntries: number;
  maxPathwayEdges: number;
  maxJournalRecords: number;
  maxTapeFrames: number;
  maxEpisodes: number;
  maxSensoryAtoms: number;
  ramBytes: number;
}

const FALLBACK_RAM_BYTES = 256 * 1024 * 1024;

const SHARE = {
  sensory: 0.20,
  tape:    0.30,
  hebbian: 0.20,
  episodic:0.12,
  patterns:0.08,
  pathway: 0.05,
  journal: 0.03,
  // reflective: 0.02 reserved, no bytes (uses episodic)
};

const BYTES_PER_PATTERN = 12 * 1024;
const BYTES_PER_HEBBIAN = 16;
const BYTES_PER_EDGE = 48;
const BYTES_PER_JOURNAL = 1024;
const BYTES_PER_TAPE_FRAME = 288;            // 40-mode top-K f32 frame
const BYTES_PER_EPISODE = 2 * 1024;          // ~2 KB full top-K episode
const BYTES_PER_SENSORY = atomBytes(32);     // 32-mode top-K atom

export function computeMemoryCaps(): MemoryCaps {
  const snap = getGovernorSync();
  const ram = snap?.gov.settings.ramBytes ?? FALLBACK_RAM_BYTES;
  return {
    ramBytes: ram,
    maxSensoryAtoms:    Math.max(64,  Math.floor((ram * SHARE.sensory)  / BYTES_PER_SENSORY)),
    maxTapeFrames:      Math.max(1024,Math.floor((ram * SHARE.tape)     / BYTES_PER_TAPE_FRAME)),
    maxHebbianEntries:  Math.max(64,  Math.floor((ram * SHARE.hebbian)  / BYTES_PER_HEBBIAN)),
    maxEpisodes:        Math.max(64,  Math.floor((ram * SHARE.episodic) / BYTES_PER_EPISODE)),
    maxPatterns:        Math.max(8,   Math.floor((ram * SHARE.patterns) / BYTES_PER_PATTERN)),
    maxPathwayEdges:    Math.max(32,  Math.floor((ram * SHARE.pathway)  / BYTES_PER_EDGE)),
    maxJournalRecords:  Math.max(16,  Math.floor((ram * SHARE.journal)  / BYTES_PER_JOURNAL)),
  };
}

/** Deterministic LRU step counter helper (φ-scaled). */
export function lruScore(lastSeen: number, salience: number): number {
  return lastSeen + salience * PHI;
}
