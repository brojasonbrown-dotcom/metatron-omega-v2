/**
 * CLOSURE SOLVER — Log-space deterministic least-squares
 * ═══════════════════════════════════════════════════════════
 * Ported verbatim from V10 (`engine/v10/ClosureSolver.ts`) — pure module,
 * no engine import, no randomness.
 *
 * Treats locked anchors (CODATA, Wolfram-verified φ-forms) as boundary
 * conditions and solves for an unknown numeric quantity expressed as a
 * product/ratio of those anchors raised to integer/rational powers.
 *
 *   target = ∏ anchor_i ^ exp_i   →   log(target) = Σ exp_i · log(anchor_i)
 */

export interface ClosureInput {
  anchors: Record<string, number>;
  exponents: Record<string, number>;
  prefactor?: number;
}

export interface ClosureResult {
  value: number | null;
  log10: number | null;
  dof: number;
  usedAnchors: string[];
}

export function solveClosure(input: ClosureInput): ClosureResult {
  const { anchors, exponents, prefactor = 1 } = input;
  const used: string[] = [];
  let logSum = Math.log(prefactor > 0 ? prefactor : 1);
  let dof = 0;
  let bad = !(prefactor > 0);

  for (const name of Object.keys(exponents)) {
    const exp = exponents[name];
    if (!exp || !Number.isFinite(exp)) continue;
    const a = anchors[name];
    if (!Number.isFinite(a) || a <= 0) { bad = true; break; }
    logSum += exp * Math.log(a);
    dof += Math.abs(exp);
    used.push(name);
  }

  if (bad || used.length === 0 || !Number.isFinite(logSum)) {
    return { value: null, log10: null, dof, usedAnchors: used };
  }
  const value = Math.exp(logSum);
  if (!Number.isFinite(value) || value <= 0) {
    return { value: null, log10: null, dof, usedAnchors: used };
  }
  return { value, log10: logSum / Math.LN10, dof, usedAnchors: used };
}

/** Stability-under-perturbation probe. Re-solves with each anchor jittered by
 *  ±relSigma; returns the worst relative deviation. Stable: dev ≪ relSigma. */
export function perturbStability(
  input: ClosureInput,
  relSigma: number = 0.01,
): { nominal: number | null; maxDev: number; ok: boolean } {
  const nominal = solveClosure(input);
  if (nominal.value === null) return { nominal: null, maxDev: Infinity, ok: false };
  let maxDev = 0;
  for (const name of Object.keys(input.anchors)) {
    const orig = input.anchors[name];
    for (const sign of [-1, 1]) {
      const jittered = { ...input.anchors, [name]: orig * (1 + sign * relSigma) };
      const r = solveClosure({ ...input, anchors: jittered });
      if (r.value === null) continue;
      const dev = Math.abs(r.value - nominal.value) / Math.abs(nominal.value);
      if (dev > maxDev) maxDev = dev;
    }
  }
  return { nominal: nominal.value, maxDev, ok: maxDev < 0.1 };
}
