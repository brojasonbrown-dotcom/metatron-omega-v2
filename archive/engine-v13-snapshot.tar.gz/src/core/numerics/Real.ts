/**
 * METATRON V11 — UNIFIED REAL NUMBER (Float64 fast-path + BigDecimal extended)
 * ============================================================================
 *
 * Two precision modes share one API:
 *   - 'f64' : native IEEE-754 double. ULP ≈ 2.22e-16. Fastest.
 *   - 'bd'  : decimal.js BigDecimal at configurable precision (default 50 sig digits).
 *             ULP ≈ 1e-50. ~30× slower; honest resolution well past φ⁻²³² (≈ 2e-49).
 *
 * Why both: the engine's φ-mode basis collapses to φ⁻ᵏ for k > driverCount.
 * Float64 saturates at M ≈ 233. Extended precision lifts the honest ceiling
 * toward M ≈ 610 (F₁₅) — this matches the documented floor in the source
 * project's AutoScaler.ts (φ⁻²³² already < float64 ULP).
 *
 * Zero mock. Every operation is the real numerical operation in the chosen mode.
 */

import Decimal from 'decimal.js';

// Working precision is now DYNAMIC. Default 60 digits (covers M ≈ 210
// honestly). The engine raises it via setWorkingPrecision(requiredDigits(M))
// before promotion, so φ⁻ᴹ stays strictly above ULP at any M. There is no
// fundamental cap — cost scales O(d log d) per multiply.
Decimal.set({ precision: 60, rounding: Decimal.ROUND_HALF_EVEN });

/** Raise (or lower) the global BigDecimal working precision. */
export function setWorkingPrecision(digits: number): void {
  const d = Math.max(16, Math.floor(digits));
  Decimal.set({ precision: d, rounding: Decimal.ROUND_HALF_EVEN });
}

/** Current global BigDecimal working precision. */
export function getWorkingPrecision(): number {
  return Decimal.precision;
}

export type RealMode = 'f64' | 'bd';

export interface Real {
  readonly mode: RealMode;
  /** f64 representation. Lossy in 'bd' mode but always defined. */
  readonly f: number;
  /** BigDecimal representation. Present only in 'bd' mode. */
  readonly d?: Decimal;
}

// ───────────────────────── construction ─────────────────────────

export function real(x: number | string | Decimal, mode: RealMode = 'f64'): Real {
  if (mode === 'f64') {
    const f = typeof x === 'number' ? x : Number(x.toString());
    return { mode, f };
  }
  const d = x instanceof Decimal ? x : new Decimal(x);
  return { mode, f: Number(d.toString()), d };
}

export function lift(r: Real, mode: RealMode): Real {
  if (r.mode === mode) return r;
  if (mode === 'bd') return real(r.f.toString(), 'bd');
  return real(r.f, 'f64');
}

/** Coerce two Reals to the higher precision of the two ('bd' wins). */
function coerce(a: Real, b: Real): { a: Real; b: Real; mode: RealMode } {
  if (a.mode === 'bd' || b.mode === 'bd') {
    return { a: lift(a, 'bd'), b: lift(b, 'bd'), mode: 'bd' };
  }
  return { a, b, mode: 'f64' };
}

// ───────────────────────── arithmetic ─────────────────────────

export function add(a: Real, b: Real): Real {
  const c = coerce(a, b);
  return c.mode === 'f64' ? real(c.a.f + c.b.f) : real(c.a.d!.plus(c.b.d!), 'bd');
}

export function sub(a: Real, b: Real): Real {
  const c = coerce(a, b);
  return c.mode === 'f64' ? real(c.a.f - c.b.f) : real(c.a.d!.minus(c.b.d!), 'bd');
}

export function mul(a: Real, b: Real): Real {
  const c = coerce(a, b);
  return c.mode === 'f64' ? real(c.a.f * c.b.f) : real(c.a.d!.times(c.b.d!), 'bd');
}

export function div(a: Real, b: Real): Real {
  const c = coerce(a, b);
  return c.mode === 'f64' ? real(c.a.f / c.b.f) : real(c.a.d!.div(c.b.d!), 'bd');
}

export function neg(a: Real): Real {
  return a.mode === 'f64' ? real(-a.f) : real(a.d!.neg(), 'bd');
}

export function abs(a: Real): Real {
  return a.mode === 'f64' ? real(Math.abs(a.f)) : real(a.d!.abs(), 'bd');
}

export function pow(a: Real, n: number): Real {
  return a.mode === 'f64' ? real(Math.pow(a.f, n)) : real(a.d!.pow(n), 'bd');
}

export function sqrt(a: Real): Real {
  return a.mode === 'f64' ? real(Math.sqrt(a.f)) : real(a.d!.sqrt(), 'bd');
}

export function ln(a: Real): Real {
  return a.mode === 'f64' ? real(Math.log(a.f)) : real(a.d!.ln(), 'bd');
}

export function exp(a: Real): Real {
  return a.mode === 'f64' ? real(Math.exp(a.f)) : real(a.d!.exp(), 'bd');
}

// ───────────────────────── bd-precision trig ─────────────────────────
//
// decimal.js ships no trig. We implement sin/cos via:
//   1. argument reduction into (-π, π] using working-precision π
//   2. Taylor series with quadratic-decay termination at 10^-(prec+5)
// The series is alternating with terms x^(2n+1)/(2n+1)! so termination
// is exact once |term| < 10^-(prec+5). For x∈(-π, π] the worst-case term
// count is ≈ prec·1.2 + 20 — entirely deterministic.
//
// atan2 uses bd-precision atan via Newton on tan, with quadrant fix.
// All paths are pure functions of working precision; raise via
// setWorkingPrecision before calling at extended digit count.

let _piBd: Decimal | null = null;
let _twoPiBd: Decimal | null = null;
let _piPrec = -1;
function piBd(): Decimal {
  if (_piBd === null || _piPrec !== Decimal.precision) {
    _piBd = Decimal.acos(-1);
    _twoPiBd = _piBd.times(2);
    _piPrec = Decimal.precision;
  }
  return _piBd;
}
function twoPiBd(): Decimal {
  if (_twoPiBd === null || _piPrec !== Decimal.precision) piBd();
  return _twoPiBd!;
}

function reduceToPi(x: Decimal): Decimal {
  const tp = twoPiBd();
  let r = x.mod(tp);
  if (r.lt(0)) r = r.plus(tp);
  const p = piBd();
  if (r.gt(p)) r = r.minus(tp);
  return r;
}

function bdSin(x: Decimal): Decimal {
  const r = reduceToPi(x);
  const x2 = r.times(r);
  const eps = new Decimal(10).pow(-(Decimal.precision + 5));
  let term = r;
  let sum = r;
  const maxIter = Math.ceil(Decimal.precision * 1.5) + 30;
  for (let n = 1; n <= maxIter; n++) {
    const denom = (2 * n) * (2 * n + 1);
    term = term.times(x2).div(denom).neg();
    sum = sum.plus(term);
    if (term.abs().lt(eps)) break;
  }
  return sum;
}

function bdCos(x: Decimal): Decimal {
  const r = reduceToPi(x);
  const x2 = r.times(r);
  const eps = new Decimal(10).pow(-(Decimal.precision + 5));
  let term = new Decimal(1);
  let sum = new Decimal(1);
  const maxIter = Math.ceil(Decimal.precision * 1.5) + 30;
  for (let n = 1; n <= maxIter; n++) {
    const denom = (2 * n - 1) * (2 * n);
    term = term.times(x2).div(denom).neg();
    sum = sum.plus(term);
    if (term.abs().lt(eps)) break;
  }
  return sum;
}

// atan via argument reduction: |x|>1 → atan(x)=±π/2 - atan(1/x);
// |x|>0.5 → use half-angle identity atan(x)=2·atan(x/(1+√(1+x²))).
// Inner core: Taylor x - x³/3 + x⁵/5 - ... converges fast for |x|≤0.5.
function bdAtanCore(x: Decimal): Decimal {
  const x2 = x.times(x);
  const eps = new Decimal(10).pow(-(Decimal.precision + 5));
  let term = x;
  let sum = x;
  const maxIter = Math.ceil(Decimal.precision * 3) + 50;
  for (let n = 1; n <= maxIter; n++) {
    term = term.times(x2).neg();
    const t = term.div(2 * n + 1);
    sum = sum.plus(t);
    if (t.abs().lt(eps)) break;
  }
  return sum;
}

function bdAtan(x: Decimal): Decimal {
  const ax = x.abs();
  const sign = x.isNegative() ? -1 : 1;
  if (ax.gt(1)) {
    // atan(x) = π/2 - atan(1/x)   (for x>0)
    const inv = new Decimal(1).div(ax);
    const inner = bdAtan(inv);
    const r = piBd().div(2).minus(inner);
    return sign < 0 ? r.neg() : r;
  }
  // |x| ≤ 1 — halve once if > 0.5 for convergence speed
  if (ax.gt('0.5')) {
    const denom = new Decimal(1).plus(ax.times(ax)).sqrt().plus(1);
    const half = ax.div(denom);
    const r = bdAtanCore(half).times(2);
    return sign < 0 ? r.neg() : r;
  }
  const r = bdAtanCore(ax);
  return sign < 0 ? r.neg() : r;
}

function bdAtan2(y: Decimal, x: Decimal): Decimal {
  if (x.isZero() && y.isZero()) return new Decimal(0);
  const p = piBd();
  if (x.gt(0)) return bdAtan(y.div(x));
  if (x.lt(0)) {
    const a = bdAtan(y.div(x));
    return y.gte(0) ? a.plus(p) : a.minus(p);
  }
  // x = 0
  return y.gt(0) ? p.div(2) : p.div(2).neg();
}

export function sin(a: Real): Real {
  if (a.mode === 'f64') return real(Math.sin(a.f));
  return real(bdSin(a.d!), 'bd');
}
export function cos(a: Real): Real {
  if (a.mode === 'f64') return real(Math.cos(a.f));
  return real(bdCos(a.d!), 'bd');
}
export function atan2(y: Real, x: Real): Real {
  const c = coerce(y, x);
  if (c.mode === 'f64') return real(Math.atan2(c.a.f, c.b.f));
  return real(bdAtan2(c.a.d!, c.b.d!), 'bd');
}

// ───────────────────────── comparison ─────────────────────────

export function eq(a: Real, b: Real, tol: number = 0): boolean {
  const c = coerce(a, b);
  if (c.mode === 'f64') return Math.abs(c.a.f - c.b.f) <= tol;
  return c.a.d!.minus(c.b.d!).abs().lte(tol);
}

export function lt(a: Real, b: Real): boolean {
  const c = coerce(a, b);
  return c.mode === 'f64' ? c.a.f < c.b.f : c.a.d!.lt(c.b.d!);
}

// ───────────────────────── constants ─────────────────────────

export const ZERO_F64 = real(0);
export const ONE_F64 = real(1);
export const TWO_F64 = real(2);

export const ZERO_BD = real('0', 'bd');
export const ONE_BD = real('1', 'bd');

/** Ulp floor for a given mode — the smallest representable relative error. */
export function ulpFloor(mode: RealMode): number {
  return mode === 'f64' ? 2.220446049250313e-16 : Math.pow(10, -getWorkingPrecision());
}

export { Decimal };
