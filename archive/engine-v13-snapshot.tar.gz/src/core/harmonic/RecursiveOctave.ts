/**
 * Recursive Octave — Wolfram-cross-validated harmonic lattice.
 *
 * Source of truth: docs/OCTAVE_AUDIT.md (56/56 Wolfram queries succeeded, 2026-06-19).
 *
 * Canonical 8-tone set is a closed 3-smooth (Pythagorean) lattice: every pair
 * reduces to a ratio of the form 2^a · 3^b. 528 Hz is kept as a clearly-marked
 * legacy overlay (Solfeggio artefact, factor 11 breaks the lattice and
 * accounts for ~95% of incoherence in the 9-tone set).
 *
 * Pure module: no I/O, no engine state writes. Deterministic.
 */

export const RECURSIVE_OCTAVE_8: readonly number[] = Object.freeze([
  144, 216, 288, 324, 432, 648, 864, 1296,
]);

export const RECURSIVE_OCTAVE_LEGACY_528 = 528;

export const RECURSIVE_OCTAVE_9: readonly number[] = Object.freeze([
  144, 216, 288, 324, 432, 528, 648, 864, 1296,
]);

/** Greatest common divisor (Euclid, integer). */
function gcd(a: number, b: number): number {
  a = Math.abs(a | 0); b = Math.abs(b | 0);
  while (b) { const t = b; b = a % b; a = t; }
  return a || 1;
}

export interface PairRatio {
  a: number;          // higher frequency
  b: number;          // lower frequency
  p: number;          // numerator of reduced ratio
  q: number;          // denominator of reduced ratio
  pq: number;         // Tenney "product complexity"
  tenney: number;     // log2(p*q)
  gradus: number;     // Euler's gradus suavitatis
  coherent64: boolean;
  coherent128: boolean;
  coherent256: boolean;
}

/** Euler's gradus suavitatis Γ(n) = 1 + Σ k_i · (p_i − 1) for prime factorisation n = Π p_i^k_i. */
function gradus(n: number): number {
  if (n <= 1) return 1;
  let g = 1;
  let m = n;
  for (let p = 2; p * p <= m; p++) {
    while (m % p === 0) { g += (p - 1); m = (m / p) | 0; }
  }
  if (m > 1) g += (m - 1);
  return g;
}

/** Reduce a pair of frequencies to lowest-terms integer ratio + complexity scores. */
export function pairRatio(f1: number, f2: number): PairRatio {
  const a = Math.max(f1, f2);
  const b = Math.min(f1, f2);
  const g = gcd(a, b);
  const p = (a / g) | 0;
  const q = (b / g) | 0;
  const pq = p * q;
  return {
    a, b, p, q, pq,
    tenney: Math.log2(pq),
    gradus: gradus(p) + gradus(q) - 1,
    coherent64: pq <= 64,
    coherent128: pq <= 128,
    coherent256: pq <= 256,
  };
}

export interface LatticeReport {
  tones: readonly number[];
  pairs: PairRatio[];        // upper triangle, i<j
  total: number;
  coherent64: number;
  coherent128: number;
  coherent256: number;
  pct64: number;
  pct128: number;
  pct256: number;
  meanTenney: number;
}

export function analyzeLattice(tones: readonly number[]): LatticeReport {
  const pairs: PairRatio[] = [];
  for (let i = 0; i < tones.length; i++) {
    for (let j = i + 1; j < tones.length; j++) {
      pairs.push(pairRatio(tones[i], tones[j]));
    }
  }
  const total = pairs.length;
  const c64  = pairs.filter(r => r.coherent64).length;
  const c128 = pairs.filter(r => r.coherent128).length;
  const c256 = pairs.filter(r => r.coherent256).length;
  const meanT = total ? pairs.reduce((s, r) => s + r.tenney, 0) / total : 0;
  return {
    tones, pairs, total,
    coherent64: c64, coherent128: c128, coherent256: c256,
    pct64:  total ? c64  / total : 0,
    pct128: total ? c128 / total : 0,
    pct256: total ? c256 / total : 0,
    meanTenney: meanT,
  };
}
