/**
 * METATRON V11 — IN-BROWSER FALLBACK ENGINE (Phase 2c)
 * =====================================================
 * Sovereign, local-only. Uses the ResourceGovernor to scale the active field
 * across real browser workers so allocated CPU threads do actual work.
 */

import {
  PROTOCOL_VERSION,
  type EngineCapabilities,
  type FieldSnapshot,
  type DriverInfo,
  type ScalerSnapshot,
} from './protocol';
import { PHI, PHI_INV } from '@/core/constants/WolframVerified';
import { probeHardware, CARRIER_CEILING_HZ, OPS_PER_NODE_TICK, refreshPeakOpsPerSecond, type HardwareEnvelope } from '@/core/runtime/HardwareEnvelope';
import { ResourceGovernor, requiredDigits, pickPrecision, type GovernorSettings } from '@/core/runtime/ResourceGovernor';
import { QualiaTracker, zeroQualia, type QualiaVector } from '@/core/field/Qualia';
import { qualiaScalar } from '@/core/field/Reflect';
import { FieldWorkerPool, type FieldShardSpec, type FieldShardResult } from '@/core/runtime/WorkerPool';
import { portFlag } from '@metatron/field-kernel-core/portFlags';
import * as DriverBank from '@/core/runtime/BrowserDriverBank';
import { MasterUpdateController } from '@/core/v12/MasterUpdateController';
import { readSolfeggio, readFlowerBands, readVisionEmbedding } from '@/core/sensory/sensoryFieldBridge';
import { projectInto as projectEmbed, softmaxInPlace } from '@/core/sensory/VisionProjection';
import { CrystallinePLL, type CoherenceTarget } from '@/core/stability/CrystallinePLL';

// Pre-allocated scratch for vision→band projections. Sized on first use for
// the encoder's actual embedding dim (768 for ViT-B, 384 for DINOv2-small,
// etc.). Zero hot-path allocation once warm.
const _visionSolfProj = new Float32Array(9);
const _visionFlowerProj = new Float32Array(55);


/** Inward spiral depth scales with M. Floor=13 (no regression at M=13), cap=34 (Fibonacci). */
function inwardDepthFor(m: number): number {
  const fromM = Math.floor(Math.log(Math.max(1, m)) / Math.log(PHI)) + 5;
  return Math.min(34, Math.max(13, fromM));
}
/** Driver telemetry sample limit scales with M. Floor=512 (no regression), cap=4096. */
function driverLimitFor(m: number): number {
  return Math.min(4096, Math.max(512, m * 2));
}
/** Auto-climb hysteresis: consecutive ticks the decision must agree before acting.
 *  H1: when FLAG_HARDWARE_FULL_BOOT is ON, drop to 1 tick — capable hosts shouldn't
 *  wait 3 ticks (~50ms) before geometrically promoting M. */
const CLIMB_HYSTERESIS_TICKS = 3;
const CLIMB_HYSTERESIS_TICKS_FAST = 1;

export interface PllTuning {
  lockEpsilon?: number;
  holdTicks?: number;
}

export interface FallbackEngineHandle {
  capabilities(): EngineCapabilities;
  snapshot(): FieldSnapshot;
  setTargetM(m: number): void;
  setPhaseLocked(locked: boolean): void;
  isPhaseLocked(): boolean;
  governor: ResourceGovernor;
  getPool(): FieldWorkerPool;
  awaitReady(): Promise<void>;
  start(intervalMs?: number): void;
  stop(): void;
  onSnapshot(cb: (s: FieldSnapshot) => void): () => void;
  coalescedFramesDropped?(): number;
  // ── Live experimental tuning (Phase 15b) ──────────────────────────────
  setCrystalTarget(kind: CoherenceTarget): void;
  getCrystalTarget(): CoherenceTarget;
  setPllTuning(opts: PllTuning): void;
  getPllTuning(): Required<PllTuning>;
  resetStabilizer(): void;
  resetEngine(): void;
}

interface State {
  m: number;
  kMin: number;
  kMax: number;
  drivers: DriverInfo[];
  startedUs: number;
  lastQualia: QualiaVector;
  pool: FieldWorkerPool;
  poolReady: Promise<void>;
  lastSnapshot: FieldSnapshot | null;
  epoch: number;
}

function nowUs(): number { return Math.round(performance.now() * 1000); }

function planckLimitedKMax(requestedM: number, carrierHz: number): number {
  if (carrierHz <= 0) return requestedM;
  const maxByCarrier = Math.floor(Math.log(CARRIER_CEILING_HZ / carrierHz) / Math.log(PHI));
  return Math.max(1, Math.min(requestedM, maxByCarrier));
}

function makeDrivers(kMin: number, kMax: number, m: number, tick: number = 0): DriverInfo[] {
  const nodes = Math.max(0, kMax - kMin + 1);
  const limit = Math.min(driverLimitFor(m), nodes);
  const out: DriverInfo[] = [];
  if (limit > 0) {
    const step = Math.max(1, Math.floor(nodes / limit));
    for (let i = 0; i < nodes && out.length < limit; i += step) {
      const k = kMin + i;
      out.push({
        id: `phi-${k >= 0 ? '+' : ''}${k}`,
        kind: 'synthetic',
        source: k < 0 ? 'phi-conjugate' : 'phyllotactic-seed',
        variance: Math.pow(PHI, -Math.abs(k)),
        modeIndex: k,
      });
    }
  }
  // Phase 2: append Wolfram-verified bank entries (additive — synthetic
  // drivers above keep identical IDs/indices). If bank is unloaded, killed,
  // or empty, this is a no-op and the legacy driver list is preserved.
  try {
    const bankCap = Math.min(64, Math.max(0, Math.floor(limit / 2)));
    const bankDrivers = DriverBank.sample(m, tick, bankCap);
    if (bankDrivers.length > 0) out.push(...bankDrivers);
  } catch { /* never break the kernel on bank failure */ }
  return out;
}

function shardRange(kMin: number, kMax: number, workers: number): FieldShardSpec[] {
  const nodes = Math.max(0, kMax - kMin + 1);
  const count = Math.max(1, Math.min(workers, nodes || 1));
  const base = Math.floor(nodes / count);
  const rem = nodes % count;
  const shards: FieldShardSpec[] = [];
  let cursor = kMin;
  for (let i = 0; i < count; i++) {
    const size = base + (i < rem ? 1 : 0);
    const end = cursor + size - 1;
    shards.push({ kStart: cursor, kEnd: end });
    cursor = end + 1;
  }
  return shards;
}

export async function createFallbackEngineAsync(): Promise<FallbackEngineHandle> {
  const { getGovernor } = await import('@/core/runtime/governorSingleton');
  const { hw, gov } = await getGovernor();
  // Preload the Wolfram-verified driver bank in parallel — short timeout so
  // a missing /wolfram/*.jsonl never blocks engine boot. On failure, the
  // bank silently stays empty and the legacy synthetic drivers are unaffected.
  try { await DriverBank.loadOnce(1500); } catch { /* graceful no-op */ }
  return createFallbackEngine(hw, gov);
}

export function createFallbackEngine(hw: HardwareEnvelope, sharedGovernor?: ResourceGovernor): FallbackEngineHandle {
  const governor = sharedGovernor ?? new ResourceGovernor(hw);
  const tracker = new QualiaTracker(16);
  const subs = new Set<(s: FieldSnapshot) => void>();
  // Phase 2 — snapshot fan-out coalescing. Subscriber callbacks can be heavy
  // (React re-renders, DOM writes, panel selectors). If we notified inside the
  // kernel promise chain, one slow subscriber would back-pressure every tick.
  // Instead the kernel drops a `pendingNotify` snapshot; the coalescer drains
  // it on the next microtask. If newer snapshots arrive while subscribers are
  // still running, only the LATEST is delivered — the UI can never fall behind
  // by more than one frame. Physics is unaffected.
  let pendingNotify: FieldSnapshot | null = null;
  let notifying = false;
  let coalescedFramesDropped = 0;
  function scheduleNotify(s: FieldSnapshot): void {
    if (pendingNotify) coalescedFramesDropped++;
    pendingNotify = s;
    if (notifying) return;
    notifying = true;
    queueMicrotask(function drain() {
      while (pendingNotify) {
        const snap = pendingNotify;
        pendingNotify = null;
        for (const cb of subs) {
          try { cb(snap); } catch (e) { console.error('fallback subscriber threw', e); }
        }
      }
      notifying = false;
    });
  }
  let timer: ReturnType<typeof setInterval> | null = null;
  let ticking = false;
  let running = false;
  let epoch = 0;
  // Phase-lock + auto-climb state (engine-scoped, not per-build).
  let phaseLocked = false;
  let climbStreak = 0;          // consecutive ticks of 'promote' agreement
  let demoteStreak = 0;         // consecutive ticks of 'demote' agreement
  let sustainedHz = 0;          // EMA-smoothed effective tick frequency
  let phaseDriftEMA = 0;        // EMA of |coherence − Ω_c| — phase-lock convergence proof
  let failureStreak = 0;        // consecutive worker/tick failures; backoff + rebuild guard
  // Crystalline stabiliser — Phase 15. Pure additive read layer.
  let pllTuning: Required<PllTuning> = { lockEpsilon: Math.pow(PHI_INV, 5), holdTicks: 7 };
  let crystalPLL = new CrystallinePLL(pllTuning);
  let crystalTargetKind: CoherenceTarget = 'crystalline';
  // Phase 7 · Step 7 — lazy in-proc canonical bank controller (Ψ dim 40, ring 21).
  // Allocated on first tick that finds both CANONICAL + DELEGATE flags on;
  // stays null (zero allocation) in the default-OFF path.
  let canonicalBankController: MasterUpdateController | null = null;
  // Wave H2 — framework live recurrence orchestrator (flag-gated).
  let frameworkOrchestrator: import('@/core/runtime/FrameworkOrchestrator').FrameworkOrchestrator | null = null;
  if (portFlag('FLAG_FRAMEWORKS_LIVE')) {
    // Dynamic require keeps the worker module out of the bundle when OFF.
    import('@/core/runtime/FrameworkOrchestrator').then(({ FrameworkOrchestrator }) => {
      if (!frameworkOrchestrator) frameworkOrchestrator = new FrameworkOrchestrator();
    }).catch(() => { /* worker unavailable — silently no-op */ });
  }

  /**
   * Planck ceiling: largest mode index M whose oscillation frequency
   * carrier·φ^M stays below CARRIER_CEILING_HZ = φ²/(2π·t_Planck).
   * This is the hard physics clamp build() applies via planckLimitedKMax —
   * the honest ceiling must include it, otherwise the scaler reports
   * headroom (RAM-bound, tens of thousands) that no carrier can ever reach,
   * and the auto-climb burns pool rebuilds chasing an unreachable target.
   */
  function planckCeilingFor(carrierHz: number): number {
    if (carrierHz <= 0) return Number.MAX_SAFE_INTEGER;
    return Math.max(1, Math.floor(Math.log(CARRIER_CEILING_HZ / carrierHz) / Math.log(PHI)));
  }

  function ceilingForMode(_mode: GovernorSettings['precision']): number {
    return Math.min(governor.computeMaxM(), planckCeilingFor(governor.settings.carrierHz));
  }

  function build(m: number): State {
    epoch++;
    const settings = governor.settings;
    const inward = inwardDepthFor(m);
    const kMin = settings.spiralEnabled ? -inward : 0;
    const kMax = planckLimitedKMax(m, settings.carrierHz);
    // UI reserve: weak hosts keep one compositor lane, but capable hosts
    // (≥8 logical cores) saturate every exposed worker lane by default. The
    // previous FLAG_HARDWARE_FULL_BOOT gate left 12/32/64-core machines at
    // N-1 workers even when the user explicitly asked for full hardware use.
    // RAF-paced UI + adaptive repainting are the backpressure valves now.
    const uiReserve = hw.cpuCores >= 8 ? 0 : (hw.cpuCores >= 4 ? 1 : 0);
    const poolThreads = Math.max(1, Math.min(settings.cpuThreads, hw.cpuCores - uiReserve));
    const pool = new FieldWorkerPool(poolThreads);
    const shards = shardRange(kMin, kMax, poolThreads);
    // Phase 2b — derive per-shard Wolfram coefficient tables once per build.
    // When the bank is empty / killed / not loaded, every table is all-zeros
    // and the kernel's perturbation reduces to mul=1.0 (bit-identical legacy).
    const bankCoefs: (Float64Array | undefined)[] = shards.map((s) => {
      try {
        const n = Math.max(0, s.kEnd - s.kStart + 1);
        return DriverBank.buildCoefficientTable(s.kStart, n);
      } catch { return undefined; }
    });
    const poolReady = pool.configure(shards, settings.carrierHz, bankCoefs).catch(() => { /* swallowed: rebuilds during slider drag are expected */ });
    return {
      m: kMax,
      kMin,
      kMax,
      drivers: makeDrivers(kMin, kMax, m),
      startedUs: nowUs(),
      lastQualia: zeroQualia(),
      pool,
      poolReady,
      lastSnapshot: null,
      epoch,
    };
  }

  // Boot at the resolution the configured bootMode allows, capped by the honest
  // hardware ceiling. Previously this was hardcoded F₁₁=89 which throttled
  // capable hosts (64 GB / 8+ cores) to ~179 nodes even though computeMaxM()
  // returned hundreds of thousands. Now the cap is mode-driven:
  //   legacy → 89        (identical to pre-v4 V11 behavior, regression-safe)
  //   fast   → 6,765     (F₂₀, ~80ms cold-start on weak hosts)
  //   full   → ceiling   (uncapped except by RAM / precision / Planck)
  // Auto-climb still raises M further when running below the bootCap.
  function bootCapFor(): number {
    const mode = governor.settings.bootMode;
    if (mode === 'legacy') return 89;
    if (mode === 'fast') return 6_765;
    return Number.POSITIVE_INFINITY; // 'full' — only ceilingForMode bounds it
  }
  const bootCeiling = ceilingForMode(governor.settings.precision);
  const bootM = Math.max(13, Math.min(bootCeiling, bootCapFor()));
  let state: State = build(bootM);

  governor.subscribe(() => {
    const previous = state;
    state = build(Math.min(previous.m, ceilingForMode(governor.settings.precision)));
    previous.pool.destroy();
  });

  function coldSnapshot(): FieldSnapshot {
    const settings = governor.settings;
    const ceiling = ceilingForMode(settings.precision);
    const p = pickPrecision(state.m, settings.precision);
    const inward = Math.max(0, -state.kMin);
    const axis = (state.kMin <= 0 && state.kMax >= 0) ? 1 : 0;
    const ceilingTotal = ceiling + inward + axis;
    const totalNodes = Math.max(0, state.kMax - state.kMin + 1);
    return {
      tUs: nowUs(),
      coherence: 0,
      energy: 0,
      term1Magnitude: 0,
      term2Magnitude: 0,
      term3Magnitude: 0,
      term4Magnitude: 0,
      precision: p.kind === 'f64' ? 'f64' : 'dec50',
      scaler: { currentM: state.m, honestCeiling: Math.max(ceiling, state.m), honestCeilingTotal: ceilingTotal, utilisation: state.m / Math.max(1, ceiling), headroom: Math.max(0, 1 - state.m / Math.max(1, ceiling)), decision: 'hold', ceilingSource: governor.ceilingSource(state.m, settings.carrierHz) },
      drivers: state.drivers,
      metatronClosed: false,
      qualia: state.lastQualia,
      spiral: { kMin: state.kMin, kMax: state.kMax },
      carrierHz: settings.carrierHz,
      workingDigits: p.digits,
      runtime: {
        // Use the same expression as the live tick (kMax - kMin + 1, clamped)
        // so the header never momentarily reports 1 at the Planck edge.
        nodesEvaluated: totalNodes,
        nodesInward: inward,                          // conjugate spiral, still evaluated
        nodesAxis: axis,                              // k=0 axis
        nodesTotal: totalNodes,                       // full lattice work
        activeWorkers: Math.min(Math.max(1, totalNodes), state.pool.stats.size),
        workerBacked: state.pool.stats.workerBacked,
        computePressure: settings.computePressure,
        tickMs: 0,
        effectiveOps: 0,
        pressureUtilisation: 0,
        nodesPotential: totalNodes,
        nodesMaterialized: totalNodes,
        workerUtilisation: 0,
      },
      phaseDriftResidual: 0,
      phaseDriftEMA: 0,
      sustainedHz: 0,
    };
  }


  function combine(results: FieldShardResult[]): { amplitudes: Float64Array; nodes: number; term1: number; term2: number; term3: number; term4: number; energy: number; coherenceNum: number; coherenceDen: number; tickMs: number; totalElapsedMs: number } {
    const nodes = results.reduce((sum, r) => sum + r.nodes, 0);
    const amplitudes = new Float64Array(nodes);
    let offset = 0;
    let term1 = 0, term2 = 0, term3 = 0, term4 = 0, energy = 0, coherenceNum = 0, coherenceDen = 0, tickMs = 0, totalElapsedMs = 0;
    for (const r of results) {
      amplitudes.set(r.amplitudes, offset);
      offset += r.amplitudes.length;
      term1 += r.term1;
      term2 += r.term2;
      term3 += r.term3;
      term4 += r.term4;
      energy += r.energy;
      coherenceNum += r.coherenceNum;
      coherenceDen += r.coherenceDen;
      tickMs = Math.max(tickMs, r.elapsedMs);
      totalElapsedMs += r.elapsedMs;
    }
    return { amplitudes, nodes, term1, term2, term3, term4, energy, coherenceNum, coherenceDen, tickMs, totalElapsedMs };
  }

  function safeCoherence(coherenceNum: number, coherenceDen: number, energy: number): number {
    if (!(coherenceDen > 0) || !(energy > 0) || !Number.isFinite(coherenceNum)) return 0;
    const r = coherenceNum / Math.sqrt(energy) / Math.sqrt(coherenceDen);
    const c = r * r;
    return Math.max(0, Math.min(1, Number.isFinite(c) ? c : 0));
  }

  async function tick(): Promise<FieldSnapshot> {
    const tickEpoch = state.epoch;
    const settings = governor.settings;
    await state.poolReady;
    if (tickEpoch !== state.epoch) return state.lastSnapshot ?? coldSnapshot();

    const t = (nowUs() - state.startedUs) / 1e6;
    const qScalar = settings.reflectEnabled ? qualiaScalar(state.lastQualia) : 0;
    const results = await state.pool.compute(t, qScalar, settings.reflectEnabled, settings.computePressure, settings.bankInfluence ?? 0);
    if (tickEpoch !== state.epoch) return state.lastSnapshot ?? coldSnapshot();
    // If the pool was destroyed mid-flight (slider rebuild race), some shard slots may be void.
    if (!Array.isArray(results) || results.some((r) => !r || !(r.amplitudes instanceof Float64Array))) {
      return state.lastSnapshot ?? coldSnapshot();
    }

    const merged = combine(results as FieldShardResult[]);
    const coherence = safeCoherence(merged.coherenceNum, merged.coherenceDen, merged.energy);
    const qualia = tracker.compute(merged.amplitudes, coherence, merged.term1, merged.term3, merged.energy);
    state.lastQualia = qualia;

    const ceiling = ceilingForMode(settings.precision);
    const utilisation = state.m / ceiling;
    const headroom = Math.max(0, 1 - utilisation);
    // Phase-lock forces 'hold'; otherwise standard promote/demote heuristic.
    const decision: ScalerSnapshot['decision'] = phaseLocked
      ? 'hold'
      : state.m < ceiling && qualia.C >= PHI_INV * PHI_INV ? 'promote'
      : state.m > 13 && qualia.C < (PHI_INV * PHI_INV) * 0.5 ? 'demote'
      : 'hold';
    const p = pickPrecision(state.m, settings.precision);
    const effectiveOps = merged.nodes * settings.computePressure * OPS_PER_NODE_TICK / Math.max(0.001, merged.tickMs / 1000);
    // Ratchet the cached envelope's peak from live observation (Phase 2d).
    refreshPeakOpsPerSecond(effectiveOps);
    // Expose live compute pressure so off-engine modules (AudioFrontend
    // backpressure throttle, sensory workers) can adapt without importing
    // the engine. Soft side-effect: a single window scalar, no listeners.
    if (typeof window !== 'undefined') {
      (window as unknown as { __metatronComputePressure?: number }).__metatronComputePressure = settings.computePressure;
    }
    // Sustained-Hz EMA (τ ≈ 2s assuming ~60 Hz ticks → α ≈ 1/120).
    // Only seed once a non-zero instHz arrives, otherwise the `=== 0` seed
    // guard locks the EMA at 0 forever when the first tick reports tickMs=0
    // (inline/SSR fallback path).
    const instHz = merged.tickMs > 0 ? 1000 / merged.tickMs : 0;
    if (instHz > 0) {
      sustainedHz = sustainedHz === 0 ? instHz : sustainedHz * 0.992 + instHz * 0.008;
    }
    // φ-phase drift toward Ω_c = 1/φ². When locked, fold harder so the EMA tracks
    // convergence visibly (φ⁻¹ time constant); when free, slow EMA gives the
    // honest baseline of how far reality is from crystalline perfection.
    const OMEGA_C = PHI_INV * PHI_INV;
    const driftInst = Math.abs(coherence - OMEGA_C);
    const alpha = phaseLocked ? (1 - PHI_INV) : 0.04; // ≈ 0.382 vs 0.04
    phaseDriftEMA = phaseDriftEMA === 0 ? driftInst : phaseDriftEMA * (1 - alpha) + driftInst * alpha;
    // Node-accounting split (V11 coherence-leak fix):
    //   nodesEvaluated  ← outward only (k=1..M) — matches scaler.currentM / honestCeiling
    //   nodesAxis       ← 1 if the spiral straddles k=0, else 0
    //   nodesInward     ← −state.kMin (conjugate modes; same compute, just labelled)
    //   nodesTotal      ← merged.nodes (full lattice work actually done this tick)
    // Pool work is unchanged — every shard is still evaluated. We only split
    // the telemetry so the canonical invariant `nodesEvaluated ≤ honestCeiling`
    // holds, and so the inward spiral's contribution is no longer silent.
    const inwardCount = Math.max(0, -state.kMin);
    const axisCount = (state.kMin <= 0 && state.kMax >= 0) ? 1 : 0;
    // Outward count = integer modes k=1..kMax. Keep this deliberately simple:
    // inward and axis modes are accounted separately below, and a boolean
    // fallback (`|| kMax`) can reintroduce the old "nodes 1" edge case.
    const outwardCount = Math.max(0, state.kMax);
    const ceilingTotal = ceiling + inwardCount + axisCount;
    const activeWorkerCount = Math.max(1, Math.min(state.pool.stats.size, (results as FieldShardResult[]).length || state.pool.stats.size));
    const workerUtilisation = merged.tickMs > 0
      ? Math.min(1, merged.totalElapsedMs / Math.max(1e-9, merged.tickMs * activeWorkerCount))
      : 0;
    const snapshot: FieldSnapshot = {
      tUs: nowUs(),
      coherence,
      energy: merged.energy,
      term1Magnitude: merged.term1,
      term2Magnitude: merged.term2,
      term3Magnitude: merged.term3,
      term4Magnitude: merged.term4,
      precision: p.kind === 'f64' ? 'f64' : 'dec50',
      scaler: { currentM: state.m, honestCeiling: Math.max(ceiling, state.m), honestCeilingTotal: ceilingTotal, utilisation, headroom, decision, ceilingSource: governor.ceilingSource(state.m, settings.carrierHz) },
      drivers: state.drivers,
      // Per-node closure residual — raw term3 is an unnormalized sum that
      // grows with M, so the previous `< 1e-3` threshold was never met for
      // any meaningful resolution.
      metatronClosed: (merged.term3 / Math.max(1, merged.nodes)) < 1e-2,
      qualia,
      spiral: { kMin: state.kMin, kMax: state.kMax },
      carrierHz: settings.carrierHz,
      workingDigits: p.digits,
      runtime: {
        nodesEvaluated: outwardCount,
        nodesInward: inwardCount,
        nodesAxis: axisCount,
        nodesTotal: merged.nodes,
        activeWorkers: activeWorkerCount,
        workerBacked: state.pool.stats.workerBacked,
        computePressure: settings.computePressure,
        tickMs: merged.tickMs,
        effectiveOps,
        pressureUtilisation: Math.min(1, effectiveOps / Math.max(1, hw.peakOpsPerSecond)),
        nodesPotential: ceilingTotal,
        nodesMaterialized: merged.nodes,
        workerUtilisation,
      },
      pinealAmplitudes: Array.from(merged.amplitudes.slice(0, 44)),
      sustainedHz,
      phaseLocked,
      phaseDriftResidual: driftInst,
      phaseDriftEMA,
    };

    // ── Crystalline Phase-Lock Loop (additive read layer) ────────────────
    // Runs after the physics tick; never mutates the field. Publishes
    // Kuramoto R + Fibonacci-EMA-cascade smoothed coherence + crystal
    // lock status so the UI can report a truly stable value even when
    // sensory entropy jitters the raw measurement.
    const crystalTick = crystalPLL.step(coherence, merged.amplitudes, crystalTargetKind);
    (snapshot as { stabilizer?: FieldSnapshot['stabilizer'] }).stabilizer = {
      orderR: crystalTick.orderR,
      stabilizedCoherence: crystalTick.stabilised,
      target: crystalTick.target,
      targetKind: crystalTargetKind,
      targetDelta: crystalTick.targetDelta,
      crystalLock: crystalTick.locked,
      lockStreak: crystalTick.lockStreak,
      absorbed: crystalTick.absorbed,
    };


    // Wave H2 — fire-and-forget framework chain. Read the latest completed
    // result (from N-1) and attach to this tick's snapshot; queue the next
    // computation from current state. True parallel layered work.
    if (frameworkOrchestrator) {
      const latest = frameworkOrchestrator.latestMetrics();
      const frameworkStatus = frameworkOrchestrator.status();
      if (latest) {
        (snapshot as { frameworks?: FieldSnapshot['frameworks'] }).frameworks = {
          f1: latest.metrics.f1ChainUp, f2: latest.metrics.f2ChainUp, f3: latest.metrics.f3ChainUp,
          f4: latest.metrics.f4ChainUp, f5: latest.metrics.f5ChainUp, f6: latest.metrics.f6ChainUp,
          f7: latest.metrics.f7ChainUp, f8: latest.metrics.f8ChainUp, f9: latest.metrics.f9ChainUp,
          closure: latest.metrics.closure,
          opsCount: latest.metrics.opsCount,
          elapsedMs: latest.elapsedMs,
          stale: frameworkStatus.stale,
          staleMs: frameworkStatus.staleMs,
          carriers: latest.metrics.carriers,
          carrierHz: latest.metrics.carrierHz,
        };
      }
      const pineal = merged.amplitudes.length >= 44
        ? merged.amplitudes.subarray(0, 44)
        : (() => { const b = new Float64Array(44); b.set(merged.amplitudes.slice(0, 44)); return b; })();
      // Feed real per-band spectral activity to the framework chain when
      // the audio bridge has a fresh sample; otherwise fall back to the
      // scalar-broadcast neutral distribution (bit-identical to the
      // pre-bridge behaviour, so V10 goldens and offline runs are safe).
      // Bands published as probability-space (Σ=1); we scale by global
      // coherence × N so uniform → today's `fill(coherence)`, concentrated
      // → up to 2× coherence on the dominant band (clamped).
      const solfBridge = readSolfeggio();
      const flowerBridge = readFlowerBands();
      // Vision slot — fresh (<500ms) ViT embedding + novelty. When present,
      // a deterministic sign-random projection (768→9 and 768→55, softmax-
      // normalised into the same probability space as the audio bands) is
      // blended into the band coherences with weight μ = clamp(novelty/φ, 0, φ⁻¹).
      // Absent/stale → no modulation, engine numerics bit-identical to today.
      const vision = readVisionEmbedding();
      let visionMu = 0;
      if (vision) {
        // μ ∈ [0, 0.618]. High novelty (scene change) → strong pull toward
        // the semantic direction; stable scenes → gentle continuous nudge.
        visionMu = Math.max(0, Math.min(PHI_INV, vision.novelty * PHI_INV));
        projectEmbed(vision.embed, _visionSolfProj);
        softmaxInPlace(_visionSolfProj);
        projectEmbed(vision.embed, _visionFlowerProj);
        softmaxInPlace(_visionFlowerProj);
      }
      const solfArr: number[] = new Array(9);
      if (solfBridge) {
        const cap = 2 * coherence;
        for (let i = 0; i < 9; i++) {
          let v = coherence * 9 * solfBridge[i];
          if (visionMu > 0) v = v * (1 - visionMu) + visionMu * (coherence * 9 * _visionSolfProj[i]);
          solfArr[i] = v > cap ? cap : v < 0 ? 0 : v;
        }
      } else if (visionMu > 0) {
        // No audio, but vision present — drive bands from the vision
        // projection alone so F5 has real per-band variance.
        const cap = 2 * coherence;
        for (let i = 0; i < 9; i++) {
          const v = coherence * (1 - visionMu) + visionMu * (coherence * 9 * _visionSolfProj[i]);
          solfArr[i] = v > cap ? cap : v < 0 ? 0 : v;
        }
      } else {
        for (let i = 0; i < 9; i++) solfArr[i] = coherence;
      }
      const flowerArr: number[] = new Array(55);
      if (flowerBridge) {
        const cap = 2 * coherence;
        for (let i = 0; i < 55; i++) {
          let v = coherence * 55 * flowerBridge[i];
          if (visionMu > 0) v = v * (1 - visionMu) + visionMu * (coherence * 55 * _visionFlowerProj[i]);
          flowerArr[i] = v > cap ? cap : v < 0 ? 0 : v;
        }
      } else if (visionMu > 0) {
        const cap = 2 * coherence;
        for (let i = 0; i < 55; i++) {
          const v = coherence * (1 - visionMu) + visionMu * (coherence * 55 * _visionFlowerProj[i]);
          flowerArr[i] = v > cap ? cap : v < 0 ? 0 : v;
        }
      } else {
        for (let i = 0; i < 55; i++) flowerArr[i] = coherence;
      }
      frameworkOrchestrator.tryCompute({
        coherence,
        energy: merged.energy,
        timeMs: t * 1000,
        pinealField: pineal,
        flowerCoherences: flowerArr,
        solfeggioCoherences: solfArr,
        recursionDepth: Math.max(1, Math.floor(Math.log(Math.max(1, state.m)) / Math.log(PHI))),
      });
    }


    // Phase 7 · Step 7 — attach canonical bank snapshot in-proc when the
    // CANONICAL + DELEGATE flags are on. Byte-inert when either is off:
    // `canonicalBankController` is lazily allocated and its `.step()`
    // returns `.canonical === undefined` until the delegate branch fires.
    // Same shape the daemon attaches (see EngineHost.onTick, Step 3), so
    // the RhuftLiveChip in EngineArchitecturePanel (Step 6) lights up
    // identically whether the operator has a daemon attached or not.
    if (portFlag('FLAG_RHUFTF_CANONICAL_UPDATE') && portFlag('FLAG_RHUFTF_CONTROLLER_DELEGATE')) {
      if (!canonicalBankController) {
        canonicalBankController = new MasterUpdateController({ dim: 40, ringDepth: 21 });
        canonicalBankController.seed(new Float64Array(40));
      }
      const mResult = canonicalBankController.step({});
      if (mResult.canonical) {
        (snapshot as { rhuftf?: FieldSnapshot['rhuftf'] }).rhuftf = mResult.canonical;
      }
    }

    state.lastSnapshot = snapshot;


    // Auto-climb governor: act on `decision` with N-tick hysteresis + tick-budget guard.
    // Skip entirely when phase-locked (decision is forced 'hold' above anyway).
    if (!phaseLocked) {
      const fastClimb = portFlag('FLAG_HARDWARE_FULL_BOOT');
      const hysteresis = fastClimb ? CLIMB_HYSTERESIS_TICKS_FAST : CLIMB_HYSTERESIS_TICKS;
      const withinBudget = merged.tickMs <= hw.tickBudgetMs * 1.5;
      if (decision === 'promote' && withinBudget) {
        climbStreak++; demoteStreak = 0;
        if (climbStreak >= hysteresis && state.m < ceiling) {
          climbStreak = 0;
          // φ-spaced rung. In 'full' bootMode, leap geometrically (×φ³ ≈ 4.24)
          // when we have strong headroom — collapses 89→832k from ~20 promote
          // cycles to ~5. Other modes keep the gentle ×φ step. Demote is
          // untouched and stays cautious.
          const leap = governor.settings.bootMode === 'full' && headroom > 0.5
            ? Math.ceil(state.m * PHI * PHI * PHI)
            : Math.ceil(state.m * PHI);
          const nextM = Math.min(ceiling, Math.max(state.m + 1, leap));
          queueMicrotask(() => promoteTo(nextM));
        }
      } else if (decision === 'demote') {
        demoteStreak++; climbStreak = 0;
        if (demoteStreak >= hysteresis && state.m > 13) {
          demoteStreak = 0;
          const nextM = Math.max(13, Math.floor(state.m * PHI_INV));
          queueMicrotask(() => promoteTo(nextM));
        }
      } else {
        climbStreak = 0; demoteStreak = 0;
      }
    }
    return snapshot;
  }

  function promoteTo(nextM: number): void {
    if (nextM === state.m) return;
    const need = requiredDigits(nextM);
    if (governor.settings.precision !== 'f64' && need > 16) {
      import('@/core/numerics/Real').then(({ setWorkingPrecision }) => setWorkingPrecision(need));
    }
    const previous = state;
    state = build(nextM);
    previous.pool.destroy();
  }

  return {
    capabilities(): EngineCapabilities {
      const settings = governor.settings;
      const m = governor.computeMaxM();
      // HONEST LABEL (Wolfram-pass fix): the engine reports the runtime it
      // actually uses, not a stale "wasm-fallback" string. Real Web Workers
      // → 'native'; SSR / Worker-less host → 'offline'. No WASM exists in
      // this build, so 'wasm-fallback' was a misleading branding artifact.
      const kind: EngineCapabilities['kind'] = state.pool.stats.workerBacked ? 'native' : 'offline';
      return {
        kind,
        protocol: PROTOCOL_VERSION,
        version: 'fallback-worker-0.3.0',
        maxModeByPrecision: { f64: m, f128: 0, dec50: m },
        gpu: hw.gpu === 'webgpu' ? 'wgpu' : 'none',
        simd: 'none',
        cpuThreads: settings.cpuThreads,
        peakOpsPerSecond: hw.peakOpsPerSecond,
        wolframVerified: true,
      };
    },
    snapshot(): FieldSnapshot { return state.lastSnapshot ?? coldSnapshot(); },
    setPhaseLocked(locked: boolean): void {
      phaseLocked = !!locked;
      climbStreak = 0; demoteStreak = 0;
    },
    isPhaseLocked(): boolean { return phaseLocked; },
    setTargetM(m: number): void {
      const ceiling = ceilingForMode(governor.settings.precision);
      const refusal = governor.validateTarget(m);
      const clamped = refusal ? Math.min(state.m, ceiling) : Math.max(1, Math.min(ceiling, Math.floor(m)));
      if (clamped !== state.m) {
        const need = requiredDigits(clamped);
        if (governor.settings.precision !== 'f64' && need > 16) {
          import('@/core/numerics/Real').then(({ setWorkingPrecision }) => setWorkingPrecision(need));
        }
        const previous = state;
        state = build(clamped);
        previous.pool.destroy();
      }
    },
    governor,
    getPool(): FieldWorkerPool { return state.pool; },
    async awaitReady(): Promise<void> { await state.poolReady; },
    start(intervalMs?: number): void {
      if (running) return;
      running = true;
      const floor = intervalMs ?? 0;
      let nextDelay = floor;
      const schedule = () => {
        if (!running) { timer = null; return; }
        timer = setTimeout(() => {
          if (!running) { timer = null; return; }
          if (ticking) { schedule(); return; }
          ticking = true;
          tick()
            .then((s) => {
              if (!running) return;
              failureStreak = 0;
              scheduleNotify(s);
              if (intervalMs == null) {
                // Pace the tick loop to the display budget (~60 Hz). The old
                // free-running 0/1 ms loop fired hundreds of ticks per second:
                // each tick is a postMessage round-trip per worker, and the
                // resulting message storm saturated the main-thread event loop
                // (the UI collapsed to single-digit fps). Compute depth per
                // tick (computePressure passes) is untouched — this only stops
                // burning ticks no display can ever show.
                //
                // Duty-cycle guard: when a tick OVERRUNS the budget (weak
                // hardware, high pressure), `budget − obs` goes ≤ 0 and the
                // old floor of 1 ms ran ticks back-to-back at ~100% duty,
                // starving the compositor/input on the very machines that
                // need headroom most. We now always yield ≥ φ⁻² (≈38.2%) of
                // the observed tick time back to the host between ticks.
                // Per-tick compute depth, M, precision and workers are
                // untouched — only the inter-tick idle gap breathes.
                const obs = s.runtime?.tickMs ?? 0;
                const idleFloor = Math.round(obs * PHI_INV * PHI_INV);
                const hiddenFloor = typeof document !== 'undefined' && document.visibilityState !== 'visible' ? 250 : 1;
                nextDelay = Math.max(hiddenFloor, Math.round(hw.tickBudgetMs - obs), idleFloor);
              }
            })
            .catch((e) => {
              failureStreak++;
              console.error('fallback tick failed', e);
              // Do not spin-log failures. Yield progressively, and if a worker
              // wedged, rebuild the pool at the same M/settings without touching
              // field math or user governor choices.
              nextDelay = Math.min(2000, Math.max(250, nextDelay * 2 || 250));
              if (failureStreak >= 3) {
                failureStreak = 0;
                const previous = state;
                state = build(previous.m);
                previous.pool.destroy();
              }
            })
            .finally(() => { ticking = false; schedule(); });
        }, nextDelay) as unknown as ReturnType<typeof setInterval>;
      };
      schedule();
    },
    stop(): void {
      running = false;
      if (timer) { clearTimeout(timer as unknown as number); timer = null; }
    },
    onSnapshot(cb: (s: FieldSnapshot) => void): () => void { subs.add(cb); return () => subs.delete(cb); },
    /** Diagnostic: number of UI frames the Phase-2 coalescer skipped since boot. */
    coalescedFramesDropped(): number { return coalescedFramesDropped; },
    setCrystalTarget(kind: CoherenceTarget): void { crystalTargetKind = kind; },
    getCrystalTarget(): CoherenceTarget { return crystalTargetKind; },
    setPllTuning(opts: PllTuning): void {
      pllTuning = {
        lockEpsilon: Math.max(1e-6, Math.min(1, opts.lockEpsilon ?? pllTuning.lockEpsilon)),
        holdTicks: Math.max(1, Math.floor(opts.holdTicks ?? pllTuning.holdTicks)),
      };
      crystalPLL = new CrystallinePLL(pllTuning);
    },
    getPllTuning(): Required<PllTuning> { return { ...pllTuning }; },
    resetStabilizer(): void { crystalPLL.reset(); },
    resetEngine(): void {
      // Full soft reset: rebuild the field state from the configured
      // bootMode, reset the stabilizer, clear phase-lock, clear climb
      // streaks. Governor settings (carrier / threads / precision / boot
      // mode / compute pressure) are preserved — this reboots the field,
      // not the operator's environment.
      const previous = state;
      const ceiling = ceilingForMode(governor.settings.precision);
      const cap = bootCapFor();
      const nextM = Math.max(13, Math.min(ceiling, cap === Number.POSITIVE_INFINITY ? ceiling : cap));
      state = build(nextM);
      previous.pool.destroy();
      phaseLocked = false;
      climbStreak = 0;
      demoteStreak = 0;
      failureStreak = 0;
      crystalPLL.reset();
    },
  };
}

export async function probeFallbackCapabilities(): Promise<EngineCapabilities> {
  const hw = await probeHardware();
  const engine = createFallbackEngine(hw);
  return engine.capabilities();
}
