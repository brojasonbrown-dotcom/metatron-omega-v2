/**
 * METATRON V11 — UNIFIED ENGINE HOOK
 * ===================================
 *
 * One React hook, one mental model. The hook probes for the native daemon
 * on mount; if it answers, it streams real snapshots over WebSocket. If
 * not, it spins up the in-browser fallback at the same ABI. Either way
 * components see the same { capabilities, snapshot } shape.
 *
 * RENDER MODEL (critical for fps):
 * Engine snapshot emissions NEVER call setState. Each emission writes a
 * ref; the snapshot is exposed through a getter so whoever renders reads
 * the freshest value at render time. The Workstation's single throttled
 * tick loop is the ONE render driver — previously snapshot flushes and
 * the UI tick were two independent ~30 Hz setState streams that
 * interleaved into ~60 full-tree reconciliations per second.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { EngineBus, type ConnectionState } from './EngineBus';
import { createFallbackEngineAsync, type FallbackEngineHandle, type PllTuning } from './FallbackEngine';
import type { EngineCapabilities, FieldSnapshot } from './protocol';
import type { CoherenceTarget } from '@/core/stability/CrystallinePLL';
import type { GovernorSettings } from '@/core/runtime/ResourceGovernor';

export interface UseEngineResult {
  readonly state: ConnectionState | 'fallback';
  readonly capabilities: EngineCapabilities | null;
  readonly snapshot: FieldSnapshot | null;
  readonly setTargetM: (m: number) => void;
  readonly setPhaseLocked: (locked: boolean) => void;
  readonly isPhaseLocked: () => boolean;
  readonly benchmark: (ticks?: number) => Promise<import('@/core/runtime/computeBench').ComputeBenchResult | null>;
  readonly forcedFallback: boolean;
  readonly setForcedFallback: (force: boolean) => void;
  // Live experimental tuning — fallback engine only. Native daemon: no-op.
  readonly updateGovernor: (patch: Partial<GovernorSettings>) => GovernorSettings | null;
  readonly getGovernorSettings: () => GovernorSettings | null;
  readonly setCrystalTarget: (kind: CoherenceTarget) => void;
  readonly getCrystalTarget: () => CoherenceTarget;
  readonly setPllTuning: (opts: PllTuning) => void;
  readonly getPllTuning: () => Required<PllTuning> | null;
  readonly resetStabilizer: () => void;
  readonly resetEngine: () => void;
}

const FORCE_FALLBACK_KEY = 'v11.forceFallback';
function readForcedFallback(): boolean {
  if (typeof localStorage === 'undefined') return false;
  try { return localStorage.getItem(FORCE_FALLBACK_KEY) === '1'; } catch { return false; }
}

/**
 * @param enabled  When false, the engine is provisioned (capabilities are
 *   visible) but no ticks are scheduled and no snapshot is emitted — the UI
 *   stays honest about "engine not started". Flip true to begin computing.
 */
export function useEngine(enabled: boolean = true): UseEngineResult {
  const [forcedFallback, setForcedFallbackState] = useState<boolean>(() => readForcedFallback());
  const [state, setState] = useState<ConnectionState | 'fallback'>('idle');
  const [caps, setCaps] = useState<EngineCapabilities | null>(null);
  // Lifecycle version bump — fired ONLY on start/stop transitions so the
  // owner re-renders once and sees the fresh (or cleared) snapshot. Live
  // snapshot updates do NOT pass through React state at all.
  const [, bumpVersion] = useState(0);
  const snapRef = useRef<FieldSnapshot | null>(null);
  const busRef = useRef<EngineBus | null>(null);
  const fallbackRef = useRef<FallbackEngineHandle | null>(null);
  const fallbackCreateRef = useRef<Promise<void> | null>(null);
  const startedRef = useRef(false);
  // Single source of truth for "should snapshots reach the UI?"
  // Both the fallback gate AND the native bus listener consult this ref so
  // pause behaves identically across implementations.
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;

  useEffect(() => {
    let cancelled = false;
    let cleanupFallback: (() => void) | undefined;

    // Snapshot sink: a plain ref write. No setState, no rAF, no scheduling.
    // The engine can emit at any rate; React renders are driven solely by
    // the Workstation tick loop, which reads `snapshot` via the getter.
    const receiveSnapshot = (s: FieldSnapshot | null) => {
      snapRef.current = enabledRef.current ? s : null;
    };

    function startFallback(): Promise<void> {
      if (fallbackRef.current) return Promise.resolve();
      if (fallbackCreateRef.current) return fallbackCreateRef.current;
      const task = createFallbackEngineAsync()
        .then((fb) => {
          if (cancelled || fallbackRef.current) {
            try { fb.stop(); } catch { /* ignore */ }
            return;
          }
          fallbackRef.current = fb;
          setCaps(fb.capabilities());
          setState('fallback');
          const off = fb.onSnapshot(receiveSnapshot);
          cleanupFallback = () => { off(); fb.stop(); startedRef.current = false; };
        })
        .catch((e) => {
          if (!cancelled) {
            console.warn('fallback engine', e instanceof Error ? e.message : String(e));
            setState('error');
          }
        })
        .finally(() => {
          if (fallbackCreateRef.current === task) fallbackCreateRef.current = null;
        });
      fallbackCreateRef.current = task;
      return task;
    }
    // Honest hardware path: if the user has explicitly forced fallback,
    // skip the native daemon probe entirely. No mock, no speculation —
    // we go straight to the real in-browser FieldWorkerPool which actually
    // saturates navigator.hardwareConcurrency cores.
    if (forcedFallback) { void startFallback(); return; }

    EngineBus.probe().then((alive) => {
      if (cancelled) return;
      if (!alive) { void startFallback(); return; }
      const bus = new EngineBus();
      busRef.current = bus;
      bus.on('state', setState);
      bus.on('capabilities', setCaps);
      bus.on('snapshot', (s) => receiveSnapshot(s));
      bus.on('error', (e) => console.warn('engine bus', e.message));
      bus.connect();
      bus
        .call('field.subscribe')
        .catch(() => {
          bus.destroy();
          busRef.current = null;
          void startFallback();
        });
    });

    return () => {
      cancelled = true;
      fallbackCreateRef.current = null;
      cleanupFallback?.();
      busRef.current?.destroy();
      busRef.current = null;
      fallbackRef.current = null;
      snapRef.current = null;
    };
  }, [forcedFallback]);

  const setForcedFallback = useCallback((force: boolean) => {
    try { localStorage.setItem(FORCE_FALLBACK_KEY, force ? '1' : '0'); } catch { /* ignore */ }
    setForcedFallbackState(force);
  }, []);

  // React to enable flag — start/stop the live tick loop on demand.
  useEffect(() => {
    const fb = fallbackRef.current;
    if (fb) {
      if (enabled && !startedRef.current) {
        startedRef.current = true;
        fb.start();
        snapRef.current = fb.snapshot();
        bumpVersion((v) => v + 1);
      } else if (!enabled && startedRef.current) {
        startedRef.current = false;
        fb.stop();
        snapRef.current = null;
        bumpVersion((v) => v + 1);
      }
      return;
    }
    // Native bus path: protocol has no unsubscribe — clear the local snapshot
    // when paused so the UI reflects "not running" honestly.
    if (!enabled) {
      snapRef.current = null;
      bumpVersion((v) => v + 1);
    }
  }, [enabled, caps]);

  // All actions close over refs only — identities are stable for the
  // component lifetime, which lets consumers memoize on the hook result
  // instead of being invalidated by fresh closures every render.
  const setTargetM = useCallback((m: number) => {
    if (busRef.current && busRef.current.currentState === 'open') {
      busRef.current.call('field.setTargetM', { m }).catch(() => undefined);
    } else {
      fallbackRef.current?.setTargetM(m);
    }
  }, []);
  const setPhaseLocked = useCallback((locked: boolean) => {
    fallbackRef.current?.setPhaseLocked(locked);
  }, []);
  const isPhaseLocked = useCallback(() => fallbackRef.current?.isPhaseLocked() ?? false, []);
  const benchmark = useCallback(async (ticks = 24) => {
    const fb = fallbackRef.current;
    if (!fb) return null;
    await fb.awaitReady();
    const { benchmarkComputeFrequency } = await import('@/core/runtime/computeBench');
    return benchmarkComputeFrequency(fb.getPool(), fb.governor, ticks);
  }, []);

  // Stable result object: identity only changes when state/caps change.
  // The snapshot getter still reads the freshest engine emission at
  // property-access time, so live data is never stale.
  const updateGovernor = useCallback((patch: Partial<GovernorSettings>) => {
    const fb = fallbackRef.current;
    if (!fb) return null;
    return fb.governor.update(patch);
  }, []);
  const getGovernorSettings = useCallback(() => fallbackRef.current?.governor.settings ?? null, []);
  const setCrystalTarget = useCallback((k: CoherenceTarget) => { fallbackRef.current?.setCrystalTarget(k); }, []);
  const getCrystalTarget = useCallback<() => CoherenceTarget>(() => fallbackRef.current?.getCrystalTarget() ?? 'crystalline', []);
  const setPllTuning = useCallback((o: PllTuning) => { fallbackRef.current?.setPllTuning(o); }, []);
  const getPllTuning = useCallback(() => fallbackRef.current?.getPllTuning() ?? null, []);
  const resetStabilizer = useCallback(() => { fallbackRef.current?.resetStabilizer(); }, []);
  const resetEngine = useCallback(() => {
    const fb = fallbackRef.current;
    if (!fb) return;
    fb.resetEngine();
    // Reflect immediately so panels don't show a stale snapshot from the
    // torn-down state during the (very short) rebuild window.
    snapRef.current = fb.snapshot();
    bumpVersion((v) => v + 1);
  }, []);

  return useMemo(() => ({
    state,
    capabilities: caps,
    get snapshot(): FieldSnapshot | null {
      return enabledRef.current ? snapRef.current : null;
    },
    setTargetM,
    setPhaseLocked,
    isPhaseLocked,
    benchmark,
    forcedFallback,
    setForcedFallback,
    updateGovernor,
    getGovernorSettings,
    setCrystalTarget,
    getCrystalTarget,
    setPllTuning,
    getPllTuning,
    resetStabilizer,
    resetEngine,
  }), [state, caps, setTargetM, setPhaseLocked, isPhaseLocked, benchmark, forcedFallback, setForcedFallback, updateGovernor, getGovernorSettings, setCrystalTarget, getCrystalTarget, setPllTuning, getPllTuning, resetStabilizer, resetEngine]);
}
