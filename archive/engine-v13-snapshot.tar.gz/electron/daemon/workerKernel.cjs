"use strict";

// daemon/src/workerKernel.ts
var import_node_worker_threads = require("node:worker_threads");
var PHI = 1.618033988749895;
var PHI_INV = 1 / PHI;
if (!import_node_worker_threads.parentPort) throw new Error("workerKernel must run as a worker_threads child");
import_node_worker_threads.parentPort.on("message", (msg) => {
  if (msg.type !== "shard") return;
  const t0 = performance.now();
  const { kStart, kEnd, pressure, tick } = msg;
  let coherenceNum = 0;
  let coherenceDen = 0;
  let energy = 0;
  let term1 = 0;
  let term2 = 0;
  let term3 = 0;
  let term4 = 0;
  let ops = 0;
  for (let k = kStart; k <= kEnd; k++) {
    const absK = Math.abs(k);
    const phase = k * PHI + tick * 1e-3;
    const env = Math.pow(PHI_INV, absK * 0.5);
    let re = Math.cos(phase) * env;
    let im = Math.sin(phase) * env;
    for (let p = 0; p < pressure; p++) {
      const nre = re * 0.9 + im * 0.1 - PHI_INV * env;
      const nim = im * 0.9 - re * 0.1;
      re = nre;
      im = nim;
      ops += 8;
    }
    const mag2 = re * re + im * im;
    energy += mag2;
    coherenceNum += re;
    coherenceDen += mag2;
    term1 += mag2;
    term2 += Math.abs(re) * env;
    term3 += Math.abs(im) * env * PHI_INV;
    term4 += mag2 * PHI_INV;
    ops += 12;
  }
  const ms = performance.now() - t0;
  const result = {
    type: "shardResult",
    id: msg.id,
    coherenceNum,
    coherenceDen,
    energy,
    term1,
    term2,
    term3,
    term4,
    ops,
    ms
  };
  import_node_worker_threads.parentPort.postMessage(result);
});
