/**
 * V11 Scheduler.
 *
 * Owns the worker_threads pool, the hot kernel loop, and the auto-climb of M
 * up to the honest hardware ceiling. Saturates allocated CPU workers during
 * compute bursts. Yields between ticks via setImmediate so OS/UI stay
 * responsive even at full load.
 *
 * Phase 1 · Step 6 — parity rewrite:
 *   • Workers now execute the shared `runShardKernel` (φ-ladder physics),
 *     so the coherence/energy/terms that flow up are the SAME physics as
 *     the browser Web Worker + fallback paths.
 *   • Removed decorative offset `+ PHI2_INV * 0.5` from coherence (was
 *     inflating every daemon-emitted coherence value by ≈0.191).
 *   • Removed hard [0,1] clamp on coherence per master-plan Decision #2
 *     ("no clamping — surface the real value"). Aggregation still uses
 *     the browser-parity form:
 *         C = coherenceNum / max(coherenceDen, ε)
 *     which is exactly what `MetatronCore` composes in the browser.
 *   • Real `carrierHz`, `qScalar`, `reflectEnabled`, `dtSeconds` are
 *     posted to workers (were hard-coded / stubbed to 0 before).
 */
import { Worker } from 'node:worker_threads';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const PHI = 1.6180339887498949;
const PHI_INV = 1 / PHI;

// __dirname is defined when esbuild emits CJS (packaged Electron build);
// under tsx ESM (dev) we derive it from import.meta.url. Guarded so the
// CJS bundle never evaluates `import.meta.url` (which is empty there).
declare const __dirname: string | undefined;
const _here: string =
  typeof __dirname !== 'undefined'
    ? __dirname
    : path.dirname(fileURLToPath(import.meta.url));
// Allow packaged Electron builds to point at the pre-bundled .cjs worker.
const WORKER_PATH =
  process.env.METATRON_WORKER_PATH ||
  path.join(_here, 'workerKernel.ts');
const WORKER_IS_TS = WORKER_PATH.endsWith('.ts');

interface ShardPartial {
  coherenceNum: number;
  coherenceDen: number;
  energy: number;
  term1: number;
  term2: number;
  term3: number;
  term4: number;
  nodes: number;
  ops: number;
  ms: number;
}

interface WorkerLane {
  worker: Worker;
  busy: boolean;
  pending?: { resolve: (r: ShardPartial) => void; reject: (e: Error) => void; id: number };
}

export interface TickResult {
  readonly m: number;
  readonly kMin: number;
  readonly kMax: number;
  readonly nodesEvaluated: number;
  readonly nodesAxis: number;
  readonly nodesInward: number;
  readonly nodesTotal: number;
  readonly coherence: number;
  readonly energy: number;
  readonly term1: number;
  readonly term2: number;
  readonly term3: number;
  readonly term4: number;
  readonly tickMs: number;        // slowest shard
  readonly effectiveOps: number;
  readonly workerUtilisation: number;
  readonly activeWorkers: number;
  readonly carrierHz: number;
  readonly tSeconds: number;
}

export interface SchedulerConfig {
  threads: number;
  initialTargetM: number;
  hardwareCeiling: number; // max M to attempt — host-determined
  peakOpsPerSecond: number;
  /** Real carrier frequency posted to every shard. Host-owned. */
  carrierHz?: number;
  /** Quantum scalar — feeds reflect gain in the kernel. */
  qScalar?: number;
  /** Whether the ψ_reflect term is active. */
  reflectEnabled?: boolean;
  /** Continuous-time step per tick, seconds. Host-provided (Q1 answer c). */
  dtSeconds?: number;
  /** Relaxation passes per node per tick. */
  computePressure?: number;
}

export class Scheduler {
  private readonly lanes: WorkerLane[] = [];
  private readonly cfg: Required<SchedulerConfig>;
  private targetM: number;
  private currentM: number;
  private tick = 0;
  private simSeconds = 0;
  private running = false;
  private nextId = 1;
  private climbAccumulator = 0;

  constructor(cfg: SchedulerConfig) {
    this.cfg = {
      threads: cfg.threads,
      initialTargetM: cfg.initialTargetM,
      hardwareCeiling: cfg.hardwareCeiling,
      peakOpsPerSecond: cfg.peakOpsPerSecond,
      carrierHz: cfg.carrierHz ?? 7.83,          // Schumann fundamental — honest, decorative-free default
      qScalar: cfg.qScalar ?? 1.0,
      reflectEnabled: cfg.reflectEnabled ?? true,
      dtSeconds: cfg.dtSeconds ?? (1 / 60),      // host-provided (Q1 = c); falls back to 60Hz sim time
      computePressure: cfg.computePressure ?? 8,
    };
    this.targetM = Math.max(89, Math.min(cfg.initialTargetM, cfg.hardwareCeiling));
    this.currentM = Math.min(89, this.targetM);

    for (let i = 0; i < cfg.threads; i++) {
      // tsx loader supports .ts workers directly in dev; packaged builds
      // ship a pre-bundled .cjs worker that runs on plain Node.
      const worker = new Worker(
        WORKER_PATH,
        WORKER_IS_TS ? { execArgv: ['--import', 'tsx/esm'] } : {},
      );
      const lane: WorkerLane = { worker, busy: false };
      worker.on('message', (msg: ShardPartial & { type: string; id: number }) => {
        if (msg.type === 'shardResult' && lane.pending && lane.pending.id === msg.id) {
          const { resolve } = lane.pending;
          lane.pending = undefined;
          lane.busy = false;
          resolve(msg);
        }
      });
      worker.on('error', (err) => {
        if (lane.pending) {
          lane.pending.reject(err);
          lane.pending = undefined;
        }
        lane.busy = false;
      });
      this.lanes.push(lane);
    }
  }

  setTargetM(m: number): void {
    this.targetM = Math.max(13, Math.min(m, this.cfg.hardwareCeiling));
  }
  getTargetM(): number { return this.targetM; }
  getCurrentM(): number { return this.currentM; }
  getHardwareCeiling(): number { return this.cfg.hardwareCeiling; }
  getThreads(): number { return this.lanes.length; }
  getCarrierHz(): number { return this.cfg.carrierHz; }
  setCarrierHz(hz: number): void { if (Number.isFinite(hz) && hz >= 0) this.cfg.carrierHz = hz; }
  setQScalar(q: number): void { if (Number.isFinite(q)) this.cfg.qScalar = q; }
  setReflectEnabled(on: boolean): void { this.cfg.reflectEnabled = on; }
  setDtSeconds(dt: number): void { if (Number.isFinite(dt) && dt > 0) this.cfg.dtSeconds = dt; }
  setComputePressure(p: number): void {
    if (Number.isFinite(p) && p >= 1) this.cfg.computePressure = Math.floor(p);
  }

  async terminate(): Promise<void> {
    this.running = false;
    await Promise.all(this.lanes.map((l) => l.worker.terminate()));
  }

  /** One full tick across all workers. Returns aggregated result. */
  async tickOnce(): Promise<TickResult> {
    this.tick += 1;
    this.simSeconds += this.cfg.dtSeconds;
    const tSeconds = this.simSeconds;
    const t0 = performance.now();
    const m = this.currentM;
    // Inward depth = φ-derived, capped at 34 (matches FallbackEngine policy)
    const inward = Math.min(34, Math.max(13, Math.floor(Math.log(Math.max(1, m)) / Math.log(PHI)) + 5));
    const kMin = -inward;
    const kMax = m;
    const nodesEvaluated = m;
    const nodesAxis = 1; // k=0 always evaluated
    const nodesInward = inward;
    const nodesTotal = nodesEvaluated + nodesAxis + nodesInward;

    // Shard the full range across all worker lanes.
    const shards: Array<{ kStart: number; kEnd: number }> = [];
    const totalNodes = kMax - kMin + 1;
    const laneCount = this.lanes.length;
    const base = Math.floor(totalNodes / laneCount);
    const rem = totalNodes % laneCount;
    let cursor = kMin;
    for (let i = 0; i < laneCount; i++) {
      const size = base + (i < rem ? 1 : 0);
      if (size <= 0) continue;
      shards.push({ kStart: cursor, kEnd: cursor + size - 1 });
      cursor += size;
    }

    const promises: Array<Promise<ShardPartial>> = [];
    let busyLanes = 0;
    for (let i = 0; i < shards.length; i++) {
      const lane = this.lanes[i];
      const shard = shards[i];
      const id = this.nextId++;
      lane.busy = true;
      busyLanes += 1;
      promises.push(
        new Promise<ShardPartial>((resolve, reject) => {
          lane.pending = { resolve, reject, id };
          lane.worker.postMessage({
            type: 'shard',
            id,
            kStart: shard.kStart,
            kEnd: shard.kEnd,
            carrierHz: this.cfg.carrierHz,
            tSeconds,
            qScalar: this.cfg.qScalar,
            reflectEnabled: this.cfg.reflectEnabled,
            computePressure: this.cfg.computePressure,
            tick: this.tick,
          });
        }),
      );
    }

    const partials = await Promise.all(promises);

    // Aggregate. `runShardKernel` returns Neumaier-compensated partial sums
    // for coherenceNum = Σ psi·prev and coherenceDen = Σ prev². Summing
    // partials across shards is exact enough for f64 at O(1e6) modes.
    let cohNum = 0, cohDen = 0, energy = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0, ops = 0, maxMs = 0;
    for (const p of partials) {
      cohNum += p.coherenceNum;
      cohDen += p.coherenceDen;
      energy += p.energy;
      t1 += p.term1;
      t2 += p.term2;
      t3 += p.term3;
      t4 += p.term4;
      ops += p.ops;
      if (p.ms > maxMs) maxMs = p.ms;
    }
    // Browser-parity coherence: C = Σ(psi·prev) / Σ(prev²). This is the
    // Rayleigh coherence used by MetatronCore. On tick #1 the workers'
    // prev buffers are zero-initialised, so cohDen === 0 → coherence 0
    // (honest — no signal yet). No clamp, no offset.
    const coherence = cohDen > 0 ? cohNum / cohDen : 0;
    const wallMs = performance.now() - t0;
    const effectiveOps = wallMs > 0 ? (ops / wallMs) * 1000 : 0;

    // Auto-climb toward target if effective ops show headroom; demote if we
    // exceeded budget. Unchanged from the pre-parity scheduler — this is
    // the honest hardware controller, not decorative.
    const utilisation = effectiveOps / Math.max(1, this.cfg.peakOpsPerSecond);
    if (this.currentM < this.targetM && utilisation < 0.85) {
      this.climbAccumulator += 1;
      if (this.climbAccumulator >= 3) {
        this.currentM = Math.min(
          this.targetM,
          Math.ceil(Math.max(this.currentM + 1, this.currentM * PHI)),
        );
        this.climbAccumulator = 0;
      }
    } else if (utilisation > 1.05) {
      this.currentM = Math.max(13, Math.floor(this.currentM * PHI_INV));
      this.climbAccumulator = 0;
    } else {
      this.climbAccumulator = Math.max(0, this.climbAccumulator - 1);
    }

    return {
      m,
      kMin,
      kMax,
      nodesEvaluated,
      nodesAxis,
      nodesInward,
      nodesTotal,
      coherence,
      energy,
      term1: t1,
      term2: t2,
      term3: t3,
      term4: t4,
      tickMs: maxMs,
      effectiveOps,
      workerUtilisation: busyLanes / Math.max(1, this.lanes.length),
      activeWorkers: laneCount,
      carrierHz: this.cfg.carrierHz,
      tSeconds,
    };
  }

  start(emit: (r: TickResult) => void, onError: (e: Error) => void): void {
    if (this.running) return;
    this.running = true;
    const loop = async () => {
      while (this.running) {
        try {
          const result = await this.tickOnce();
          emit(result);
        } catch (e) {
          onError(e as Error);
          this.running = false;
          return;
        }
        // Yield so OS/UI stay responsive even at full saturation.
        await new Promise<void>((res) => setImmediate(res));
      }
    };
    loop();
  }

  stop(): void {
    this.running = false;
  }
}
