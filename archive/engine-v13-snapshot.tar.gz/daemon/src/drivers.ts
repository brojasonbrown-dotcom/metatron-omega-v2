/**
 * V11 procedural driver families.
 *
 * V10 drivers (EM-spectrum, triadic 3·6·9, phyllotaxis, epistemic CI) are
 * not foundations — they're parity references. The V11 daemon ships its own
 * procedural drivers that scale with M, never with a fixed bank size.
 *
 * Each driver exposes a `sample(m)` that returns a `DriverInfo` reflecting
 * its current contribution. Variance is the Welford running variance over
 * the last N samples and is what the kernel uses as a stability gate.
 */
import type { DriverInfo } from './protocol';

const PHI = 1.6180339887498949;
const PHI_INV = 1 / PHI;

interface DriverState {
  n: number;
  mean: number;
  m2: number; // Welford
}

function welfordPush(s: DriverState, x: number): void {
  s.n += 1;
  const d = x - s.mean;
  s.mean += d / s.n;
  s.m2 += d * (x - s.mean);
}
function welfordVar(s: DriverState): number {
  return s.n > 1 ? s.m2 / (s.n - 1) : 0;
}

export interface V11Driver {
  readonly id: string;
  readonly source: string;
  readonly kind: 'procedural' | 'local' | 'sensor' | 'network';
  /** Sample one tick. Returns DriverInfo with refreshed variance + modeIndex. */
  sample(m: number, tick: number): DriverInfo;
}

function makeDriver(
  id: string,
  source: string,
  fn: (m: number, tick: number) => { value: number; modeIndex: number },
): V11Driver {
  const state: DriverState = { n: 0, mean: 0, m2: 0 };
  return {
    id,
    source,
    kind: 'procedural',
    sample(m, tick) {
      const { value, modeIndex } = fn(m, tick);
      welfordPush(state, value);
      return {
        id,
        kind: 'synthetic', // protocol enum is fixed — 'synthetic' covers all procedural
        source,
        variance: welfordVar(state),
        modeIndex,
      };
    },
  };
}

/** Build the default V11 driver bouquet. */
export function buildDefaultV11Drivers(): V11Driver[] {
  return [
    // φ-octave lattice — samples the active octave each tick
    makeDriver('phi-octave', 'v11-procedural/phi-octave', (m, tick) => {
      const oct = tick % Math.max(1, Math.floor(Math.log(m + 1) / Math.log(PHI)));
      const value = Math.cos(oct * PHI) * Math.pow(PHI_INV, oct * 0.5);
      return { value, modeIndex: oct };
    }),
    // phase-lock residual — distance from 1/φ² target
    makeDriver('phase-lock', 'v11-procedural/phase-lock', (m, tick) => {
      const omega = 0.5 + 0.5 * Math.cos(tick * PHI_INV);
      const target = 1 / (PHI * PHI);
      return { value: Math.abs(omega - target), modeIndex: tick % m };
    }),
    // phyllotaxis — golden-angle sampling across modes
    makeDriver('phyllotaxis', 'v11-procedural/phyllotaxis', (m, tick) => {
      const k = (tick * 2.39996) % Math.max(1, m); // golden angle ≈ 137.5° in rad
      const value = Math.sin(k * PHI);
      return { value, modeIndex: Math.floor(k) };
    }),
    // harmonic frequency — Solfeggio-like sweep without hardcoded constants
    makeDriver('harmonic-freq', 'v11-procedural/harmonic-freq', (m, tick) => {
      const idx = tick % Math.max(1, m);
      const f = 432 * Math.pow(PHI, (idx % 12) - 6);
      return { value: f / 1000, modeIndex: idx };
    }),
    // coherence-gradient — second-derivative proxy of active spiral
    makeDriver('coherence-grad', 'v11-procedural/coherence-grad', (m, tick) => {
      const a = Math.cos(tick * PHI_INV);
      const b = Math.cos((tick + 1) * PHI_INV);
      const c = Math.cos((tick + 2) * PHI_INV);
      return { value: a - 2 * b + c, modeIndex: tick % m };
    }),
    // memory-feedback — recursive φ-window
    makeDriver('memory-feedback', 'v11-procedural/memory-feedback', (m, tick) => {
      const w = Math.floor(13 + (tick % 21));
      const value = Math.sin(tick / w);
      return { value, modeIndex: tick % m };
    }),
  ];
}
