/**
 * V11 daemon — hardware probe.
 *
 * Honest measurement of the host. No fake numbers. The peakOpsPerSecond is
 * self-benched at startup over a real numeric kernel (φ-mode evaluation),
 * not estimated from a vendor table.
 */
import os from 'node:os';

export interface HardwareProfile {
  readonly cpuThreads: number;       // logical cores reported by the OS
  readonly availableThreads: number; // cores the daemon may use (cpuThreads - reserve)
  readonly totalRamBytes: number;
  readonly usableRamBytes: number;   // 75% of total — leaves headroom for OS/apps
  readonly cpuModel: string;
  readonly platform: string;
  readonly arch: string;
  readonly peakOpsPerSecond: number;
  readonly benchTickMs: number;      // wall time of the self-bench
  readonly nodeVersion: string;
}

/**
 * Self-bench kernel: evaluates N φ-modes for B iterations and measures real
 * ops/sec. Same shape as the live kernel — so the number reflects what the
 * engine can actually sustain, not a synthetic micro-benchmark.
 */
function selfBench(): { opsPerSecond: number; tickMs: number } {
  const PHI = 1.6180339887498949;
  const N = 50_000;
  const ITERS = 8;
  const buf = new Float64Array(N * 2);
  // seed with golden-spiral amplitudes
  for (let k = 0; k < N; k++) {
    const phase = (k + 1) * PHI;
    buf[k * 2] = Math.cos(phase);
    buf[k * 2 + 1] = Math.sin(phase);
  }
  const t0 = performance.now();
  let acc = 0;
  for (let iter = 0; iter < ITERS; iter++) {
    for (let k = 0; k < N; k++) {
      const re = buf[k * 2];
      const im = buf[k * 2 + 1];
      const inv = 1 / Math.pow(PHI, ((k % 21) + 1) * 0.05);
      const nre = re * inv - im * inv * 0.3;
      const nim = im * inv + re * inv * 0.3;
      buf[k * 2] = nre;
      buf[k * 2 + 1] = nim;
      acc += nre * nre + nim * nim;
    }
  }
  const dt = performance.now() - t0;
  // 8 flops per inner iteration (mul/add) × N × ITERS
  const ops = 8 * N * ITERS;
  // prevent dead-code elim
  if (!Number.isFinite(acc)) throw new Error('bench produced NaN');
  return { opsPerSecond: (ops / dt) * 1000, tickMs: dt };
}

export function probeHardware(opts: { reserveCores?: number } = {}): HardwareProfile {
  const reserve = Math.max(0, opts.reserveCores ?? 1);
  const cpuThreads = os.availableParallelism?.() ?? os.cpus().length ?? 1;
  const availableThreads = Math.max(1, cpuThreads - reserve);
  const totalRamBytes = os.totalmem();
  const usableRamBytes = Math.floor(totalRamBytes * 0.75);
  const cpus = os.cpus();
  const cpuModel = cpus[0]?.model?.trim() ?? 'unknown';
  const { opsPerSecond, tickMs } = selfBench();
  return {
    cpuThreads,
    availableThreads,
    totalRamBytes,
    usableRamBytes,
    cpuModel,
    platform: os.platform(),
    arch: os.arch(),
    peakOpsPerSecond: opsPerSecond,
    benchTickMs: tickMs,
    nodeVersion: process.version,
  };
}
