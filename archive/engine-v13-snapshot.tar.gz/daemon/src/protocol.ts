/**
 * Re-export of the canonical EngineBus protocol from the main app. Single
 * source of truth lives in `src/core/bus/protocol.ts`. We import it here via
 * a relative path so the daemon stays in lockstep — if the contract changes
 * in the app, the daemon won't compile until the change is acknowledged.
 */
export * from '../../src/core/bus/protocol';
