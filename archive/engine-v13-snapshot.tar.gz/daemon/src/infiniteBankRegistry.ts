/**
 * V11 InfiniteBankRegistry
 *
 * The point of this module: separate the engine's ADDRESSABLE bank from what
 * is currently MATERIALIZED in RAM and what is currently EVALUATED per tick.
 *
 * The V10 engine conflated these — its 55-node sub-Planckian "bank" was
 * literally a 55-slot array, so capacity = compute = RAM, all stuck at 55.
 * V11 separates them:
 *
 *   - Potential:   { kMin, kMax } can extend to ±Infinity. A bank is
 *                  defined by a deterministic generator, not an array.
 *   - Materialized: only the shards currently in the LRU cache hold floats.
 *                   Shards are evicted by total RAM budget.
 *   - Evaluated:    the scheduler picks an active window inside the
 *                   addressable bank and computes only that window per tick.
 *
 * One InfiniteBankRegistry instance backs the daemon. Banks register their
 * generators on startup. The kernel asks the registry "give me modes
 * [kStart..kEnd) for bank X"; the registry returns a Float64Array shard,
 * materializing it on demand and caching it.
 */
const PHI = 1.6180339887498949;

export type ShardGenerator = (kStart: number, count: number, out: Float64Array) => void;

export interface BankDefinition {
  readonly id: string;
  readonly description: string;
  /** Smallest addressable mode index (may be -Infinity). */
  readonly kMin: number;
  /** Largest addressable mode index (may be +Infinity). */
  readonly kMax: number;
  /** Floats per node in this bank (typically 2 for complex amplitudes). */
  readonly floatsPerNode: number;
  /** Pure function: same (kStart,count) → same output. */
  readonly generator: ShardGenerator;
}

interface ResidentShard {
  readonly bankId: string;
  readonly kStart: number;
  readonly count: number;
  readonly floats: Float64Array;
  /** Monotonic touch counter for LRU eviction. */
  lastTouched: number;
  readonly bytes: number;
}

export class InfiniteBankRegistry {
  private readonly banks = new Map<string, BankDefinition>();
  private readonly shards = new Map<string, ResidentShard>();
  private readonly ramBudgetBytes: number;
  private bytesResident = 0;
  private touchCounter = 0;

  constructor(opts: { ramBudgetBytes: number }) {
    // Hard-cap shard RAM at 25% of usable system RAM. The rest of the
    // budget is reserved for worker thread stacks, V8 heap, and snapshot
    // history. We tune this once hot data tells us the real shape.
    this.ramBudgetBytes = Math.floor(opts.ramBudgetBytes * 0.25);
  }

  register(def: BankDefinition): void {
    if (this.banks.has(def.id)) throw new Error(`bank ${def.id} already registered`);
    this.banks.set(def.id, def);
  }

  list(): readonly BankDefinition[] {
    return Array.from(this.banks.values());
  }

  /**
   * Total addressable nodes across all banks, summing each bank's extent.
   * Returns `Number.POSITIVE_INFINITY` when any bank is unbounded.
   */
  potentialNodes(): number {
    let total = 0;
    for (const b of this.banks.values()) {
      if (b.kMin === -Infinity || b.kMax === Infinity) return Number.POSITIVE_INFINITY;
      total += b.kMax - b.kMin + 1;
    }
    return total;
  }

  materializedNodes(): number {
    let total = 0;
    for (const s of this.shards.values()) total += s.count;
    return total;
  }

  materializedBytes(): number {
    return this.bytesResident;
  }

  /**
   * Request a shard. If already cached, returns the cached Float64Array; if
   * not, the bank generator runs to fill a fresh buffer, which is then
   * cached (subject to LRU eviction).
   */
  shard(bankId: string, kStart: number, count: number): Float64Array {
    const def = this.banks.get(bankId);
    if (!def) throw new Error(`unknown bank: ${bankId}`);
    if (count <= 0) return new Float64Array(0);
    // Clamp request to addressable range
    const clampedStart = Math.max(def.kMin, kStart);
    const clampedEnd = Math.min(def.kMax + 1, kStart + count);
    const actualCount = Math.max(0, clampedEnd - clampedStart);
    if (actualCount <= 0) return new Float64Array(0);

    const key = `${bankId}|${clampedStart}|${actualCount}`;
    const cached = this.shards.get(key);
    if (cached) {
      cached.lastTouched = ++this.touchCounter;
      return cached.floats;
    }

    const floats = new Float64Array(actualCount * def.floatsPerNode);
    def.generator(clampedStart, actualCount, floats);
    const bytes = floats.byteLength;
    this.evictUntilFits(bytes);
    const shard: ResidentShard = {
      bankId,
      kStart: clampedStart,
      count: actualCount,
      floats,
      lastTouched: ++this.touchCounter,
      bytes,
    };
    this.shards.set(key, shard);
    this.bytesResident += bytes;
    return floats;
  }

  private evictUntilFits(incomingBytes: number): void {
    if (this.bytesResident + incomingBytes <= this.ramBudgetBytes) return;
    // LRU: evict oldest until it fits
    const sorted = Array.from(this.shards.entries()).sort(
      (a, b) => a[1].lastTouched - b[1].lastTouched,
    );
    for (const [key, shard] of sorted) {
      if (this.bytesResident + incomingBytes <= this.ramBudgetBytes) break;
      this.shards.delete(key);
      this.bytesResident -= shard.bytes;
    }
  }

  /** Drop everything — used on resize/precision change. */
  flush(): void {
    this.shards.clear();
    this.bytesResident = 0;
  }
}

/**
 * Default V11 banks. All are procedural — no V10 hardcoded 55-node arrays.
 * Each has unbounded `kMax` so they advertise as virtually-infinite while
 * still being computable in finite RAM via on-demand shard materialization.
 */
export function registerDefaultV11Banks(reg: InfiniteBankRegistry): void {
  // Bank A: φ-spiral outward modes. Complex amplitudes (re,im) per mode.
  reg.register({
    id: 'phi-outward',
    description: 'φ-spiral outward modes (k≥1) — golden-angle amplitudes.',
    kMin: 1,
    kMax: Number.POSITIVE_INFINITY,
    floatsPerNode: 2,
    generator(kStart, count, out) {
      for (let i = 0; i < count; i++) {
        const k = kStart + i;
        const phase = k * PHI;
        const decay = Math.pow(PHI, -((k - 1) * 0.5));
        out[i * 2] = Math.cos(phase) * decay;
        out[i * 2 + 1] = Math.sin(phase) * decay;
      }
    },
  });

  // Bank B: φ-spiral inward conjugates (k<0).
  reg.register({
    id: 'phi-inward',
    description: 'φ-spiral inward conjugate modes (k≤-1).',
    kMin: Number.NEGATIVE_INFINITY,
    kMax: -1,
    floatsPerNode: 2,
    generator(kStart, count, out) {
      for (let i = 0; i < count; i++) {
        const k = kStart + i; // negative
        const phase = -k * PHI;
        const grow = Math.pow(PHI, k * 0.5); // shrinks as k→−∞
        out[i * 2] = Math.cos(phase) * grow;
        out[i * 2 + 1] = -Math.sin(phase) * grow;
      }
    },
  });

  // Bank C: octave-scale lattice. One float per octave shell amplitude.
  reg.register({
    id: 'octave-scale',
    description: 'φ-octave shell amplitudes — coarse-grain bank for scale-up checks.',
    kMin: 0,
    kMax: Number.POSITIVE_INFINITY,
    floatsPerNode: 1,
    generator(kStart, count, out) {
      for (let i = 0; i < count; i++) {
        const oct = kStart + i;
        out[i] = 1 / (1 + oct * 0.1); // simple monotonic shell weight
      }
    },
  });
}
