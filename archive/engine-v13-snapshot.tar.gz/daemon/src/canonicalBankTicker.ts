/**
 * V11 daemon — CanonicalBankTicker (Phase 7 · Step 2).
 *
 * A THIN wrapper around the browser's `MasterUpdateController` so the
 * Node daemon can step the exact same RHUFT-F canonical bank pipeline
 * (LadderProjection Π + CanonicalUpdateBank + ShadowStateTape + U_0..U_8)
 * that Phase 6 landed for the browser. No code duplication: this module
 * imports the browser modules by RELATIVE PATH from the shared `src/`
 * tree — the daemon runs literally the same bytes, just under Node
 * instead of Vite.
 *
 * Flag gate: constructing this ticker with `forceOn = false` reads
 * `FLAG_RHUFTF_DAEMON_BANK` at construction time. When OFF (default) the
 * ticker is *inert* — `tick()` returns `null`, `state()` returns a
 * quiescent report, and the underlying controller is never allocated.
 * Zero regression surface to the shard-kernel physics path.
 *
 * Determinism: identical `(seed, ticks, dim, dt)` sequences produce
 * identical `CanonicalUpdateSnapshot` outputs across two independent
 * instances (proven by `scripts/phase7Step2DaemonTickerFreeze.ts`).
 *
 * SAFETY: nothing in this module touches `window` / `document` /
 * `localStorage`. Verified by the Phase 7 · Step 1 import-audit script.
 */

import { MasterUpdateController } from '../../src/core/v12/MasterUpdateController';
import type { StepMetrics } from '../../src/core/v12/MasterUpdateController';
import type { CanonicalUpdateSnapshot } from '../../src/core/runtime/CanonicalUpdateBank';
import { portFlag } from '../../src/core/runtime/portFlags';

export interface CanonicalBankTickerOptions {
  /** Ψ vector length. Must match the browser controller's dim (default 40). */
  readonly dim?: number;
  /** Fibonacci ring depth (default 21, matches browser). */
  readonly ringDepth?: number;
  /** Force ON regardless of FLAG_RHUFTF_DAEMON_BANK env flag. Test-only. */
  readonly forceOn?: boolean;
}

export interface DaemonBankTickInput {
  /** Optional sensory injection (Float64Array of length `dim`). */
  readonly sensory?: Float64Array | null;
  /** Optional memory recall injection. */
  readonly memoryRecall?: Float64Array | null;
  /** Optional reflect injection. */
  readonly reflect?: Float64Array | null;
}

export interface DaemonBankTickerState {
  readonly enabled: boolean;
  readonly ticks: number;
  readonly dim: number;
  readonly lastSnapshotAt: number | null; // performance.now() at last non-null snapshot
}

/**
 * Wraps a `MasterUpdateController` so the daemon can step the canonical
 * bank alongside its shard-kernel physics without touching the
 * scheduler / worker path.
 */
export class CanonicalBankTicker {
  readonly enabled: boolean;
  readonly dim: number;
  private controller: MasterUpdateController | null;
  private ticks = 0;
  private lastSnapshotAt: number | null = null;

  constructor(opts: CanonicalBankTickerOptions = {}) {
    this.dim = Math.max(1, opts.dim ?? 40);
    this.enabled = opts.forceOn === true || portFlag('FLAG_RHUFTF_DAEMON_BANK');
    if (this.enabled) {
      this.controller = new MasterUpdateController({
        dim: this.dim,
        ringDepth: opts.ringDepth ?? 21,
      });
      // Seed with zeros — deterministic baseline, matches browser default.
      this.controller.seed(new Float64Array(this.dim));
    } else {
      this.controller = null;
    }
  }

  /** Seed Ψ_0 with the caller's vector. No-op when disabled. */
  seed(psi0: Float64Array): void {
    if (!this.controller) return;
    if (psi0.length !== this.dim) {
      throw new Error(`CanonicalBankTicker.seed: length ${psi0.length} != dim ${this.dim}`);
    }
    this.controller.seed(psi0);
    this.ticks = 0;
  }

  /**
   * One deterministic canonical-bank step. Returns the snapshot when the
   * canonical branch fires (both CANONICAL and DELEGATE flags decide
   * *inside* the controller); returns `null` when the branch is OFF or
   * when this ticker is disabled.
   */
  tick(input: DaemonBankTickInput = {}): CanonicalUpdateSnapshot | null {
    if (!this.controller) return null;
    const m: StepMetrics = this.controller.step({
      sensory: input.sensory ?? null,
      memoryRecall: input.memoryRecall ?? null,
      reflect: input.reflect ?? null,
    });
    this.ticks++;
    if (m.canonical) {
      this.lastSnapshotAt = performance.now();
      return m.canonical;
    }
    return null;
  }

  state(): DaemonBankTickerState {
    return {
      enabled: this.enabled,
      ticks: this.ticks,
      dim: this.dim,
      lastSnapshotAt: this.lastSnapshotAt,
    };
  }
}
