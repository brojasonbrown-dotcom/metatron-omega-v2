/**
 * V11 daemon — WebSocket JSON-RPC server.
 *
 * Speaks the protocol defined in src/core/bus/protocol.ts. Browser/Electron
 * client connects via EngineBus → automatic upgrade from fallback to native.
 *
 * Wire format: JSON-RPC 2.0 over WebSocket text frames.
 */
import { WebSocketServer, WebSocket } from 'ws';
import type { EngineHost } from './engineHost';
import type {
  FieldSnapshot,
  RpcRequest,
  RpcSuccess,
  RpcError,
  FieldSubscriptionEvent,
} from './protocol';

export interface WsServerOptions {
  readonly port: number;
  readonly host?: string;
}

export class DaemonWsServer {
  private readonly wss: WebSocketServer;
  private readonly subscribers = new Set<WebSocket>();

  constructor(private readonly host: EngineHost, opts: WsServerOptions) {
    this.wss = new WebSocketServer({ port: opts.port, host: opts.host ?? '127.0.0.1' });
    this.wss.on('connection', (ws) => this.handleConnection(ws));
    this.wss.on('error', (err) => console.error('[daemon-ws] server error:', err));
    host.on('snapshot', (snap: FieldSnapshot) => this.broadcastSnapshot(snap));
  }

  /** Resolves once the server is listening and `port` is final. */
  async ready(): Promise<void> {
    if (this.wss.address()) return;
    await new Promise<void>((resolve, reject) => {
      this.wss.once('listening', () => resolve());
      this.wss.once('error', reject);
    });
  }

  get port(): number {
    const addr = this.wss.address();
    return typeof addr === 'object' && addr ? addr.port : 0;
  }

  async close(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.wss.close((err) => (err ? reject(err) : resolve()));
    });
  }

  private handleConnection(ws: WebSocket): void {
    ws.on('message', (data) => this.handleMessage(ws, data.toString()));
    ws.on('close', () => this.subscribers.delete(ws));
    ws.on('error', (err) => console.warn('[daemon-ws] client error:', err.message));
  }

  private handleMessage(ws: WebSocket, raw: string): void {
    let req: RpcRequest;
    try {
      req = JSON.parse(raw) as RpcRequest;
    } catch {
      return; // malformed — silently drop (browser EngineBus drops bad too)
    }
    if (req.jsonrpc !== '2.0' || typeof req.id !== 'number' || !req.method) return;

    try {
      const result = this.dispatch(ws, req);
      const success: RpcSuccess = { jsonrpc: '2.0', id: req.id, result };
      ws.send(JSON.stringify(success));
    } catch (e) {
      const err: RpcError = {
        jsonrpc: '2.0',
        id: req.id,
        error: { code: -32603, message: (e as Error).message },
      };
      ws.send(JSON.stringify(err));
    }
  }

  private dispatch(ws: WebSocket, req: RpcRequest): unknown {
    switch (req.method) {
      case 'engine.hello':
      case 'engine.capabilities':
        return this.host.getCapabilities();
      case 'field.snapshot':
        return this.host.getLastSnapshot();
      case 'field.subscribe':
        this.subscribers.add(ws);
        // immediately send latest snapshot if we have one
        const last = this.host.getLastSnapshot();
        if (last) {
          const ev: FieldSubscriptionEvent = {
            jsonrpc: '2.0',
            method: 'field.snapshot.event',
            params: last,
          };
          ws.send(JSON.stringify(ev));
        }
        return { subscribed: true };
      case 'field.start':
        this.host.start();
        return { started: true };
      case 'field.stop':
        // intentionally no-op for now: daemon keeps the kernel hot so
        // re-subscribers see live data instantly. UI 'stop' just unsubscribes.
        return { stopped: true };
      case 'field.setTargetM': {
        const m = (req.params as { m?: number } | undefined)?.m;
        if (typeof m === 'number') this.host.setTargetM(m);
        return { targetM: m };
      }
      case 'field.setPrecision':
        return { precision: 'f64' }; // f128/dec50 are Phase 2
      case 'verify.identity':
        return { ok: true, kind: 'native', protocol: this.host.getCapabilities().protocol };
      case 'verify.runAll':
        return { ok: true, note: 'verification suite hosted in app — daemon emits real numerics only' };
      default:
        throw new Error(`unknown method: ${req.method}`);
    }
  }

  private broadcastSnapshot(snap: FieldSnapshot): void {
    if (this.subscribers.size === 0) return;
    const ev: FieldSubscriptionEvent = {
      jsonrpc: '2.0',
      method: 'field.snapshot.event',
      params: snap,
    };
    const msg = JSON.stringify(ev);
    for (const ws of this.subscribers) {
      if (ws.readyState === WebSocket.OPEN) ws.send(msg);
    }
  }
}
