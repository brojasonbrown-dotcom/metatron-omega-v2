/**
 * V11 daemon — worker thread side of the field kernel.
 *
 * Phase 1 · Step 4: the hand-rolled 2×2 stand-in is gone. This worker now
 * runs the SAME `runShardKernel` as the browser (Web Worker + main-thread
 * fallback), imported from the shared `@metatron/field-kernel-core`
 * package. Byte-for-byte identical physics between Node daemon and browser
 * (modulo IEEE 754 same-runtime tolerance, which is 0 ULP for the shard
 * kernel because every op is `Math.cos`/`Math.exp`/scalar arithmetic —
 * V8 in Node and V8 in Chrome use identical libm paths on the same OS).
 *
 * Per-shard `prev` amplitudes are cached across ticks keyed by the
 * `(kStart, kEnd)` range. When the range changes (M climbs / demotes)
 * the cache entry is resized and re-seeded with zeros — the kernel is
 * self-recovering because the reflect/memory terms decay toward zero
 * within O(1/(1-φ⁻²)) ≈ 2.6 ticks.
 */
import { parentPort } from 'node:worker_threads';
import {
  runShardKernel,
  type ShardKernelInput,
} from '../../packages/field-kernel-core/src/index';

interface ShardRequest {
  type: 'shard';
  id: number;
  kStart: number;
  kEnd: number;
  carrierHz: number;
  tSeconds: number;
  qScalar: number;
  reflectEnabled: boolean;
  computePressure: number;
  tick: number;
}

interface ShardResult {
  type: 'shardResult';
  id: number;
  coherenceNum: number;
  coherenceDen: number;
  energy: number;
  term1: number;
  term2: number;
  term3: number;
  term4: number;
  nodes: number;
  ops: number;
  ms: number;
}

if (!parentPort) throw new Error('workerKernel must run as a worker_threads child');

// Persistent per-shard scratch. Keyed by kStart:kEnd because those form
// the physical extent of the shard; if the extent changes, prev is stale
// anyway and must be rebuilt.
interface ShardScratch {
  prev: Float64Array;
  out: Float64Array;
  nodes: number;
}
const scratchByRange = new Map<string, ShardScratch>();

function getScratch(kStart: number, kEnd: number): ShardScratch {
  const nodes = kEnd - kStart + 1;
  const key = `${kStart}:${kEnd}`;
  const cached = scratchByRange.get(key);
  if (cached && cached.nodes === nodes) return cached;
  const scratch: ShardScratch = {
    prev: new Float64Array(nodes),
    out: new Float64Array(nodes),
    nodes,
  };
  scratchByRange.set(key, scratch);
  // Simple LRU cap so an M-climbing session doesn't leak buffers forever.
  if (scratchByRange.size > 64) {
    const firstKey = scratchByRange.keys().next().value as string | undefined;
    if (firstKey && firstKey !== key) scratchByRange.delete(firstKey);
  }
  return scratch;
}

parentPort.on('message', (msg: ShardRequest) => {
  if (msg.type !== 'shard') return;
  const t0 = performance.now();
  const { kStart, kEnd, carrierHz, tSeconds, qScalar, reflectEnabled, computePressure } = msg;
  const scratch = getScratch(kStart, kEnd);

  const input: ShardKernelInput = {
    kStart,
    nodes: scratch.nodes,
    carrierHz,
    tSeconds,
    qScalar,
    reflectEnabled,
    computePressure,
    prev: scratch.prev,
    out: scratch.out,
  };

  const r = runShardKernel(input);
  const ms = performance.now() - t0;

  // Honest op-count for the utilisation controller: last pass has ~18 fused
  // ops per node (cos, mul, add ×~15, plus 6 Neumaier updates); prior passes
  // ~9. Matches the loop bodies in runShardKernel.
  const passes = Math.max(1, Math.floor(computePressure));
  const ops = scratch.nodes * ((passes - 1) * 9 + 18);

  const result: ShardResult = {
    type: 'shardResult',
    id: msg.id,
    coherenceNum: r.coherenceNum,
    coherenceDen: r.coherenceDen,
    energy: r.energy,
    term1: r.term1,
    term2: r.term2,
    term3: r.term3,
    term4: r.term4,
    nodes: scratch.nodes,
    ops,
    ms,
  };
  parentPort!.postMessage(result);
});
