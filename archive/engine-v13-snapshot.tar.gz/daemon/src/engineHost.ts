/**
 * V11 EngineHost — wires the registry, scheduler, drivers, and snapshot
 * fan-out together. The host owns nothing browser-specific — it is a pure
 * Node module that can be embedded in Electron, a CLI daemon, or tests.
 */
import { EventEmitter } from 'node:events';
import { InfiniteBankRegistry, registerDefaultV11Banks } from './infiniteBankRegistry';
import { buildDefaultV11Drivers, type V11Driver } from './drivers';
import { Scheduler, type TickResult } from './scheduler';
import { probeHardware, type HardwareProfile } from './hardwareProbe';
import {
  PROTOCOL_VERSION,
  type EngineCapabilities,
  type FieldSnapshot,
  type DriverInfo,
} from './protocol';
import { CanonicalBankTicker } from './canonicalBankTicker';

const PHI = 1.6180339887498949;
const PHI2_INV = 1 / (PHI * PHI);

export interface EngineHostOptions {
  readonly reserveCores?: number;
  readonly threads?: number;
  readonly initialTargetM?: number;
  readonly snapshotHz?: number; // outbound snapshot rate cap (kernel may tick faster)
  readonly carrierHz?: number;  // real carrier — no longer stubbed
  readonly qScalar?: number;
  readonly reflectEnabled?: boolean;
  readonly dtSeconds?: number;  // sim-time step per tick (host-owned)
  readonly computePressure?: number;
  /**
   * Phase 7 · Step 3 — force the daemon-side CanonicalBankTicker ON
   * regardless of `FLAG_RHUFTF_DAEMON_BANK`. Test-only. Default is
   * `undefined` (honour the env flag; default OFF ⇒ ticker inert).
   */
  readonly enableCanonicalBank?: boolean;
  /** Ψ vector length for the wrapped controller. Default 40 (browser parity). */
  readonly canonicalBankDim?: number;
}

export interface EngineHostEvents {
  snapshot: (s: FieldSnapshot) => void;
  capabilities: (c: EngineCapabilities) => void;
}

export class EngineHost extends EventEmitter {
  readonly hardware: HardwareProfile;
  readonly registry: InfiniteBankRegistry;
  readonly drivers: V11Driver[];
  readonly scheduler: Scheduler;
  private readonly capabilities: EngineCapabilities;
  private lastSnapshot: FieldSnapshot | null = null;
  private lastEmitMs = 0;
  private readonly emitIntervalMs: number;
  private phaseLocked = false;
  private readonly computePressure: number;
  /**
   * Phase 7 · Step 3 — optional RHUFT-F canonical bank ticker. Flag-gated
   * (`FLAG_RHUFTF_DAEMON_BANK`, default OFF) or forced via
   * `opts.enableCanonicalBank`. When disabled, `.tick()` returns null on
   * every call and the outbound snapshot's `rhuftf` field is never set —
   * byte-identical to the pre-Phase-7 emission.
   */
  readonly canonicalBank: CanonicalBankTicker;

  constructor(opts: EngineHostOptions = {}) {
    super();
    this.hardware = probeHardware({ reserveCores: opts.reserveCores ?? 1 });

    this.registry = new InfiniteBankRegistry({ ramBudgetBytes: this.hardware.usableRamBytes });
    registerDefaultV11Banks(this.registry);

    this.drivers = buildDefaultV11Drivers();

    // Honest hardware ceiling: derive from RAM (≈ 256 bytes per active mode budget)
    // and CPU throughput. Capped at 4M to keep snapshot serialization sane.
    const ramCeiling = Math.floor(this.hardware.usableRamBytes / 1024); // 1KB per mode budget
    const opsCeiling = Math.floor(this.hardware.peakOpsPerSecond / 200); // 200 ops/mode/tick budget
    const hardwareCeiling = Math.min(4_000_000, Math.max(89, Math.min(ramCeiling, opsCeiling)));

    const threads = Math.max(1, opts.threads ?? this.hardware.availableThreads);
    this.scheduler = new Scheduler({
      threads,
      initialTargetM: opts.initialTargetM ?? Math.min(6765, hardwareCeiling),
      hardwareCeiling,
      peakOpsPerSecond: this.hardware.peakOpsPerSecond,
      carrierHz: opts.carrierHz ?? 7.83,
      qScalar: opts.qScalar ?? 1.0,
      reflectEnabled: opts.reflectEnabled ?? true,
      dtSeconds: opts.dtSeconds ?? (1 / 60),
      computePressure: opts.computePressure ?? 8,
    });
    this.computePressure = opts.computePressure ?? 8;

    this.capabilities = {
      kind: 'native',
      protocol: PROTOCOL_VERSION,
      version: '0.1.0-daemon',
      maxModeByPrecision: { f64: hardwareCeiling, f128: Math.floor(hardwareCeiling / 2), dec50: Math.floor(hardwareCeiling / 4) },
      gpu: 'none',
      simd: 'none',
      cpuThreads: this.hardware.cpuThreads,
      peakOpsPerSecond: this.hardware.peakOpsPerSecond,
      wolframVerified: false,
    };

    this.emitIntervalMs = 1000 / Math.max(1, Math.min(120, opts.snapshotHz ?? 60));

    // Phase 7 · Step 3 — construct canonical bank ticker. Defaults inert
    // (flag off, forceOn undefined). No effect on shard-kernel physics.
    this.canonicalBank = new CanonicalBankTicker({
      dim: opts.canonicalBankDim ?? 40,
      forceOn: opts.enableCanonicalBank === true,
    });
  }

  getCapabilities(): EngineCapabilities {
    return this.capabilities;
  }

  setTargetM(m: number): void {
    if (this.phaseLocked) return;
    this.scheduler.setTargetM(m);
  }

  setPhaseLocked(locked: boolean): void {
    this.phaseLocked = locked;
  }

  start(): void {
    this.scheduler.start(
      (tick) => this.onTick(tick),
      (err) => console.error('[daemon] scheduler error:', err),
    );
  }

  async stop(): Promise<void> {
    this.scheduler.stop();
    await this.scheduler.terminate();
  }

  getLastSnapshot(): FieldSnapshot | null {
    return this.lastSnapshot;
  }

  private onTick(tick: TickResult): void {
    const tUs = Math.round(performance.now() * 1000);

    // Sample all V11 drivers for this tick
    const driverInfos: DriverInfo[] = this.drivers.map((d, i) => d.sample(tick.m, i + tick.m));

    const materialized = this.registry.materializedNodes();
    const potential = this.registry.potentialNodes(); // Infinity

    const snap: FieldSnapshot = {
      tUs,
      coherence: tick.coherence,
      energy: tick.energy,
      term1Magnitude: tick.term1,
      term2Magnitude: tick.term2,
      term3Magnitude: tick.term3,
      term4Magnitude: tick.term4,
      precision: 'f64',
      scaler: {
        currentM: tick.m,
        honestCeiling: this.scheduler.getHardwareCeiling(),
        honestCeilingTotal: this.scheduler.getHardwareCeiling() + tick.nodesInward + 1,
        utilisation: Math.min(1, tick.effectiveOps / Math.max(1, this.hardware.peakOpsPerSecond)),
        headroom: Math.max(0, 1 - tick.effectiveOps / Math.max(1, this.hardware.peakOpsPerSecond)),
        decision: tick.m < this.scheduler.getTargetM() ? 'promote' : tick.coherence < PHI2_INV ? 'demote' : 'hold',
      },
      drivers: driverInfos,
      metatronClosed: tick.coherence >= PHI2_INV,
      qualia: {
        C: tick.coherence,
        N: Math.min(1, tick.energy / Math.max(1, tick.nodesTotal)),
        S: Math.max(0, 1 - tick.term3),
        V: Math.min(1, tick.term1 / Math.max(1, tick.nodesTotal)),
        I: Math.min(1, tick.term4 / Math.max(1, tick.nodesTotal)),
      },
      spiral: { kMin: tick.kMin, kMax: tick.kMax },
      carrierHz: tick.carrierHz,
      workingDigits: 16,
      runtime: {
        nodesEvaluated: tick.nodesEvaluated,
        nodesAxis: tick.nodesAxis,
        nodesInward: tick.nodesInward,
        nodesTotal: tick.nodesTotal,
        nodesMaterialized: Math.max(materialized, tick.nodesTotal),
        nodesPotential: potential,
        activeWorkers: tick.activeWorkers,
        workerBacked: true,
        computePressure: this.computePressure,
        tickMs: tick.tickMs,
        effectiveOps: tick.effectiveOps,
        pressureUtilisation: Math.min(1, tick.effectiveOps / Math.max(1, this.hardware.peakOpsPerSecond)),
        workerUtilisation: tick.workerUtilisation,
      },
      phaseLocked: this.phaseLocked,
    };

    // Phase 7 · Step 3 — attach canonical bank snapshot when the ticker
    // fired. When disabled (default), `.tick()` returns null and the
    // `rhuftf` field is omitted — additive, byte-inert for pre-Phase-7
    // subscribers.
    const bankSnap = this.canonicalBank.tick();
    const snapOut: FieldSnapshot = bankSnap
      ? { ...snap, rhuftf: bankSnap }
      : snap;

    this.lastSnapshot = snapOut;

    // Throttle outbound emission to snapshotHz; kernel keeps ticking at full speed.
    const nowMs = performance.now();
    if (nowMs - this.lastEmitMs >= this.emitIntervalMs) {
      this.lastEmitMs = nowMs;
      this.emit('snapshot', snapOut);
    }
  }
}
