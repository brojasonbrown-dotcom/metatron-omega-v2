/**
 * V11 daemon entry point.
 *
 *   tsx src/index.ts [--port 7777] [--threads N] [--reserve-cores 1] [--target-m 6765]
 *
 * Env overrides: METATRON_DAEMON_PORT, METATRON_DAEMON_THREADS,
 *                METATRON_DAEMON_RESERVE, METATRON_DAEMON_TARGET_M.
 */
import { EngineHost } from './engineHost';
import { DaemonWsServer } from './wsServer';

function getArg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : undefined;
}
function getNum(name: string, envName: string, fallback: number): number {
  const v = getArg(name) ?? process.env[envName];
  if (!v) return fallback;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

async function main() {
  const port = getNum('port', 'METATRON_DAEMON_PORT', 7777);
  const threads = getNum('threads', 'METATRON_DAEMON_THREADS', 0);
  const reserve = getNum('reserve-cores', 'METATRON_DAEMON_RESERVE', 1);
  const targetM = getNum('target-m', 'METATRON_DAEMON_TARGET_M', 6765);

  console.log('[metatron-daemon] V11 native — booting…');
  const host = new EngineHost({
    reserveCores: reserve,
    threads: threads > 0 ? threads : undefined,
    initialTargetM: targetM,
    snapshotHz: 60,
  });

  const hw = host.hardware;
  const caps = host.getCapabilities();
  console.log(`[metatron-daemon] host: ${hw.cpuModel} (${hw.cpuThreads} threads, reserve ${reserve})`);
  console.log(`[metatron-daemon] RAM: ${(hw.totalRamBytes / 1024 / 1024 / 1024).toFixed(1)} GB total, ${(hw.usableRamBytes / 1024 / 1024 / 1024).toFixed(1)} GB usable`);
  console.log(`[metatron-daemon] self-bench: ${(caps.peakOpsPerSecond / 1e6).toFixed(1)} MOps/s`);
  console.log(`[metatron-daemon] hardware ceiling: M=${caps.maxModeByPrecision.f64.toLocaleString()} modes`);
  console.log(`[metatron-daemon] worker threads: ${host.scheduler.getThreads()}`);
  console.log('[metatron-daemon] driver families: ' + host.drivers.map((d) => d.id).join(', '));
  console.log('[metatron-daemon] banks: ' + host.registry.list().map((b) => b.id).join(', '));

  const server = new DaemonWsServer(host, { port, host: '127.0.0.1' });
  await server.ready();
  // Kick the kernel on boot so the first WS subscriber gets live data immediately.
  host.start();
  console.log(`[metatron-daemon] listening at ws://127.0.0.1:${server.port}`);

  const shutdown = async (sig: string) => {
    console.log(`[metatron-daemon] ${sig} — shutting down`);
    await server.close().catch(() => undefined);
    await host.stop().catch(() => undefined);
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((e) => {
  console.error('[metatron-daemon] fatal:', e);
  process.exit(1);
});
