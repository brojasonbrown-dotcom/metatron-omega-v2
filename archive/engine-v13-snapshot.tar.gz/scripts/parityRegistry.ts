/**
 * Shared parity-case registry.
 * ─────────────────────────────────────────────────────────────────────────
 * Extracted from `v10Parity.ts` in Phase 16 to break a cyclic top-level
 * await.
 *
 * The cycle was:
 *   v10Parity.ts       ──(await import)────────▶  stabilityTests.ts
 *   stabilityTests.ts  ──(import registerCase)─▶  v10Parity.ts
 *
 * `v10Parity.ts` contains top-level `await`, so ESM suspends its module body
 * at the dynamic import and will not resolve until `stabilityTests.ts`
 * evaluates — while `stabilityTests.ts` cannot evaluate until `v10Parity.ts`
 * resolves. The result was a permanent deadlock, reported by the runtime as
 * "Detected unsettled top-level await", with the process exiting 0 having
 * printed nothing. Both the v10 golden cases AND the 90 closed-form
 * stability checks were silently skipped.
 *
 * This module holds only the case type and the mutable registry. It has no
 * imports and no top-level await, so both harnesses can depend on it without
 * forming a cycle.
 */

export interface ParityCase {
  module: string;
  name: string;
  /** Returns a number or BigDecimal-as-string; harness diffs both. */
  v10: () => number | string;
  v11: () => number | string;
  /** Relative tolerance. Defaults to PARITY_TOL_F64_REL. */
  tol?: number;
}

export const CASES: ParityCase[] = [];

export function registerCase(c: ParityCase): void {
  CASES.push(c);
}
