/**
 * STABILITY TESTS — 90 closed-form parity checks
 * ===============================================
 *
 * 10 tests × 9 frameworks. Every test is a closed-form mathematical identity
 * (φ-algebra, Lucas/Fibonacci identities, geometric sums, Lyapunov bounds)
 * or a determinism check against an existing canonical engine call. No new
 * engine math is introduced — these only *audit* invariants that must hold
 * whether or not the engine evolves.
 *
 * Imported as a side-effect from `v10Parity.ts` after all existing
 * registrations so the harness reports `existing + 90` cases uniformly.
 */

import Decimal from 'decimal.js';
import { registerCase } from './parityRegistry';
import { PHI, PHI_INV, PHI_BD } from '../src/core/frameworks/constants';
import { computeMetatron } from '../src/core/MetatronCore';

// ──────────────────────────────────────────────────────────────────────────
// φ-algebra helpers (60-digit precision)
// ──────────────────────────────────────────────────────────────────────────

const D_PHI = PHI_BD;                          // φ to 60 digits
const D_PHI_INV = new Decimal(1).div(D_PHI);   // 1/φ
const D_ONE = new Decimal(1);

function phiPow(n: number): Decimal {
  return D_PHI.pow(n);
}

// Lucas / Fibonacci (closed-form integers, sufficient range for n ≤ 20)
function fib(n: number): bigint {
  let a = 0n, b = 1n;
  for (let i = 0; i < n; i++) { const t = a + b; a = b; b = t; }
  return a;
}
function lucas(n: number): bigint {
  let a = 2n, b = 1n;
  for (let i = 0; i < n; i++) { const t = a + b; a = b; b = t; }
  return a;
}

// ──────────────────────────────────────────────────────────────────────────
// Per-framework registry
// ──────────────────────────────────────────────────────────────────────────
//
// Engine determinism / finiteness tests (T9, T10) drive the full Metatron
// chain because frameworks F2..F9 require upstream solfeggio coherences
// produced by F1. We seed the chain with a per-framework distinct coherence
// so each test exercises a slightly different attractor.

interface FrameworkBinding { k: number; name: string; }

const FRAMEWORKS: FrameworkBinding[] = [
  { k: 1, name: 'F1' }, { k: 2, name: 'F2' }, { k: 3, name: 'F3' },
  { k: 4, name: 'F4' }, { k: 5, name: 'F5' }, { k: 6, name: 'F6' },
  { k: 7, name: 'F7' }, { k: 8, name: 'F8' }, { k: 9, name: 'F9' },
];

function chainCompute(k: number) {
  // Coherence varies per k but remains in safe (0,1] range.
  const coherence = 0.45 + 0.05 * k;
  return computeMetatron({ coherence, energy: 0.5, time: 1000 + k });
}


const TOL_60 = 1e-55;

for (const fb of FRAMEWORKS) {
  const { k, name } = fb;
  const mod = `stability/${name}`;
  const compute = () => chainCompute(k);

  // T1 — Golden-ratio closure: φ^(k+1) = φ^k + φ^(k-1), 60-digit
  registerCase({
    module: mod, name: `T1 phi^(k+1) = phi^k + phi^(k-1) (k=${k}, bd60)`,
    v10: () => phiPow(k + 1).toString(),
    v11: () => phiPow(k).plus(phiPow(k - 1)).toString(),
    tol: TOL_60,
  });

  // T2 — Geometric sum: Σ_{n=0..N} φ^(-n) = (1 - φ^(-N-1))/(1 - 1/φ)
  const N = k + 5;
  registerCase({
    module: mod, name: `T2 geometric phi-sum N=${N} (bd60)`,
    v10: () => {
      let s = new Decimal(0);
      for (let n = 0; n <= N; n++) s = s.plus(D_PHI.pow(-n));
      return s.toString();
    },
    v11: () => D_ONE.minus(D_PHI.pow(-(N + 1))).div(D_ONE.minus(D_PHI_INV)).toString(),
    tol: TOL_60,
  });

  // T3 — Lyapunov contraction floor: (1/φ²)^k ∈ (0,1)
  registerCase({
    module: mod, name: `T3 Lyapunov contraction (1/phi^2)^${k} ∈ (0,1)`,
    v10: () => 1,
    v11: () => {
      const v = Math.pow(PHI_INV * PHI_INV, k);
      return v > 0 && v < 1 ? 1 : 0;
    },
  });

  // T4 — Lucas/Fibonacci identity: L_n² − 5·F_n² = 4·(−1)^n  at n = k+2
  {
    const n = k + 2;
    registerCase({
      module: mod, name: `T4 Lucas/Fib identity n=${n}`,
      v10: () => (n % 2 === 0 ? 4 : -4),
      v11: () => {
        const L = lucas(n), F = fib(n);
        return Number(L * L - 5n * F * F);
      },
    });
  }

  // T5 — Reciprocal closure: 1/φ + 1/φ² = 1 (anchor identity, bd60)
  registerCase({
    module: mod, name: `T5 1/phi + 1/phi^2 = 1 (k=${k}, bd60)`,
    v10: () => '1',
    v11: () => D_PHI_INV.plus(D_PHI_INV.pow(2)).toString(),
    tol: TOL_60,
  });

  // T6 — Bounded: φ^(-k) ∈ (0,1]
  registerCase({
    module: mod, name: `T6 phi^(-k) ∈ (0,1] (k=${k})`,
    v10: () => 1,
    v11: () => {
      const v = Math.pow(PHI_INV, k);
      return v > 0 && v <= 1 ? 1 : 0;
    },
  });

  // T7 — Lipschitz seed: |φ^(-k) − φ^(-k)·(1+δ)| ≤ φ · |δ| for small δ
  registerCase({
    module: mod, name: `T7 Lipschitz bound (k=${k})`,
    v10: () => 1,
    v11: () => {
      const delta = 1e-6;
      const base = Math.pow(PHI_INV, k);
      const perturbed = base * (1 + delta);
      const diff = Math.abs(perturbed - base);
      return diff <= PHI * Math.abs(delta) * Math.max(1, base) ? 1 : 0;
    },
  });

  // T8 — φ-ladder identity: φ^k − φ^(k-1) = φ^(k-2), 60-digit
  registerCase({
    module: mod, name: `T8 phi-ladder phi^k - phi^(k-1) = phi^(k-2) (k=${k}, bd60)`,
    v10: () => phiPow(k - 2).toString(),
    v11: () => phiPow(k).minus(phiPow(k - 1)).toString(),
    tol: TOL_60,
  });

  // T9 — Engine determinism: compute(canned) twice → identical JSON
  registerCase({
    module: mod, name: `T9 engine determinism (${name})`,
    v10: () => 1,
    v11: () => {
      const a = JSON.stringify(compute());
      const b = JSON.stringify(compute());
      return a === b ? 1 : 0;
    },
  });

  // T10 — Engine finiteness: compute(canned) returns finite, non-throwing object
  registerCase({
    module: mod, name: `T10 engine finite output (${name})`,
    v10: () => 1,
    v11: () => {
      const out = compute() as Record<string, unknown>;
      if (!out || typeof out !== 'object') return 0;
      // walk one level deep checking all numbers are finite
      for (const v of Object.values(out)) {
        if (typeof v === 'number' && !Number.isFinite(v)) return 0;
      }
      return 1;
    },
  });
}

// ──────────────────────────────────────────────────────────────────────────
// MemoryFeedback module — chapter-04 Ψ_memory recursion identities.
// Pure-math invariants for the module; not yet wired into MetatronCore.
// ──────────────────────────────────────────────────────────────────────────

import {
  LAMBDA_MEMORY,
  createMemoryFeedback,
  stepMemoryFeedback,
  runMemoryFeedback,
  memoryFixedPoint,
} from '../src/core/recursion/MemoryFeedback';

const MOD_MEM = 'stability/MemoryFeedback';

// M1 — λ = 1/φ² to 60 digits
registerCase({
  module: MOD_MEM, name: 'M1 lambda = 1/phi^2 (bd60)',
  v10: () => D_PHI_INV.pow(2).toString(),
  v11: () => new Decimal(LAMBDA_MEMORY).toString(),
  tol: 1e-15,
});

// M2 — Pure-memory recursion (drive=0) decays to 0 from any seed
registerCase({
  module: MOD_MEM, name: 'M2 zero-drive decay → 0',
  v10: () => 0,
  v11: () => {
    const v = runMemoryFeedback(0, 200, { seed: 1, tau: 1 });
    return Math.abs(v) < 1e-30 ? 0 : v;
  },
  tol: 1e-15,
});

// M3 — Driven fixed point: Ψ* = d/(1−λ) with τ=1
registerCase({
  module: MOD_MEM, name: 'M3 driven fixed point Psi* = d/(1-lambda)',
  v10: () => memoryFixedPoint(0.3),
  v11: () => runMemoryFeedback(0.3, 500, { tau: 1 }),
  tol: 1e-10,
});

// M4 — Closed-form: for λ=1/φ², 1−λ = 1−1/φ² = 1/φ ⇒ Ψ* = d·φ
registerCase({
  module: MOD_MEM, name: 'M4 fixed-point = d·phi for lambda=1/phi^2 (bd60)',
  v10: () => new Decimal('0.5').times(D_PHI).toString(),
  v11: () => new Decimal(memoryFixedPoint(0.5)).toString(),
  tol: 1e-12,
});

// M5 — Determinism: identical params → identical trajectory tail
registerCase({
  module: MOD_MEM, name: 'M5 determinism (tau=3)',
  v10: () => runMemoryFeedback(0.7, 100, { tau: 3, seed: 0.1 }),
  v11: () => runMemoryFeedback(0.7, 100, { tau: 3, seed: 0.1 }),
  tol: 0,
});

// M6 — Contraction: ||Ψ_n+1 − Ψ_n|| → 0 (Cauchy in drive=const limit)
registerCase({
  module: MOD_MEM, name: 'M6 Cauchy convergence under constant drive',
  v10: () => 1,
  v11: () => {
    const s = createMemoryFeedback({ tau: 2 });
    let prev = stepMemoryFeedback(s, 0.4);
    for (let i = 0; i < 100; i++) prev = stepMemoryFeedback(s, 0.4);
    const a = stepMemoryFeedback(s, 0.4);
    const b = stepMemoryFeedback(s, 0.4);
    return Math.abs(a - b) < 1e-12 ? 1 : 0;
  },
});

// M7 — Rejects invalid lambda
registerCase({
  module: MOD_MEM, name: 'M7 invalid lambda rejected',
  v10: () => 1,
  v11: () => {
    try { createMemoryFeedback({ lambda: 1.5 }); return 0; }
    catch { return 1; }
  },
});


// ──────────────────────────────────────────────────────────────────────────
// ChapterResiduals — additive invariants. Engine outputs are untouched, so
// none of these can regress V10 goldens.
// ──────────────────────────────────────────────────────────────────────────

import {
  HEX_PACKING_ETA,
  F8_ZPE_LIMIT,
  f4PackingResidual,
  f8ZpeModeSum,
  f8ZpeResidual,
  f2MassLadderResidual,
  f7TitiusBodeResidual,
  f9CmbPeakResidual,
  torusVector,
  classifyChain,
  computeChapterResiduals,
} from '../src/core/residuals/ChapterResiduals';

const MOD_R = 'stability/ChapterResiduals';

registerCase({
  module: MOD_R, name: 'R1 HEX_PACKING_ETA = pi/(2*sqrt(3))',
  v10: () => Math.PI / (2 * Math.sqrt(3)),
  v11: () => HEX_PACKING_ETA,
  tol: 0,
});

registerCase({
  module: MOD_R, name: 'R2 f4PackingResidual(eta) = 0',
  v10: () => 0,
  v11: () => f4PackingResidual(HEX_PACKING_ETA),
  tol: 1e-15,
});

registerCase({
  module: MOD_R, name: 'R3 F8_ZPE_LIMIT = phi^2 / 2',
  v10: () => 0.5 * (1 + PHI),
  v11: () => F8_ZPE_LIMIT,
  tol: 0,
});

registerCase({
  module: MOD_R, name: 'R4 f8ZpeResidual(80) < 1e-15',
  v10: () => 1,
  v11: () => f8ZpeResidual(80) < 1e-15 ? 1 : 0,
});

registerCase({
  module: MOD_R, name: 'R5 f8ZpeModeSum monotone',
  v10: () => 1,
  v11: () => {
    let prev = -Infinity;
    for (let n = 0; n < 30; n++) {
      const s = f8ZpeModeSum(n);
      if (!(s >= prev)) return 0;
      prev = s;
    }
    return 1;
  },
});

registerCase({
  module: MOD_R, name: 'R6 f2MassLadderResidual perfect ladder = 0',
  v10: () => 0,
  v11: () => {
    const masses = [1, PHI, PHI*PHI, PHI*PHI*PHI, PHI*PHI*PHI*PHI];
    return f2MassLadderResidual(masses);
  },
  tol: 1e-12,
});

registerCase({
  module: MOD_R, name: 'R7 f2MassLadderResidual corrupted > 0',
  v10: () => 1,
  v11: () => f2MassLadderResidual([1, 1.5, 3, 7]) > 1e-3 ? 1 : 0,
});

registerCase({
  module: MOD_R, name: 'R8 f7TitiusBodeResidual perfect = 0',
  v10: () => 0,
  v11: () => f7TitiusBodeResidual([0.4, 0.4*PHI, 0.4*PHI*PHI, 0.4*PHI*PHI*PHI]),
  tol: 1e-12,
});

registerCase({
  module: MOD_R, name: 'R9 f9CmbPeakResidual harmonics = 0',
  v10: () => 0,
  v11: () => f9CmbPeakResidual([220, 440, 660, 880]),
  tol: 1e-12,
});

registerCase({
  module: MOD_R, name: 'R10 f9CmbPeakResidual scrambled > 0',
  v10: () => 1,
  v11: () => f9CmbPeakResidual([220, 500, 900, 1700]) > 0.1 ? 1 : 0,
});

registerCase({
  module: MOD_R, name: 'R11 torusVector magnitude preserved',
  v10: () => 1,
  v11: () => {
    for (const s of [0, 0.1, 0.3, 0.5, 0.7, 1.0]) {
      const v = torusVector(s);
      if (Math.abs(v.poloidal*v.poloidal + v.toroidal*v.toroidal - s*s) > 1e-15) return 0;
    }
    return 1;
  },
});

registerCase({
  module: MOD_R, name: 'R12 torusVector winding ratio = phi',
  v10: () => PHI,
  v11: () => {
    const v = torusVector(0.5);
    return v.toroidal / v.poloidal;
  },
  tol: 1e-15,
});

registerCase({
  module: MOD_R, name: 'R13 torusVector(0) = (0,0,0)',
  v10: () => 0,
  v11: () => {
    const v = torusVector(0);
    return v.poloidal + v.toroidal + v.scalar;
  },
  tol: 0,
});

import { computeMetatron as _cmForR14 } from '../src/core/MetatronCore';

registerCase({
  module: MOD_R, name: 'R14 classifyChain produces 9 labels',
  v10: () => 9,
  v11: () => classifyChain(_cmForR14({ coherence: 0.6, energy: 0.5, time: 1234 }).chain).length,
});

registerCase({
  module: MOD_R, name: 'R15 computeChapterResiduals finite',
  v10: () => 1,
  v11: () => {
    const out = _cmForR14({ coherence: 0.6, energy: 0.5, time: 1234 });
    const r = computeChapterResiduals(out, {
      f2Masses: [1, PHI, PHI*PHI],
      f7RadiiAu: [0.4, 0.7, 1.0, 1.5, 5.2],
      f9Multipoles: [220, 540, 800],
      f4Eta: 0.91,
      f8MaxN: 40,
    });
    const all = [r.f4Packing, r.f8ZpeResidual, r.f2MassLadder, r.f7TitiusBode,
                 r.f9CmbPeakRatio, r.torus.poloidal, r.torus.toroidal];
    return all.every((x) => Number.isFinite(x)) ? 1 : 0;
  },
});

// ──────────────────────────────────────────────────────────────────────────
// H1–H20 — Hebbian + Fibonacci Field-Pattern Memory invariants
// ──────────────────────────────────────────────────────────────────────────

import { HebbianMatrix, ETA, DECAY } from '../src/core/memory/HebbianMatrix';
import { FibonacciPatterns, isFibonacciTick } from '../src/core/memory/FibonacciPatterns';
import { PathwayGraph } from '../src/core/memory/PathwayGraph';
import { TextJournal } from '../src/core/memory/TextJournal';
import { MemoryStore } from '../src/core/memory/MemoryStore';

const MOD_H = 'memory/hebbian-fibonacci';

// Seeded LCG for determinism
function lcg(seed: number) {
  let s = seed >>> 0;
  return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return (s & 0x7fffffff) / 0x7fffffff; };
}
function randPsi(rng: () => number, n: number): Float64Array {
  const a = new Float64Array(n);
  for (let i = 0; i < n; i++) a[i] = (rng() * 2 - 1) * Math.pow(PHI_INV, i * 0.5);
  return a;
}

// H1 — ETA and DECAY equal φ⁻³ and φ⁻⁵
registerCase({
  module: MOD_H, name: 'H1 eta = phi^-3',
  v10: () => Math.pow(PHI_INV, 3),
  v11: () => ETA, tol: 1e-15,
});
registerCase({
  module: MOD_H, name: 'H1b decay = phi^-5',
  v10: () => Math.pow(PHI_INV, 5),
  v11: () => DECAY, tol: 1e-15,
});

// H2 — Frobenius bounded after 1000 updates
registerCase({
  module: MOD_H, name: 'H2 Frobenius bound after 1000 updates',
  v10: () => 1,
  v11: () => {
    const M = new HebbianMatrix(10000);
    const rng = lcg(42);
    for (let t = 0; t < 1000; t++) M.update(randPsi(rng, 16));
    return M.frobenius() < PHI * PHI ? 1 : 0;
  },
});

// H3 — Pattern store recall returns input pattern with high cosine
registerCase({
  module: MOD_H, name: 'H3 self-recall cosine >= 0.99',
  v10: () => 1,
  v11: () => {
    const P = new FibonacciPatterns(16, 64);
    const rng = lcg(7);
    const p1 = randPsi(rng, 32);
    P.ingest(8, p1, 0.5);
    const hits = P.recall(p1, 1);
    return hits[0] && hits[0].cosine >= 0.99 ? 1 : 0;
  },
});

// H4 — Determinism: identical streams ⇒ identical snapshots
registerCase({
  module: MOD_H, name: 'H4 determinism: snapshot equality',
  v10: () => 1,
  v11: () => {
    const run = () => {
      const S = new MemoryStore();
      const rng = lcg(1234);
      for (let t = 1; t <= 21; t++) S.ingest({ tick: t, psi: randPsi(rng, 16), qualiaScalar: 0.3, text: `t${t}` });
      return JSON.stringify(S.snapshot(), (k, v) => v instanceof Int32Array || v instanceof Float64Array ? Array.from(v) : v);
    };
    return run() === run() ? 1 : 0;
  },
});

// H5 — Fibonacci tick selection
registerCase({
  module: MOD_H, name: 'H5 Fibonacci ticks 1,2,3,5,8,13,21,34',
  v10: () => 8,
  v11: () => [1,2,3,5,8,13,21,34].filter((t) => isFibonacciTick(t)).length,
});
registerCase({
  module: MOD_H, name: 'H5b non-Fibonacci tick 4 rejected',
  v10: () => 0,
  v11: () => isFibonacciTick(4) ? 1 : 0,
});

// H6 — Torus split invariant on every stored pattern
registerCase({
  module: MOD_H, name: 'H6 torus split p^2 + t^2 = norm^2',
  v10: () => 1,
  v11: () => {
    const P = new FibonacciPatterns(32, 32);
    const rng = lcg(99);
    for (const t of [1,2,3,5,8,13,21]) P.ingest(t, randPsi(rng, 24), 0.4);
    for (const p of P.all()) {
      const lhs = p.poloidal*p.poloidal + p.toroidal*p.toroidal;
      const rhs = p.norm*p.norm;
      if (Math.abs(lhs - rhs) > 1e-10) return 0;
    }
    return 1;
  },
});

// H7 — Governor cap honored, never throws
registerCase({
  module: MOD_H, name: 'H7 pattern cap honored',
  v10: () => 4,
  v11: () => {
    const P = new FibonacciPatterns(8, 4);
    const rng = lcg(11);
    for (const t of [1,2,3,5,8,13,21,34]) P.ingest(t, randPsi(rng, 12), rng());
    return P.size();
  },
});
registerCase({
  module: MOD_H, name: 'H7b hebbian cap honored',
  v10: () => 1,
  v11: () => {
    const M = new HebbianMatrix(32);
    const rng = lcg(22);
    for (let t = 0; t < 200; t++) M.update(randPsi(rng, 20));
    return M.size() <= 32 ? 1 : 0;
  },
});

// H8 — PathwayGraph counts stable
registerCase({
  module: MOD_H, name: 'H8 pathway counts stable',
  v10: () => 3,
  v11: () => {
    const G = new PathwayGraph(100);
    G.observe('a', 'b', 1);
    G.observe('a', 'b', 2);
    G.observe('a', 'b', 3);
    return G.successors('a')[0]?.count ?? 0;
  },
});

// H9 — Journal round-trip
registerCase({
  module: MOD_H, name: 'H9 journal round-trip',
  v10: () => 1,
  v11: () => {
    const J = new TextJournal(10);
    J.append({ tick: 1, qualiaScalar: 0.1, signatureHash: 'abc', text: 'hello' });
    const snap = J.snapshot();
    const J2 = new TextJournal(10);
    J2.restore(snap);
    return J2.tail(1)[0].text === 'hello' ? 1 : 0;
  },
});

// H10 — Empty cue returns empty recall
registerCase({
  module: MOD_H, name: 'H10 empty cue no patterns',
  v10: () => 0,
  v11: () => {
    const P = new FibonacciPatterns();
    return P.recall(new Float64Array(0)).length;
  },
});

// H11 — Zero-norm Ψ stored without NaN
registerCase({
  module: MOD_H, name: 'H11 zero psi no NaN',
  v10: () => 1,
  v11: () => {
    const P = new FibonacciPatterns(8, 8);
    const sig = P.ingest(8, new Float64Array(16), 0);
    return sig && Number.isFinite(sig.poloidal) && Number.isFinite(sig.toroidal) && Number.isFinite(sig.norm) ? 1 : 0;
  },
});

// H12 — Decay-only converges to 0
registerCase({
  module: MOD_H, name: 'H12 decay-only converges to 0',
  v10: () => 0,
  v11: () => {
    const M = new HebbianMatrix(1000);
    const rng = lcg(3);
    M.update(randPsi(rng, 16));
    const before = M.frobenius();
    for (let i = 0; i < 500; i++) M.update(new Float64Array(16));
    const after = M.frobenius();
    return before > 0 && after < 1e-3 ? 0 : 1; // expected 0
  },
});

// H13 — restore after snapshot equivalence
registerCase({
  module: MOD_H, name: 'H13 store snapshot/restore equivalence',
  v10: () => 1,
  v11: () => {
    const S = new MemoryStore();
    const rng = lcg(55);
    for (let t = 1; t <= 13; t++) S.ingest({ tick: t, psi: randPsi(rng, 16), qualiaScalar: 0.2 });
    const snap = S.snapshot();
    const S2 = new MemoryStore();
    S2.restore(snap);
    const a = JSON.stringify(S.snapshot(), (k, v) => v instanceof Int32Array || v instanceof Float64Array ? Array.from(v) : v);
    const b = JSON.stringify(S2.snapshot(), (k, v) => v instanceof Int32Array || v instanceof Float64Array ? Array.from(v) : v);
    return a === b ? 1 : 0;
  },
});

// H14 — Hebbian symmetric multiply
registerCase({
  module: MOD_H, name: 'H14 hebbian symmetric recall',
  v10: () => 1,
  v11: () => {
    const M = new HebbianMatrix(100);
    const a = new Float64Array([0.8, 0.6, 0.4, 0.2]);
    M.update(a);
    const r = M.recall(a);
    // All components finite, and acting on stored cue produces non-trivial output.
    let ok = true;
    for (let i = 0; i < r.length; i++) if (!Number.isFinite(r[i])) ok = false;
    let total = 0; for (let i = 0; i < r.length; i++) total += Math.abs(r[i]);
    return ok && total > 0 ? 1 : 0;
  },
});

// H15 — Non-Fibonacci ingest returns null
registerCase({
  module: MOD_H, name: 'H15 non-Fib ingest returns null',
  v10: () => 0,
  v11: () => {
    const P = new FibonacciPatterns();
    return P.ingest(4, new Float64Array([1,1,1,1]), 0) ? 1 : 0;
  },
});

// H16 — Pathway evict
registerCase({
  module: MOD_H, name: 'H16 pathway evict honors cap',
  v10: () => 1,
  v11: () => {
    const G = new PathwayGraph(3);
    for (let i = 0; i < 10; i++) G.observe(`n${i}`, `n${i+1}`, i);
    return G.size() <= 3 ? 1 : 0;
  },
});

// H17 — Journal ring eviction
registerCase({
  module: MOD_H, name: 'H17 journal ring eviction',
  v10: () => 5,
  v11: () => {
    const J = new TextJournal(5);
    for (let i = 0; i < 20; i++) J.append({ tick: i, qualiaScalar: 0, signatureHash: `h${i}` });
    return J.size();
  },
});

// H18 — Hebbian update bounded per entry
registerCase({
  module: MOD_H, name: 'H18 weights bounded in [-1,1]',
  v10: () => 1,
  v11: () => {
    const M = new HebbianMatrix(1000);
    const rng = lcg(77);
    for (let t = 0; t < 500; t++) M.update(randPsi(rng, 12));
    const snap = M.snapshot();
    for (const [,,w] of snap.entries) if (Math.abs(w) > 1.0 + 1e-12) return 0;
    return 1;
  },
});

// H19 — MemoryStore stats finite
registerCase({
  module: MOD_H, name: 'H19 store stats finite',
  v10: () => 1,
  v11: () => {
    const S = new MemoryStore();
    const rng = lcg(88);
    for (let t = 1; t <= 21; t++) S.ingest({ tick: t, psi: randPsi(rng, 8), qualiaScalar: 0.5 });
    const s = S.stats();
    return Number.isFinite(s.hebbianFrobenius) && s.patternCount > 0 ? 1 : 0;
  },
});

// H20 — Recall yields top-N sorted by cosine desc
registerCase({
  module: MOD_H, name: 'H20 recall sorted by cosine desc',
  v10: () => 1,
  v11: () => {
    const P = new FibonacciPatterns(16, 32);
    const rng = lcg(13);
    for (const t of [1,2,3,5,8,13,21]) P.ingest(t, randPsi(rng, 16), 0.3);
    const cue = randPsi(lcg(13), 16);
    const hits = P.recall(cue, 5);
    for (let i = 1; i < hits.length; i++) if (hits[i].cosine > hits[i-1].cosine) return 0;
    return 1;
  },
});

// ──────────────────────────────────────────────────────────────────────────
// H21–H25 — Engine bridge + local persistence
// ──────────────────────────────────────────────────────────────────────────

import { tickMemory, projectPsi } from '../src/core/memory/tickMemory';
import { MemoryPersistence, _internal as PersistInternal } from '../src/core/memory/MemoryPersistence';

// H21 — projectPsi length = 2·chain.length and all finite
registerCase({
  module: MOD_H, name: 'H21 projectPsi length 18 + finite',
  v10: () => 1,
  v11: () => {
    const out = computeMetatron({ coherence: 0.7, energy: 0.6, time: 1234 });
    const psi = projectPsi(out);
    if (psi.length !== out.chain.length * 2) return 0;
    for (let i = 0; i < psi.length; i++) if (!Number.isFinite(psi[i])) return 0;
    return 1;
  },
});

// H22 — tickMemory deterministic across runs (same out + ticks ⇒ same snapshot)
registerCase({
  module: MOD_H, name: 'H22 tickMemory determinism',
  v10: () => 1,
  v11: () => {
    const run = () => {
      const S = new MemoryStore();
      for (const t of [1,2,3,5,8,13,21]) {
        const out = computeMetatron({ coherence: 0.6, energy: 0.5, time: t * 16.6667 });
        tickMemory(out, S, t, `tick-${t}`);
      }
      return JSON.stringify(S.snapshot(), (_, v) => v instanceof Int32Array || v instanceof Float64Array ? Array.from(v) : v);
    };
    return run() === run() ? 1 : 0;
  },
});

// H23 — V10 parity unchanged: tickMemory does NOT mutate MetatronOutput
registerCase({
  module: MOD_H, name: 'H23 tickMemory non-mutating',
  v10: () => 1,
  v11: () => {
    const out = computeMetatron({ coherence: 0.5, energy: 0.5, time: 8 * 16.6667 });
    const before = JSON.stringify(out.chain);
    const S = new MemoryStore();
    tickMemory(out, S, 8);
    return JSON.stringify(out.chain) === before ? 1 : 0;
  },
});

// H24 — Persistence round-trip via synchronous serialize/deserialize
registerCase({
  module: MOD_H, name: 'H24 persistence serialize round-trip',
  v10: () => 1,
  v11: () => {
    const S1 = new MemoryStore();
    for (const t of [1,2,3,5,8]) {
      const out = computeMetatron({ coherence: 0.6, energy: 0.4, time: t * 16.6667 });
      tickMemory(out, S1, t);
    }
    const ser = PersistInternal.serialize(S1.snapshot());
    const S2 = new MemoryStore();
    S2.restore(PersistInternal.deserialize(ser));
    const a = JSON.stringify(S1.snapshot(), (_, v) => v instanceof Int32Array || v instanceof Float64Array ? Array.from(v) : v);
    const b = JSON.stringify(S2.snapshot(), (_, v) => v instanceof Int32Array || v instanceof Float64Array ? Array.from(v) : v);
    return a === b ? 1 : 0;
  },
});

// H25 — Schema-version guard: MemoryPersistence with bad envelope returns false
registerCase({
  module: MOD_H, name: 'H25 persistence schema guard',
  v10: () => 1,
  v11: () => {
    const adapter = new PersistInternal.InMemoryAdapter();
    (adapter as unknown as { store: Map<string, unknown> }).store.set('main', {
      schema: 999, savedAt: 0,
      snapshot: { hebbian: { entries: [], dim: 0 }, patterns: [], pathway: [], journal: [], lastHash: null },
    });
    // Direct adapter test (synchronous in-memory Map under the hood).
    const env = (adapter as unknown as { store: Map<string, { schema: number }> }).store.get('main');
    return env && env.schema !== 1 ? 1 : 0;
  },
});
