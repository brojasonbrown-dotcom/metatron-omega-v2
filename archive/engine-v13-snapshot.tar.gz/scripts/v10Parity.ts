/**
 * METATRON V11 — V10 PARITY HARNESS
 * ==================================
 *
 * Run with:  bun scripts/v10Parity.ts [--module=<name>] [--json]
 *
 * Each registered case replays a canned input through (a) the vendored V10
 * implementation and (b) the V11 implementation, then asserts numeric
 * equality within tolerance. ANY case that drifts past tolerance fails the
 * run with non-zero exit. NO case is allowed to be skipped silently.
 *
 * The harness is intentionally minimal:
 *   - no test framework dependency (bun + plain TS)
 *   - JSON report on stdout when --json is passed
 *   - exit code = number of failed cases
 *
 * F-module ports register their cases by importing this module's
 * `registerCase` and pushing into CASES. The runner walks CASES at the
 * bottom of the file. New ports MUST add at least one canned case before
 * being merged.
 */

import {
  PHI, PHI_BD, PHI_INV, PHI_SQ, KAPPA, OMEGA_C,
  PARITY_TOL_F64_REL,
} from '../src/core/frameworks/constants';
import { real, sin, cos, atan2, setWorkingPrecision, getWorkingPrecision } from '../src/core/numerics/Real';
import { computeF8 } from '../src/core/frameworks/F8_SubPlanckian';
import { cannedF8Input } from '../vendor/v10-reference/src/engine/v10Goldens/F8';
import { computeF1 } from '../src/core/frameworks/F1_Septenary';
import { cannedF1Input } from '../vendor/v10-reference/src/engine/v10Goldens/F1';
import { computeF2 } from '../src/core/frameworks/F2_Quantum';
import { cannedF2Input } from '../vendor/v10-reference/src/engine/v10Goldens/F2_Quantum';
import { computeF3 } from '../src/core/frameworks/F3_Atomic';
import { cannedF3Input } from '../vendor/v10-reference/src/engine/v10Goldens/F3_Atomic';
import { computeF4 } from '../src/core/frameworks/F4_Geometric';
import { cannedF4Input } from '../vendor/v10-reference/src/engine/v10Goldens/F4';
import { computeF5 } from '../src/core/frameworks/F5_ColorMusic';
import { cannedF5Input } from '../vendor/v10-reference/src/engine/v10Goldens/F5_ColorMusic';
import { computeF6 } from '../src/core/frameworks/F6_Hebrew';
import { cannedF6Input } from '../vendor/v10-reference/src/engine/v10Goldens/F6_Hebrew';
import { computeF7 } from '../src/core/frameworks/F7_Galactic';
import { cannedF7Input } from '../vendor/v10-reference/src/engine/v10Goldens/F7_Galactic';
import { computeF9 } from '../src/core/frameworks/F9_HyperGalactic';
import { cannedF9Input } from '../vendor/v10-reference/src/engine/v10Goldens/F9_HyperGalactic';
import { readFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import Decimal from 'decimal.js';

// ─────────────────────────────────────────────────────────────────────────
// Case registry
// ─────────────────────────────────────────────────────────────────────────
//
// The registry itself lives in `./parityRegistry` so that `stabilityTests.ts`
// can import `registerCase` without depending on this module — which carries
// top-level await and would otherwise deadlock the pair. Re-exported here so
// existing `from './v10Parity'` imports keep resolving.
export type { ParityCase } from './parityRegistry';
export { CASES, registerCase } from './parityRegistry';

import { CASES, registerCase } from './parityRegistry';


// ─────────────────────────────────────────────────────────────────────────
// Foundation cases (constants + bd-trig). These MUST pass before any
// F-module port is even attempted.
// ─────────────────────────────────────────────────────────────────────────

registerCase({
  module: 'constants',
  name: 'phi^2 == phi + 1 (f64)',
  v10: () => PHI * PHI,
  v11: () => PHI + 1,
});

registerCase({
  module: 'constants',
  name: 'phi^2 identity (bd, 60 digits)',
  v10: () => PHI_BD.times(PHI_BD).toString(),
  v11: () => PHI_BD.plus(1).toString(),
  tol: 1e-55,
});

registerCase({
  module: 'constants',
  name: 'kappa = 1/(phi*pi)',
  v10: () => KAPPA,
  v11: () => 1 / (PHI * Math.PI),
});

registerCase({
  module: 'constants',
  name: 'OMEGA_C = phi^-2',
  v10: () => OMEGA_C,
  v11: () => PHI_INV * PHI_INV,
});

// bd-trig: sin(π/6) = 1/2 to 60 digits
registerCase({
  module: 'numerics/Real',
  name: 'sin(pi/6) = 1/2 (bd, 60 digits)',
  v10: () => '0.5',
  v11: () => {
    setWorkingPrecision(60);
    const x = real(new Decimal(Decimal.acos(-1)).div(6).toString(), 'bd');
    return sin(x).d!.toString();
  },
  tol: 1e-55,
});

// bd-trig: cos(π/3) = 1/2 to 60 digits
registerCase({
  module: 'numerics/Real',
  name: 'cos(pi/3) = 1/2 (bd, 60 digits)',
  v10: () => '0.5',
  v11: () => {
    setWorkingPrecision(60);
    const x = real(new Decimal(Decimal.acos(-1)).div(3).toString(), 'bd');
    return cos(x).d!.toString();
  },
  tol: 1e-55,
});

// bd-trig: sin² + cos² = 1 at φ (transcendental input)
registerCase({
  module: 'numerics/Real',
  name: 'sin^2(phi) + cos^2(phi) = 1 (bd, 60 digits)',
  v10: () => '1',
  v11: () => {
    setWorkingPrecision(60);
    const x = real(PHI_BD.toString(), 'bd');
    const s = sin(x).d!;
    const c = cos(x).d!;
    return s.times(s).plus(c.times(c)).toString();
  },
  tol: 1e-55,
});

// atan2 quadrants
registerCase({
  module: 'numerics/Real',
  name: 'atan2(1, 1) = pi/4 (bd, 60 digits)',
  v10: () => Decimal.acos(-1).div(4).toString(),
  v11: () => {
    setWorkingPrecision(60);
    const y = real('1', 'bd');
    const x = real('1', 'bd');
    return atan2(y, x).d!.toString();
  },
  tol: 1e-55,
});

registerCase({
  module: 'numerics/Real',
  name: 'atan2(-1, -1) = -3pi/4 (bd)',
  v10: () => Decimal.acos(-1).times(-3).div(4).toString(),
  v11: () => {
    setWorkingPrecision(60);
    return atan2(real('-1', 'bd'), real('-1', 'bd')).d!.toString();
  },
  tol: 1e-55,
});

// ─────────────────────────────────────────────────────────────────────────
// F8 (Sub-Planckian) — V11 against V10 JSON golden, M=55 spine
// ─────────────────────────────────────────────────────────────────────────

const __dirname = dirname(fileURLToPath(import.meta.url));
const F8_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F8.golden.json');
if (existsSync(F8_GOLDEN_PATH)) {
  const golden = JSON.parse(readFileSync(F8_GOLDEN_PATH, 'utf8'));
  const inp = cannedF8Input();
  // V11 with V10 defaults (5 rings, 7 modes, 13 spheres) MUST match golden
  const v11 = computeF8({
    coherence: inp.coherence, energy: inp.energy,
    pinealField: inp.pinealField, solfeggioCoherences: inp.solfeggioCoherences,
    time: inp.time, flowerCoherences: inp.flowerCoherences,
    hyperGalacticToroidalFeedback: inp.hyperGalacticToroidalFeedback,
  });

  // Scalar parity gate — every deterministic field metric
  const scalarChecks: Array<[string, number, number]> = [
    ['zeroPointEnergy',         golden.zeroPointEnergy,         v11.zeroPointEnergy],
    ['planckFoamDensity',       golden.planckFoamDensity,       v11.planckFoamDensity],
    ['kappaClosureFreq',        golden.kappaClosureFreq,        v11.kappaClosureFreq],
    ['tetrahedralPacking',      golden.tetrahedralPacking,      v11.tetrahedralPacking],
    ['vacuumToAtomicBridge',    golden.vacuumToAtomicBridge,    v11.vacuumToAtomicBridge],
    ['alephResonance',          golden.alephResonance,          v11.alephResonance],
    ['betResonance',            golden.betResonance,            v11.betResonance],
    ['nonCommutativePhase',     golden.nonCommutativePhase,     v11.nonCommutativePhase],
    ['kappaModulation',         golden.kappaModulation,         v11.kappaModulation],
    ['phiCubedStep',            golden.phiCubedStep,            v11.phiCubedStep],
    ['ncTensor',                golden.ncTensor,                v11.ncTensor],
    ['scaleRelativeTime',       golden.scaleRelativeTime,       v11.scaleRelativeTime],
    ['planckInternalFreq',      golden.planckInternalFreq,      v11.planckInternalFreq],
    ['lightModes',              golden.lightModes,              v11.lightModes],
    ['torusLinkStrength',       golden.torusLinkStrength,       v11.torusLinkStrength],
    ['septenaryComposite',      golden.septenaryComposite,      v11.septenaryComposite],
    ['chromaticComposite',      golden.chromaticComposite,      v11.chromaticComposite],
    ['fieldEntropy',            golden.fieldEntropy,            v11.fieldEntropy],
    ['structuralFormations',    golden.structuralFormations,    v11.structuralFormations],
    ['chainUpCoupling',         golden.chainUpCoupling,         v11.chainUpCoupling],
    ['superposition55Composite', golden.superposition55Composite, v11.superpositionMComposite],
  ];
  for (const [name, gv, vv] of scalarChecks) {
    registerCase({
      module: 'F8',
      name: `M=55 :: ${name}`,
      v10: () => gv,
      v11: () => vv,
      tol: 1e-12, // scalar V10 path must match to ~12 ULP (math is identical)
    });
  }

  // Array-shape parity — node counts and rings must match V10 spine
  registerCase({
    module: 'F8',
    name: 'M=55 :: ringAnalysis length = 5',
    v10: () => golden.ringAnalysis.length,
    v11: () => v11.ringAnalysis.length,
  });
  registerCase({
    module: 'F8',
    name: 'M=55 :: superpositions55 length = 55',
    v10: () => golden.superpositions55.length,
    v11: () => v11.superpositionsM.length,
  });
  // Per-node stability deep parity (one bit-for-bit check per ring)
  for (const r of [0, 1, 2, 3, 4]) {
    const idx = r === 0 ? 0 : r === 1 ? 3 : r === 2 ? 13 : r === 3 ? 25 : 45;
    registerCase({
      module: 'F8',
      name: `M=55 :: node[${idx}].stability (ring ${r})`,
      v10: () => golden.superpositions55[idx].stability,
      v11: () => v11.superpositionsM[idx].stability,
      tol: 1e-12,
    });
    registerCase({
      module: 'F8',
      name: `M=55 :: node[${idx}].structuralPotential (ring ${r})`,
      v10: () => golden.superpositions55[idx].structuralPotential,
      v11: () => v11.superpositionsM[idx].structuralPotential,
      tol: 1e-12,
    });
  }

  // V11 EXTENSION SANITY — at M=85 (R=6), V10 spine sub-metrics must equal
  // golden because rings 0-4 are unchanged; only ring 5 is new.
  const v11_R6 = computeF8({
    coherence: inp.coherence, energy: inp.energy,
    pinealField: inp.pinealField, solfeggioCoherences: inp.solfeggioCoherences,
    time: inp.time, flowerCoherences: inp.flowerCoherences,
    hyperGalacticToroidalFeedback: inp.hyperGalacticToroidalFeedback,
    targetRings: 6,
  });
  registerCase({
    module: 'F8',
    name: 'V11 ext :: R=6 ⇒ 85 nodes',
    v10: () => 85,
    v11: () => v11_R6.numNodes,
  });
  registerCase({
    module: 'F8',
    name: 'V11 ext :: R=6 ring[3] meanCoherence == V10 ring[3]',
    v10: () => golden.ringAnalysis[3].meanCoherence,
    v11: () => v11_R6.ringAnalysis[3].meanCoherence,
    tol: 1e-12,
  });
  registerCase({
    module: 'F8',
    name: 'V11 ext :: R=6 closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v11_R6.closureResidual)) === v11_R6.closureResidual ? 0.5 : -1,
  });
}

// ─────────────────────────────────────────────────────────────────────────
// F1 (Septenary) — V11 against V10 JSON golden, M=7 chakras
// ─────────────────────────────────────────────────────────────────────────

const F1_GOLDEN_PATH = join(__dirname, "v10Goldens", "F1.golden.json");
if (existsSync(F1_GOLDEN_PATH)) {
  const golden1 = JSON.parse(readFileSync(F1_GOLDEN_PATH, "utf8"));
  const inp1 = cannedF1Input();
  const v11f1 = computeF1({coherence: inp1.coherence, phases: inp1.phases, time: inp1.time, flowerCoherences: inp1.flowerCoherences, subPlanckianChainUp: inp1.subPlanckianChainUp});
  const f1Scalars: Array<[string, number, number]> = [
    ['overallAlignment',      golden1.overallAlignment,      v11f1.overallAlignment],
    ['toeplitzResonance',     golden1.toeplitzResonance,     v11f1.toeplitzResonance],
    ['toeplitzPhiMode',       golden1.toeplitzPhiMode,       v11f1.toeplitzPhiMode],
    ['psiDampedResonance',    golden1.psiDampedResonance,    v11f1.psiDampedResonance],
    ['psiStabilityIndex',     golden1.psiStabilityIndex,     v11f1.psiStabilityIndex],
    ['lucasTotal',            golden1.lucasTotal,            v11f1.lucasTotal],
    ['lucasNormalized',       golden1.lucasNormalized,       v11f1.lucasNormalized],
    ['kuramotoOrder',         golden1.kuramotoOrder,         v11f1.kuramotoOrder],
    ['kuramotoPhase',         golden1.kuramotoPhase,         v11f1.kuramotoPhase],
    ['solfeggioAlignment',    golden1.solfeggioAlignment,    v11f1.solfeggioAlignment],
    ['vacuumBridgeStrength',  golden1.vacuumBridgeStrength,  v11f1.vacuumBridgeStrength],
    ['sevenFoldClosure',      golden1.sevenFoldClosure,      v11f1.sevenFoldClosure],
    ['heptagonCoherence',     golden1.heptagonCoherence,     v11f1.heptagonCoherence],
    ['verticalFlow',          golden1.verticalFlow,          v11f1.verticalFlow],
    ['centralColumn',         golden1.centralColumn,         v11f1.centralColumn],
    ['inversePhiMirror',      golden1.inversePhiMirror,      v11f1.inversePhiMirror],
    ['spectralGapUtilization',golden1.spectralGapUtilization,v11f1.spectralGapUtilization],
    ['conditionStability',    golden1.conditionStability,    v11f1.conditionStability],
    ['psiDampedClosure',      golden1.psiDampedClosure,      v11f1.psiDampedClosure],
    ['closureBreathingBand',  golden1.closureBreathingBand,  v11f1.closureBreathingBand],
    ['realityLagF2',          golden1.realityLagF2,          v11f1.realityLagF2],
    ['dimensionalComplexity', golden1.dimensionalComplexity, v11f1.dimensionalComplexity],
    ['fieldOrganization',     golden1.fieldOrganization,     v11f1.fieldOrganization],
    ['chainDownCoupling',     golden1.chainDownCoupling,     v11f1.chainDownCoupling],
    ['chainUpCoupling',       golden1.chainUpCoupling,       v11f1.chainUpCoupling],
  ];
  for (const [name, gv, vv] of f1Scalars) {
    registerCase({ module: 'F1', name: `M=7 :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }

  registerCase({ module: 'F1', name: 'M=7 :: chakras length = 7',
    v10: () => golden1.chakras.length, v11: () => v11f1.chakras.length });
  registerCase({ module: 'F1', name: 'M=7 :: septenaryField55 length = 55',
    v10: () => golden1.septenaryField55.length, v11: () => v11f1.septenaryField55.length });
  registerCase({ module: 'F1', name: 'M=7 :: resonanceMatrix length = 49',
    v10: () => golden1.resonanceMatrix.length, v11: () => v11f1.resonanceMatrix.length });

  for (let c = 0; c < 7; c++) {
    registerCase({ module: 'F1', name: `M=7 :: chakra[${c}].resonance`,
      v10: () => golden1.chakras[c].resonance, v11: () => v11f1.chakras[c].resonance, tol: 1e-12 });
    registerCase({ module: 'F1', name: `M=7 :: chakra[${c}].alignment`,
      v10: () => golden1.chakras[c].alignment, v11: () => v11f1.chakras[c].alignment, tol: 1e-12 });
  }

  const v11f1_M13 = computeF1({
    coherence: inp1.coherence, phases: inp1.phases, time: inp1.time,
    flowerCoherences: inp1.flowerCoherences, subPlanckianChainUp: inp1.subPlanckianChainUp,
    targetModes: 13,
  });
  registerCase({ module: 'F1', name: 'V11 ext :: M=13 ⇒ extensionModes.length = 6',
    v10: () => 6, v11: () => v11f1_M13.extensionModes.length });
  registerCase({ module: 'F1', name: 'V11 ext :: M=13 overallAlignment == V10',
    v10: () => golden1.overallAlignment, v11: () => v11f1_M13.overallAlignment, tol: 1e-12 });
  registerCase({ module: 'F1', name: 'V11 ext :: M=13 chakra[3].resonance == V10',
    v10: () => golden1.chakras[3].resonance, v11: () => v11f1_M13.chakras[3].resonance, tol: 1e-12 });
  registerCase({ module: 'F1', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v11f1_M13.closureResidual)) === v11f1_M13.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// F2 (Quantum) — V11 against V10 JSON golden
// ─────────────────────────────────────────────────────────────────────────
const F2_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F2_Quantum.golden.json');
if (existsSync(F2_GOLDEN_PATH)) {
  const g2 = JSON.parse(readFileSync(F2_GOLDEN_PATH, 'utf8'));
  const i2 = cannedF2Input();
  const v2 = computeF2({
    coherence: i2.coherence, energy: i2.energy, pinealField: i2.pinealField,
    solfeggioCoherences: i2.solfeggioCoherences, time: i2.time,
    flowerCoherences: i2.flowerCoherences, septenaryChainUp: i2.septenaryChainUp,
  });
  const f2Scalars: Array<[string, number, number]> = [
    ['fineStructure',           g2.fineStructure,           v2.fineStructure],
    ['fineStructureAgreement',  g2.fineStructureAgreement,  v2.fineStructureAgreement],
    ['protonElectronRatio',     g2.protonElectronRatio,     v2.protonElectronRatio],
    ['quarkPhaseCoherence',     g2.quarkPhaseCoherence,     v2.quarkPhaseCoherence],
    ['quarkColorClosure',       g2.quarkColorClosure,       v2.quarkColorClosure],
    ['perfectFourthResonance',  g2.perfectFourthResonance,  v2.perfectFourthResonance],
    ['rydbergResonance',        g2.rydbergResonance,        v2.rydbergResonance],
    ['fieldEntropy',            g2.fieldEntropy,            v2.fieldEntropy],
    ['fieldOrganization',       g2.fieldOrganization,       v2.fieldOrganization],
    ['superposition55Composite',g2.superposition55Composite,v2.superposition55Composite],
    ['dimensionalComplexity',   g2.dimensionalComplexity,   v2.dimensionalComplexity],
    ['structuralFormations',    g2.structuralFormations,    v2.structuralFormations],
    ['chainDownCoupling',       g2.chainDownCoupling,       v2.chainDownCoupling],
    ['chainUpCoupling',         g2.chainUpCoupling,         v2.chainUpCoupling],
    ['quantumCoherence',        g2.quantumCoherence,        v2.quantumCoherence],
    ['planckBridgeResonance',   g2.planckBridgeResonance,   v2.planckBridgeResonance],
    ['protonElectronicDepth',   g2.protonElectronicDepth,   v2.protonElectronicDepth],
    ['protonMuonicDepth',       g2.protonMuonicDepth,       v2.protonMuonicDepth],
    ['protonRadiusPuzzleResolved', g2.protonRadiusPuzzleResolved, v2.protonRadiusPuzzleResolved],
    ['weinbergAgreement',       g2.weinbergAgreement,       v2.weinbergAgreement],
    ['runningCouplingMZ',       g2.runningCouplingMZ,       v2.runningCouplingMZ],
    ['rydbergKappaAlignment',   g2.rydbergKappaAlignment,   v2.rydbergKappaAlignment],
    ['standardModelCompleteness', g2.standardModelCompleteness, v2.standardModelCompleteness],
  ];
  for (const [name, gv, vv] of f2Scalars) {
    registerCase({ module: 'F2', name: `core :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }
  registerCase({ module: 'F2', name: 'core :: particleModes.length = 12',
    v10: () => 12, v11: () => v2.particleModes.length });
  registerCase({ module: 'F2', name: 'core :: quantumField55.length = 55',
    v10: () => 55, v11: () => v2.quantumField55.length });
  for (let i = 0; i < 12; i++) {
    registerCase({ module: 'F2', name: `core :: particleModes[${i}].resonance`,
      v10: () => g2.particleModes[i].resonance,
      v11: () => v2.particleModes[i].resonance, tol: 1e-12 });
  }
  for (const idx of [0, 6, 18, 30, 50]) {
    registerCase({ module: 'F2', name: `core :: quantumField55[${idx}]`,
      v10: () => g2.quantumField55[idx], v11: () => v2.quantumField55[idx], tol: 1e-12 });
  }
  // V11 extension: append 1 extra particle (charm), V10 core unchanged
  const v2ext = computeF2({
    coherence: i2.coherence, energy: i2.energy, pinealField: i2.pinealField,
    solfeggioCoherences: i2.solfeggioCoherences, time: i2.time,
    flowerCoherences: i2.flowerCoherences, septenaryChainUp: i2.septenaryChainUp,
    extensionParticles: [{ name: 'Charm', generation: 2, charge: 2/3, spin: 0.5, phiAffinity: PHI_INV * 0.9 }],
  });
  registerCase({ module: 'F2', name: 'V11 ext :: extensionModes.length = 1',
    v10: () => 1, v11: () => v2ext.extensionModes.length });
  registerCase({ module: 'F2', name: 'V11 ext :: core quantumCoherence == V10',
    v10: () => g2.quantumCoherence, v11: () => v2ext.quantumCoherence, tol: 1e-12 });
  registerCase({ module: 'F2', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v2.closureResidual)) === v2.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// F3 (Atomic) — V11 against V10 JSON golden
// ─────────────────────────────────────────────────────────────────────────
const F3_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F3_Atomic.golden.json');
if (existsSync(F3_GOLDEN_PATH)) {
  const g3 = JSON.parse(readFileSync(F3_GOLDEN_PATH, 'utf8'));
  const i3 = cannedF3Input();
  const v3 = computeF3({
    coherence: i3.coherence, nodeAmps: i3.nodeAmps,
    solfeggioCoherences: i3.solfeggioCoherences, time: i3.time,
    flowerCoherences: i3.flowerCoherences, quantumChainUp: i3.quantumChainUp,
  });
  const f3Scalars: Array<[string, number, number]> = [
    ['hydrogenCorrection',      g3.hydrogenCorrection,      v3.hydrogenCorrection],
    ['periodicResonance',       g3.periodicResonance,       v3.periodicResonance],
    ['fieldEntropy',            g3.fieldEntropy,            v3.fieldEntropy],
    ['fieldOrganization',       g3.fieldOrganization,       v3.fieldOrganization],
    ['superposition55Composite',g3.superposition55Composite,v3.superposition55Composite],
    ['structuralFormations',    g3.structuralFormations,    v3.structuralFormations],
    ['dimensionalComplexity',   g3.dimensionalComplexity,   v3.dimensionalComplexity],
    ['chainDownCoupling',       g3.chainDownCoupling,       v3.chainDownCoupling],
    ['chainUpCoupling',         g3.chainUpCoupling,         v3.chainUpCoupling],
    ['nobleGasResonance',       g3.nobleGasResonance,       v3.nobleGasResonance],
    ['nobleGasPhiRatio',        g3.nobleGasPhiRatio,        v3.nobleGasPhiRatio],
    ['nuclearMagicResonance',   g3.nuclearMagicResonance,   v3.nuclearMagicResonance],
    ['magicPhiAlignment',       g3.magicPhiAlignment,       v3.magicPhiAlignment],
    ['geometricProjection',     g3.geometricProjection,     v3.geometricProjection],
    ['psiShellStability',       g3.psiShellStability,       v3.psiShellStability],
    ['aufbauCompleteness',      g3.aufbauCompleteness,      v3.aufbauCompleteness],
    ['shellPhaseLead',          g3.shellPhaseLead,          v3.shellPhaseLead],
    ['trialityClosure',         g3.trialityClosure,         v3.trialityClosure],
    ['phiSquaredIdentity',      g3.phiSquaredIdentity,      v3.phiSquaredIdentity],
    ['rydbergPhiDecomposition', g3.rydbergPhiDecomposition, v3.rydbergPhiDecomposition],
    ['ionizationGradient',      g3.ionizationGradient,      v3.ionizationGradient],
    ['atomicCoherence',         g3.atomicCoherence,         v3.atomicCoherence],
  ];
  for (const [name, gv, vv] of f3Scalars) {
    registerCase({ module: 'F3', name: `core :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }
  registerCase({ module: 'F3', name: 'core :: bohrOrbits.length = 7',
    v10: () => 7, v11: () => v3.bohrOrbits.length });
  registerCase({ module: 'F3', name: 'core :: periodModes.length = 7',
    v10: () => 7, v11: () => v3.periodModes.length });
  registerCase({ module: 'F3', name: 'core :: atomicField55.length = 55',
    v10: () => 55, v11: () => v3.atomicField55.length });
  for (let n = 0; n < 7; n++) {
    registerCase({ module: 'F3', name: `core :: bohrOrbits[${n}].radius_m`,
      v10: () => g3.bohrOrbits[n].radius_m, v11: () => v3.bohrOrbits[n].radius_m, tol: 1e-12 });
    registerCase({ module: 'F3', name: `core :: periodModes[${n}].resonance`,
      v10: () => g3.periodModes[n].resonance, v11: () => v3.periodModes[n].resonance, tol: 1e-12 });
  }
  for (const idx of [0, 6, 18, 30, 50]) {
    registerCase({ module: 'F3', name: `core :: atomicField55[${idx}]`,
      v10: () => g3.atomicField55[idx], v11: () => v3.atomicField55[idx], tol: 1e-12 });
  }
  // V11 ext: 2 extra Bohr orbits (n=8, n=9), V10 core unchanged
  const v3ext = computeF3({
    coherence: i3.coherence, nodeAmps: i3.nodeAmps,
    solfeggioCoherences: i3.solfeggioCoherences, time: i3.time,
    flowerCoherences: i3.flowerCoherences, quantumChainUp: i3.quantumChainUp,
    extensionShells: 2,
  });
  registerCase({ module: 'F3', name: 'V11 ext :: extensionOrbits.length = 2',
    v10: () => 2, v11: () => v3ext.extensionOrbits.length });
  registerCase({ module: 'F3', name: 'V11 ext :: core atomicCoherence == V10',
    v10: () => g3.atomicCoherence, v11: () => v3ext.atomicCoherence, tol: 1e-12 });
  registerCase({ module: 'F3', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v3.closureResidual)) === v3.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// F4 (Geometric) — V11 against V10 JSON golden
// ─────────────────────────────────────────────────────────────────────────
const F4_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F4.golden.json');
if (existsSync(F4_GOLDEN_PATH)) {
  const g4 = JSON.parse(readFileSync(F4_GOLDEN_PATH, 'utf8'));
  const i4 = cannedF4Input();
  const v4 = computeF4({
    coherence: i4.coherence, nodeCoherences: i4.nodeCoherences, time: i4.time,
    solfeggioCoherences: i4.solfeggioCoherences, flowerCoherences: i4.flowerCoherences,
    atomicChainUp: i4.atomicChainUp,
  });
  const f4Scalars: Array<[string, number, number]> = [
    ['flowerOfLifeCoherence',     g4.flowerOfLifeCoherence,     v4.flowerOfLifeCoherence],
    ['metatronCubeIntegrity',     g4.metatronCubeIntegrity,     v4.metatronCubeIntegrity],
    ['goldenSpiralPhase',         g4.goldenSpiralPhase,         v4.goldenSpiralPhase],
    ['mersenneResonance',         g4.mersenneResonance,         v4.mersenneResonance],
    ['vesicaPiscisResonance',     g4.vesicaPiscisResonance,     v4.vesicaPiscisResonance],
    ['dualPolyhedraResonance',    g4.dualPolyhedraResonance,    v4.dualPolyhedraResonance],
    ['seedOfLifeCoherence',       g4.seedOfLifeCoherence,       v4.seedOfLifeCoherence],
    ['phiEdgeResonance',          g4.phiEdgeResonance,          v4.phiEdgeResonance],
    ['geometricComposite',        g4.geometricComposite,        v4.geometricComposite],
    ['eulerCharacteristic',       g4.eulerCharacteristic,       v4.eulerCharacteristic],
    ['zeckendorfDepth',           g4.zeckendorfDepth,           v4.zeckendorfDepth],
    ['fieldEntropy',              g4.fieldEntropy,              v4.fieldEntropy],
    ['fieldOrganization',         g4.fieldOrganization,         v4.fieldOrganization],
    ['dimensionalComplexity',     g4.dimensionalComplexity,     v4.dimensionalComplexity],
    ['superposition55Composite',  g4.superposition55Composite,  v4.superposition55Composite],
    ['structuralFormations',      g4.structuralFormations,      v4.structuralFormations],
    ['chainDownCoupling',         g4.chainDownCoupling,         v4.chainDownCoupling],
    ['chainUpCoupling',           g4.chainUpCoupling,           v4.chainUpCoupling],
    ['cos36Resonance',            g4.cos36Resonance,            v4.cos36Resonance],
    ['pentagonalSymmetry',        g4.pentagonalSymmetry,        v4.pentagonalSymmetry],
    ['metatronConnectionDensity', g4.metatronConnectionDensity, v4.metatronConnectionDensity],
    ['goldenAngleResonance',      g4.goldenAngleResonance,      v4.goldenAngleResonance],
    ['geometricCoherence',        g4.geometricCoherence,        v4.geometricCoherence],
    ['descartesDefectIntegrity',  g4.descartesDefectIntegrity,  v4.descartesDefectIntegrity],
    ['goldenNestingResonance',    g4.goldenNestingResonance,    v4.goldenNestingResonance],
    ['volumePhiPresence',         g4.volumePhiPresence,         v4.volumePhiPresence],
    ['starPolyhedraResonance',    g4.starPolyhedraResonance,    v4.starPolyhedraResonance],
    ['rhombicTriacontahedronCoh', g4.rhombicTriacontahedronCoh, v4.rhombicTriacontahedronCoh],
    ['icosahedralGroupResonance', g4.icosahedralGroupResonance, v4.icosahedralGroupResonance],
    ['surfaceAreaRatio',          g4.surfaceAreaRatio,          v4.surfaceAreaRatio],
  ];
  for (const [name, gv, vv] of f4Scalars) {
    registerCase({ module: 'F4', name: `core :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }
  registerCase({ module: 'F4', name: 'core :: platonic.length = 5',
    v10: () => 5, v11: () => v4.platonic.length });
  registerCase({ module: 'F4', name: 'core :: geometricField55.length = 55',
    v10: () => 55, v11: () => v4.geometricField55.length });
  registerCase({ module: 'F4', name: 'core :: ringAnalysis.length = 5',
    v10: () => 5, v11: () => v4.ringAnalysis.length });
  registerCase({ module: 'F4', name: 'core :: phiBinaryRepresentation',
    v10: () => g4.phiBinaryRepresentation === v4.phiBinaryRepresentation ? 1 : 0, v11: () => 1 });
  for (let s = 0; s < 5; s++) {
    registerCase({ module: 'F4', name: `core :: platonic[${s}].resonance`,
      v10: () => g4.platonic[s].resonance, v11: () => v4.platonic[s].resonance, tol: 1e-12 });
    registerCase({ module: 'F4', name: `core :: circumradiusHierarchy[${s}]`,
      v10: () => g4.circumradiusHierarchy[s], v11: () => v4.circumradiusHierarchy[s], tol: 1e-12 });
  }
  for (const idx of [0, 6, 18, 30, 50]) {
    registerCase({ module: 'F4', name: `core :: geometricField55[${idx}]`,
      v10: () => g4.geometricField55[idx], v11: () => v4.geometricField55[idx], tol: 1e-12 });
  }
  for (let r = 0; r < 5; r++) {
    registerCase({ module: 'F4', name: `core :: ringAnalysis[${r}].meanCoherence`,
      v10: () => g4.ringAnalysis[r].meanCoherence, v11: () => v4.ringAnalysis[r].meanCoherence, tol: 1e-12 });
    registerCase({ module: 'F4', name: `core :: ringAnalysis[${r}].phaseUniformity`,
      v10: () => g4.ringAnalysis[r].phaseUniformity, v11: () => v4.ringAnalysis[r].phaseUniformity, tol: 1e-12 });
  }
  // V11 ext: extend Metatron to 25 nodes; V10 path unchanged
  const v4ext = computeF4({
    coherence: i4.coherence, nodeCoherences: i4.nodeCoherences, time: i4.time,
    solfeggioCoherences: i4.solfeggioCoherences, flowerCoherences: i4.flowerCoherences,
    atomicChainUp: i4.atomicChainUp, extensionMetatronNodes: 25,
  });
  registerCase({ module: 'F4', name: 'V11 ext :: extensionNodes.length = 12',
    v10: () => 12, v11: () => v4ext.extensionNodes.length });
  registerCase({ module: 'F4', name: 'V11 ext :: core geometricCoherence == V10',
    v10: () => g4.geometricCoherence, v11: () => v4ext.geometricCoherence, tol: 1e-12 });
  registerCase({ module: 'F4', name: 'V11 ext :: core metatronCubeIntegrity == V10',
    v10: () => g4.metatronCubeIntegrity, v11: () => v4ext.metatronCubeIntegrity, tol: 1e-12 });
  registerCase({ module: 'F4', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v4.closureResidual)) === v4.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// F5 (Color/Music) — V11 against V10 JSON golden
// ─────────────────────────────────────────────────────────────────────────
const F5_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F5_ColorMusic.golden.json');
if (existsSync(F5_GOLDEN_PATH)) {
  const g5 = JSON.parse(readFileSync(F5_GOLDEN_PATH, 'utf8'));
  const i5 = cannedF5Input();
  const v5 = computeF5({
    coherence: i5.coherence, solfeggioCoherences: i5.solfeggioCoherences, time: i5.time,
    flowerCoherences: i5.flowerCoherences, geometricChainUp: i5.geometricChainUp,
  });
  const f5Scalars: Array<[string, number, number]> = [
    ['goldenAngle',                 g5.goldenAngle,                 v5.goldenAngle],
    ['dominantHue',                 g5.dominantHue,                 v5.dominantHue],
    ['fieldEntropy',                g5.fieldEntropy,                v5.fieldEntropy],
    ['fieldOrganization',           g5.fieldOrganization,           v5.fieldOrganization],
    ['dimensionalComplexity',       g5.dimensionalComplexity,       v5.dimensionalComplexity],
    ['superposition55Composite',    g5.superposition55Composite,    v5.superposition55Composite],
    ['structuralFormations',        g5.structuralFormations,        v5.structuralFormations],
    ['chainDownCoupling',           g5.chainDownCoupling,           v5.chainDownCoupling],
    ['chainUpCoupling',             g5.chainUpCoupling,             v5.chainUpCoupling],
    ['pythagoreanCommaResonance',   g5.pythagoreanCommaResonance,   v5.pythagoreanCommaResonance],
    ['minorSixthPhiResonance',      g5.minorSixthPhiResonance,      v5.minorSixthPhiResonance],
    ['solfeggioPhiStrength',        g5.solfeggioPhiStrength,        v5.solfeggioPhiStrength],
    ['perfectFourthPairResonance',  g5.perfectFourthPairResonance,  v5.perfectFourthPairResonance],
    ['overtoneSeriesResonance',     g5.overtoneSeriesResonance,     v5.overtoneSeriesResonance],
    ['justIntonationDeviation',     g5.justIntonationDeviation,     v5.justIntonationDeviation],
    ['newtonColorResonance',        g5.newtonColorResonance,        v5.newtonColorResonance],
    ['colorMusicCoherence',         g5.colorMusicCoherence,         v5.colorMusicCoherence],
    ['octaveBridgeCoherence',       g5.octaveBridgeCoherence,       v5.octaveBridgeCoherence],
    ['phiIntervalResonance',        g5.phiIntervalResonance,        v5.phiIntervalResonance],
    ['centAccuracyScore',           g5.centAccuracyScore,           v5.centAccuracyScore],
    ['fibonacciBeatResonance',      g5.fibonacciBeatResonance,      v5.fibonacciBeatResonance],
    ['chakraColorAlignment',        g5.chakraColorAlignment,        v5.chakraColorAlignment],
    ['dualMappingCoherence',        g5.dualMappingCoherence,        v5.dualMappingCoherence],
    ['goldenTuningAlignment',       g5.goldenTuningAlignment,       v5.goldenTuningAlignment],
    ['acousticWavelengthResonance', g5.acousticWavelengthResonance, v5.acousticWavelengthResonance],
    ['solfeggioCommaPresence',      g5.solfeggioCommaPresence,      v5.solfeggioCommaPresence],
  ];
  for (const [name, gv, vv] of f5Scalars) {
    registerCase({ module: 'F5', name: `core :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }
  registerCase({ module: 'F5', name: 'core :: chromaticModes.length = 12',
    v10: () => 12, v11: () => v5.chromaticModes.length });
  registerCase({ module: 'F5', name: 'core :: modeResonance.length = 7',
    v10: () => 7, v11: () => v5.modeResonance.length });
  registerCase({ module: 'F5', name: 'core :: colorMusicField55.length = 55',
    v10: () => 55, v11: () => v5.colorMusicField55.length });
  registerCase({ module: 'F5', name: 'core :: solfeggioOctaveBridge.length = 9',
    v10: () => 9, v11: () => v5.solfeggioOctaveBridge.length });
  for (let c = 0; c < 12; c++) {
    registerCase({ module: 'F5', name: `core :: chromaticModes[${c}].resonance`,
      v10: () => g5.chromaticModes[c].resonance, v11: () => v5.chromaticModes[c].resonance, tol: 1e-12 });
  }
  for (let m = 0; m < 7; m++) {
    registerCase({ module: 'F5', name: `core :: modeResonance[${m}].resonance`,
      v10: () => g5.modeResonance[m].resonance, v11: () => v5.modeResonance[m].resonance, tol: 1e-12 });
  }
  for (const idx of [0, 6, 18, 30, 50]) {
    registerCase({ module: 'F5', name: `core :: colorMusicField55[${idx}]`,
      v10: () => g5.colorMusicField55[idx], v11: () => v5.colorMusicField55[idx], tol: 1e-12 });
  }
  // V11 ext: 24-EDO microtonal extension; V10 12-tone path unchanged
  const v5ext = computeF5({
    coherence: i5.coherence, solfeggioCoherences: i5.solfeggioCoherences, time: i5.time,
    flowerCoherences: i5.flowerCoherences, geometricChainUp: i5.geometricChainUp,
    extensionChromaticSemitones: 24,
  });
  registerCase({ module: 'F5', name: 'V11 ext :: extensionMicrotones.length = 12',
    v10: () => 12, v11: () => v5ext.extensionMicrotones.length });
  registerCase({ module: 'F5', name: 'V11 ext :: core colorMusicCoherence == V10',
    v10: () => g5.colorMusicCoherence, v11: () => v5ext.colorMusicCoherence, tol: 1e-12 });
  registerCase({ module: 'F5', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v5.closureResidual)) === v5.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// F6 (Hebrew/Tree of Life) — V11 against V10 JSON golden
// ─────────────────────────────────────────────────────────────────────────
const F6_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F6_Hebrew.golden.json');
if (existsSync(F6_GOLDEN_PATH)) {
  const g6 = JSON.parse(readFileSync(F6_GOLDEN_PATH, 'utf8'));
  const i6 = cannedF6Input();
  const v6 = computeF6({
    coherence: i6.coherence, pinealCoherences: i6.pinealCoherences, time: i6.time,
    flowerCoherences: i6.flowerCoherences, solfeggioCoherences: i6.solfeggioCoherences,
    colorMusicChainUp: i6.colorMusicChainUp, septenaryCentralColumn: i6.septenaryCentralColumn,
  });
  const f6Scalars: Array<[string, number, number]> = [
    ['totalGematria',                  g6.totalGematria,                  v6.totalGematria],
    ['reducedGematria',                g6.reducedGematria,                v6.reducedGematria],
    ['phiGematria',                    g6.phiGematria,                    v6.phiGematria],
    ['treeOfLifeBalance',              g6.treeOfLifeBalance,              v6.treeOfLifeBalance],
    ['fieldEntropy',                   g6.fieldEntropy,                   v6.fieldEntropy],
    ['fieldOrganization',              g6.fieldOrganization,              v6.fieldOrganization],
    ['dimensionalComplexity',          g6.dimensionalComplexity,          v6.dimensionalComplexity],
    ['superposition55Composite',       g6.superposition55Composite,       v6.superposition55Composite],
    ['structuralFormations',           g6.structuralFormations,           v6.structuralFormations],
    ['chainDownCoupling',              g6.chainDownCoupling,              v6.chainDownCoupling],
    ['chainUpCoupling',                g6.chainUpCoupling,                v6.chainUpCoupling],
    ['scaleRelativeTime',              g6.scaleRelativeTime,              v6.scaleRelativeTime],
    ['yhvhResonance',                  g6.yhvhResonance,                  v6.yhvhResonance],
    ['chaiResonance',                  g6.chaiResonance,                  v6.chaiResonance],
    ['metatronResonance',              g6.metatronResonance,              v6.metatronResonance],
    ['pillarBalance',                  g6.pillarBalance,                  v6.pillarBalance],
    ['worldAlignment',                 g6.worldAlignment,                 v6.worldAlignment],
    ['pathwayFlowRate',                g6.pathwayFlowRate,                v6.pathwayFlowRate],
    ['gematriaFactorizationResonance', g6.gematriaFactorizationResonance, v6.gematriaFactorizationResonance],
    ['solfeggio22Mapping',             g6.solfeggio22Mapping,             v6.solfeggio22Mapping],
    ['binaryResonance',                g6.binaryResonance,                v6.binaryResonance],
    ['harmonicPiResonance',            g6.harmonicPiResonance,            v6.harmonicPiResonance],
    ['atbashMirrorCoherence',          g6.atbashMirrorCoherence,          v6.atbashMirrorCoherence],
    ['digitalRootCycleCoherence',      g6.digitalRootCycleCoherence,      v6.digitalRootCycleCoherence],
    ['fibonacciGematriaAlignment',     g6.fibonacciGematriaAlignment,     v6.fibonacciGematriaAlignment],
    ['binaryDensityResonance',         g6.binaryDensityResonance,         v6.binaryDensityResonance],
    ['sacredWordBinaryResonance',      g6.sacredWordBinaryResonance,      v6.sacredWordBinaryResonance],
    ['numerologicalReductionField',    g6.numerologicalReductionField,    v6.numerologicalReductionField],
    ['hebrewCoherence',                g6.hebrewCoherence,                v6.hebrewCoherence],
  ];
  for (const [name, gv, vv] of f6Scalars) {
    registerCase({ module: 'F6', name: `core :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }
  registerCase({ module: 'F6', name: 'core :: sefirot.length = 10',
    v10: () => 10, v11: () => v6.sefirot.length });
  registerCase({ module: 'F6', name: 'core :: treePaths.length = 22',
    v10: () => 22, v11: () => v6.treePaths.length });
  registerCase({ module: 'F6', name: 'core :: allLetters.length = 22',
    v10: () => 22, v11: () => v6.allLetters.length });
  registerCase({ module: 'F6', name: 'core :: hebrewField55.length = 55',
    v10: () => 55, v11: () => v6.hebrewField55.length });
  for (let s = 0; s < 10; s++) {
    registerCase({ module: 'F6', name: `core :: sefirot[${s}].resonance`,
      v10: () => g6.sefirot[s].resonance, v11: () => v6.sefirot[s].resonance, tol: 1e-12 });
  }
  for (let p = 0; p < 22; p++) {
    registerCase({ module: 'F6', name: `core :: treePaths[${p}].resonance`,
      v10: () => g6.treePaths[p].resonance, v11: () => v6.treePaths[p].resonance, tol: 1e-12 });
  }
  for (const idx of [0, 7, 18, 30, 42, 54]) {
    registerCase({ module: 'F6', name: `core :: hebrewField55[${idx}]`,
      v10: () => g6.hebrewField55[idx], v11: () => v6.hebrewField55[idx], tol: 1e-12 });
  }
  // V11 ext: extra letters appended; V10 22-letter kernel unchanged
  const v6ext = computeF6({
    coherence: i6.coherence, pinealCoherences: i6.pinealCoherences, time: i6.time,
    flowerCoherences: i6.flowerCoherences, solfeggioCoherences: i6.solfeggioCoherences,
    colorMusicChainUp: i6.colorMusicChainUp, septenaryCentralColumn: i6.septenaryCentralColumn,
    extensionLetters: [
      { char: 'ך', gematria: 500 }, { char: 'ם', gematria: 600 },
      { char: 'ן', gematria: 700 }, { char: 'ף', gematria: 800 },
      { char: 'ץ', gematria: 900 },
    ],
  });
  registerCase({ module: 'F6', name: 'V11 ext :: extensionLetters.length = 5',
    v10: () => 5, v11: () => v6ext.extensionLetters.length });
  registerCase({ module: 'F6', name: 'V11 ext :: core hebrewCoherence == V10',
    v10: () => g6.hebrewCoherence, v11: () => v6ext.hebrewCoherence, tol: 1e-12 });
  registerCase({ module: 'F6', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v6.closureResidual)) === v6.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// F7 (Galactic/Cosmic) — V11 against V10 JSON golden
// ─────────────────────────────────────────────────────────────────────────
const F7_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F7_Galactic.golden.json');
if (existsSync(F7_GOLDEN_PATH)) {
  const g7 = JSON.parse(readFileSync(F7_GOLDEN_PATH, 'utf8'));
  const i7 = cannedF7Input();
  const v7 = computeF7({
    coherence: i7.coherence, energy: i7.energy, time: i7.time,
    recursionDepth: i7.recursionDepth, flowerCoherences: i7.flowerCoherences,
    solfeggioCoherences: i7.solfeggioCoherences, hebrewChainUp: i7.hebrewChainUp,
  });
  const f7Scalars: Array<[string, number, number]> = [
    ['cosmicScale',                  g7.cosmicScale,                  v7.cosmicScale],
    ['hubbleHarmonic',               g7.hubbleHarmonic,               v7.hubbleHarmonic],
    ['galacticCoherence',            g7.galacticCoherence,            v7.galacticCoherence],
    ['dimensionalDepth',             g7.dimensionalDepth,             v7.dimensionalDepth],
    ['fieldEntropy',                 g7.fieldEntropy,                 v7.fieldEntropy],
    ['fieldOrganization',            g7.fieldOrganization,            v7.fieldOrganization],
    ['dimensionalComplexity',        g7.dimensionalComplexity,        v7.dimensionalComplexity],
    ['superposition55Composite',     g7.superposition55Composite,     v7.superposition55Composite],
    ['structuralFormations',         g7.structuralFormations,         v7.structuralFormations],
    ['chainDownCoupling',            g7.chainDownCoupling,            v7.chainDownCoupling],
    ['chainUpCoupling',              g7.chainUpCoupling,              v7.chainUpCoupling],
    ['scaleRelativeTime',            g7.scaleRelativeTime,            v7.scaleRelativeTime],
    ['keplerLawAgreement',           g7.keplerLawAgreement,           v7.keplerLawAgreement],
    ['titiusBodeResonance',          g7.titiusBodeResonance,          v7.titiusBodeResonance],
    ['spiralPitchResonance',         g7.spiralPitchResonance,         v7.spiralPitchResonance],
    ['fibonacciArmResonance',        g7.fibonacciArmResonance,        v7.fibonacciArmResonance],
    ['baoResonance',                 g7.baoResonance,                 v7.baoResonance],
    ['universeAgePhiResonance',      g7.universeAgePhiResonance,      v7.universeAgePhiResonance],
    ['orbitalPhiCascade',            g7.orbitalPhiCascade,            v7.orbitalPhiCascade],
    ['rotationCurveFlat',            g7.rotationCurveFlat,            v7.rotationCurveFlat],
    ['laplaceResonance',             g7.laplaceResonance,             v7.laplaceResonance],
    ['meanMotionResonance',          g7.meanMotionResonance,          v7.meanMotionResonance],
    ['kirkwoodFibonacciResonance',   g7.kirkwoodFibonacciResonance,   v7.kirkwoodFibonacciResonance],
    ['lagrangeGeometry',             g7.lagrangeGeometry,             v7.lagrangeGeometry],
    ['tullyFisherPhiAlignment',      g7.tullyFisherPhiAlignment,      v7.tullyFisherPhiAlignment],
    ['cosmicVoidStructure',          g7.cosmicVoidStructure,          v7.cosmicVoidStructure],
    ['virialSelfConsistency',        g7.virialSelfConsistency,        v7.virialSelfConsistency],
  ];
  for (const [name, gv, vv] of f7Scalars) {
    registerCase({ module: 'F7', name: `core :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }
  registerCase({ module: 'F7', name: 'core :: planetaryModes.length = 9',
    v10: () => 9, v11: () => v7.planetaryModes.length });
  registerCase({ module: 'F7', name: 'core :: galacticField55.length = 55',
    v10: () => 55, v11: () => v7.galacticField55.length });
  for (let p = 0; p < 9; p++) {
    registerCase({ module: 'F7', name: `core :: planetaryModes[${p}].resonance`,
      v10: () => g7.planetaryModes[p].resonance, v11: () => v7.planetaryModes[p].resonance, tol: 1e-12 });
  }
  for (const idx of [0, 7, 18, 30, 42, 54]) {
    registerCase({ module: 'F7', name: `core :: galacticField55[${idx}]`,
      v10: () => g7.galacticField55[idx], v11: () => v7.galacticField55[idx], tol: 1e-12 });
  }
  // V11 ext: trans-Neptunian / dwarf bodies
  const v7ext = computeF7({
    coherence: i7.coherence, energy: i7.energy, time: i7.time,
    recursionDepth: i7.recursionDepth, flowerCoherences: i7.flowerCoherences,
    solfeggioCoherences: i7.solfeggioCoherences, hebrewChainUp: i7.hebrewChainUp,
    extensionBodies: [
      { name: 'Eris',     au: 67.8 },
      { name: 'Sedna',    au: 506.0 },
      { name: 'Makemake', au: 45.7 },
      { name: 'Haumea',   au: 43.1 },
    ],
  });
  registerCase({ module: 'F7', name: 'V11 ext :: extensionBodies.length = 4',
    v10: () => 4, v11: () => v7ext.extensionBodies.length });
  registerCase({ module: 'F7', name: 'V11 ext :: core galacticCoherence == V10',
    v10: () => g7.galacticCoherence, v11: () => v7ext.galacticCoherence, tol: 1e-12 });
  registerCase({ module: 'F7', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v7.closureResidual)) === v7.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// F9 (HyperGalactic / Cosmic Web) — V11 against V10 JSON golden
// ─────────────────────────────────────────────────────────────────────────
const F9_GOLDEN_PATH = join(__dirname, 'v10Goldens', 'F9_HyperGalactic.golden.json');
if (existsSync(F9_GOLDEN_PATH)) {
  const g9 = JSON.parse(readFileSync(F9_GOLDEN_PATH, 'utf8'));
  const i9 = cannedF9Input();
  const v9 = computeF9({
    coherence: i9.coherence, energy: i9.energy, pinealField: i9.pinealField,
    solfeggioCoherences: i9.solfeggioCoherences, time: i9.time,
    recursionDepth: i9.recursionDepth, flowerCoherences: i9.flowerCoherences,
    galacticChainUp: i9.galacticChainUp,
  });
  const f9Scalars: Array<[string, number, number]> = [
    ['cosmicWebDensity',             g9.cosmicWebDensity,             v9.cosmicWebDensity],
    ['hubbleHarmonicExtended',       g9.hubbleHarmonicExtended,       v9.hubbleHarmonicExtended],
    ['darkEnergyGradient',           g9.darkEnergyGradient,           v9.darkEnergyGradient],
    ['cosmicWebCoherence',           g9.cosmicWebCoherence,           v9.cosmicWebCoherence],
    ['superClusterPhase',            g9.superClusterPhase,            v9.superClusterPhase],
    ['holographicEntropy',           g9.holographicEntropy,           v9.holographicEntropy],
    ['dimensionalProjection',        g9.dimensionalProjection,        v9.dimensionalProjection],
    ['chetResonance',                g9.chetResonance,                v9.chetResonance],
    ['tetResonance',                 g9.tetResonance,                 v9.tetResonance],
    ['psiDampingFactor',             g9.psiDampingFactor,             v9.psiDampingFactor],
    ['baryonAcousticScale',          g9.baryonAcousticScale,          v9.baryonAcousticScale],
    ['cmbHarmonic',                  g9.cmbHarmonic,                  v9.cmbHarmonic],
    ['cosmicToVacuumHandshake',      g9.cosmicToVacuumHandshake,      v9.cosmicToVacuumHandshake],
    ['adsCftBoundary',               g9.adsCftBoundary,               v9.adsCftBoundary],
    ['fieldEntropy',                 g9.fieldEntropy,                 v9.fieldEntropy],
    ['fieldOrganization',            g9.fieldOrganization,            v9.fieldOrganization],
    ['dimensionalComplexity',        g9.dimensionalComplexity,        v9.dimensionalComplexity],
    ['superposition55Composite',     g9.superposition55Composite,     v9.superposition55Composite],
    ['structuralFormations',         g9.structuralFormations,         v9.structuralFormations],
    ['chainDownCoupling',            g9.chainDownCoupling,            v9.chainDownCoupling],
    ['chainUpCoupling',              g9.chainUpCoupling,              v9.chainUpCoupling],
    ['scaleRelativeTime',            g9.scaleRelativeTime,            v9.scaleRelativeTime],
    ['cmbPeakPsiResonance',          g9.cmbPeakPsiResonance,          v9.cmbPeakPsiResonance],
    ['darkRatioSqrt5Resonance',      g9.darkRatioSqrt5Resonance,      v9.darkRatioSqrt5Resonance],
    ['darkEnergyWResonance',         g9.darkEnergyWResonance,         v9.darkEnergyWResonance],
    ['filamentResonance',            g9.filamentResonance,            v9.filamentResonance],
    ['voidResonance',                g9.voidResonance,                v9.voidResonance],
    ['toroidalIntegrity',            g9.toroidalIntegrity,            v9.toroidalIntegrity],
    ['holographicBound',             g9.holographicBound,             v9.holographicBound],
    ['cosmicSelfSimilarity',         g9.cosmicSelfSimilarity,         v9.cosmicSelfSimilarity],
    ['bekensteinHawkingResonance',   g9.bekensteinHawkingResonance,   v9.bekensteinHawkingResonance],
    ['friedmannFlatnessResonance',   g9.friedmannFlatnessResonance,   v9.friedmannFlatnessResonance],
    ['inflationEfoldsResonance',     g9.inflationEfoldsResonance,     v9.inflationEfoldsResonance],
    ['baryonAsymmetryResonance',     g9.baryonAsymmetryResonance,     v9.baryonAsymmetryResonance],
    ['sachsWolfeResonance',          g9.sachsWolfeResonance,          v9.sachsWolfeResonance],
    ['reionizationResonance',        g9.reionizationResonance,        v9.reionizationResonance],
    ['cosmicHorizonResonance',       g9.cosmicHorizonResonance,       v9.cosmicHorizonResonance],
  ];
  for (const [name, gv, vv] of f9Scalars) {
    registerCase({ module: 'F9', name: `core :: ${name}`, v10: () => gv, v11: () => vv, tol: 1e-12 });
  }
  registerCase({ module: 'F9', name: 'core :: cosmicField55.length = 55',
    v10: () => 55, v11: () => v9.cosmicField55.length });
  for (const idx of [0, 7, 18, 30, 42, 54]) {
    registerCase({ module: 'F9', name: `core :: cosmicField55[${idx}]`,
      v10: () => g9.cosmicField55[idx], v11: () => v9.cosmicField55[idx], tol: 1e-12 });
  }
  // V11 ext: extra CMB acoustic-peak multipoles beyond the canonical ladder
  const v9ext = computeF9({
    coherence: i9.coherence, energy: i9.energy, pinealField: i9.pinealField,
    solfeggioCoherences: i9.solfeggioCoherences, time: i9.time,
    recursionDepth: i9.recursionDepth, flowerCoherences: i9.flowerCoherences,
    galacticChainUp: i9.galacticChainUp,
    extensionMultipoles: [1100, 1500, 2000, 2500],
  });
  registerCase({ module: 'F9', name: 'V11 ext :: extensionMultipoles.length = 4',
    v10: () => 4, v11: () => v9ext.extensionMultipoles.length });
  registerCase({ module: 'F9', name: 'V11 ext :: core cosmicWebCoherence == V10',
    v10: () => g9.cosmicWebCoherence, v11: () => v9ext.cosmicWebCoherence, tol: 1e-12 });
  registerCase({ module: 'F9', name: 'V11 ext :: closureResidual ∈ [0, 1]',
    v10: () => 0.5,
    v11: () => Math.max(0, Math.min(1, v9.closureResidual)) === v9.closureResidual ? 0.5 : -1 });
}

// ─────────────────────────────────────────────────────────────────────────
// MetatronCore (unifier) — invariants
// ─────────────────────────────────────────────────────────────────────────
import { computeMetatron } from '../src/core/MetatronCore';
{
  const out = computeMetatron({ coherence: 0.7, energy: 0.6, time: 1234.5 });
  registerCase({ module: 'MetatronCore', name: 'chain.length = 9',
    v10: () => 9, v11: () => out.chain.length });
  registerCase({ module: 'MetatronCore', name: 'metatronClosure ∈ (0, 1]',
    v10: () => 0.5,
    v11: () => (out.metatronClosure > 0 && out.metatronClosure <= 1) ? 0.5 : -1 });
  registerCase({ module: 'MetatronCore', name: 'metatronCoherence ∈ (0, 1]',
    v10: () => 0.5,
    v11: () => (out.metatronCoherence > 0 && out.metatronCoherence <= 1) ? 0.5 : -1 });
  // Determinism: same input → identical outputs
  const out2 = computeMetatron({ coherence: 0.7, energy: 0.6, time: 1234.5 });
  registerCase({ module: 'MetatronCore', name: 'deterministic :: metatronClosure',
    v10: () => out.metatronClosure, v11: () => out2.metatronClosure, tol: 0 });
  registerCase({ module: 'MetatronCore', name: 'deterministic :: metatronCoherence',
    v10: () => out.metatronCoherence, v11: () => out2.metatronCoherence, tol: 0 });
  // Per-rung closure residuals must lie in [0,1]
  for (const rung of out.chain) {
    registerCase({ module: 'MetatronCore', name: `${rung.framework} :: closureResidual ∈ [0, 1]`,
      v10: () => 0.5,
      v11: () => (rung.closureResidual >= 0 && rung.closureResidual <= 1) ? 0.5 : -1 });
    registerCase({ module: 'MetatronCore', name: `${rung.framework} :: chainUpCoupling ∈ [0, 1]`,
      v10: () => 0.5,
      v11: () => (rung.chainUpCoupling >= 0 && rung.chainUpCoupling <= 1) ? 0.5 : -1 });
  }
  // No-regression: unifier's per-framework outputs equal direct calls at default canned input
  // (verified by F1..F9 parity blocks above; here we just confirm the chain composes).
  registerCase({ module: 'MetatronCore', name: 'F4 in chain matches F4 master output',
    v10: () => out.F4.geometricCoherence, v11: () => out.chain[4].masterMetric, tol: 0 });

  // Toroidal closure invariants
  registerCase({ module: 'MetatronCore', name: 'torusClosure ∈ [0, 1]',
    v10: () => 0, v11: () => (out.torusClosure >= 0 && out.torusClosure <= 1) ? 0 : 1 });
  registerCase({ module: 'MetatronCore', name: 'phaseCirculation ∈ [0, 1]',
    v10: () => 0, v11: () => (out.phaseCirculation >= 0 && out.phaseCirculation <= 1) ? 0 : 1 });
  registerCase({ module: 'MetatronCore', name: 'deterministic :: torusClosure',
    v10: () => out.torusClosure, v11: () => out2.torusClosure, tol: 0 });
  registerCase({ module: 'MetatronCore', name: 'deterministic :: phaseCirculation',
    v10: () => out.phaseCirculation, v11: () => out2.phaseCirculation, tol: 0 });

  // Phase 12: toroidal fixed-point sweep removed with `solveToroidalFixedPoint`.


  // ── Extension stress test ──────────────────────────────────────────────
  // Engage every V11 extension hook simultaneously and verify (a) the chain
  // still composes, (b) every rung's headline metric stays in [0,1],
  // (c) the master closure is no worse than the V10-anchor-only baseline,
  // (d) the fixed-point solver still converges with all extensions live.
  const baseline = computeMetatron({ coherence: 0.7, energy: 0.6, time: 1234.5 });
  const extended = computeMetatron({
    coherence: 0.7, energy: 0.6, time: 1234.5,
    extensions: {
      chakraModes: 9,                 // F1: 7 → 9 modes
      atomicShells: 9,                // F3: extra Bohr orbits
      metatronNodes: 19,              // F4: 13 → 19 nodes
      chromaticSemitones: 24,         // F5: 12 → 24 (quarter-tones)
      multipoles: [3000, 3500, 4000], // F9: extra CMB peaks
      quantumParticles: [
        { name: 'SterileNu', generation: 4, charge: 0, spin: 0.5, phiAffinity: 0.382 },
        { name: 'AxionLike', generation: 0, charge: 0, spin: 0,   phiAffinity: 0.236 },
      ],
      letters: [
        { char: 'ך', gematria: 500, category: 'simple' },
        { char: 'ם', gematria: 600, category: 'simple' },
      ],
      bodies: [
        { name: 'Eris',   au: 67.78 },
        { name: 'Sedna',  au: 506   },
      ],
    },
  });

  registerCase({ module: 'MetatronCore', name: 'extensions :: chain still 9 rungs',
    v10: () => 9, v11: () => extended.chain.length });
  registerCase({ module: 'MetatronCore', name: 'extensions :: all metrics ∈ [0,1]',
    v10: () => 1,
    v11: () => extended.chain.every((r) =>
      r.masterMetric >= 0 && r.masterMetric <= 1 &&
      r.closureResidual >= 0 && r.closureResidual <= 1 &&
      r.chainUpCoupling >= 0 && r.chainUpCoupling <= 1) ? 1 : 0 });
  registerCase({ module: 'MetatronCore', name: 'extensions :: torusClosure ∈ [0,1]',
    v10: () => 1,
    v11: () => (extended.torusClosure >= 0 && extended.torusClosure <= 1) ? 1 : 0 });
  registerCase({ module: 'MetatronCore', name: 'extensions :: metatronCoherence ∈ (0,1]',
    v10: () => 1,
    v11: () => (extended.metatronCoherence > 0 && extended.metatronCoherence <= 1) ? 1 : 0 });
  // Headline metrics shouldn't catastrophically diverge from baseline (≤ 30% delta).
  registerCase({ module: 'MetatronCore', name: 'extensions :: coherence within 30% of baseline',
    v10: () => 1,
    v11: () => (Math.abs(extended.metatronCoherence - baseline.metatronCoherence) /
      Math.max(1e-9, baseline.metatronCoherence) <= 0.3) ? 1 : 0 });
  // Phase 12: extension fixed-point sweep removed with `solveToroidalFixedPoint`.
  // Extensions must be deterministic
  const extended2 = computeMetatron({
    coherence: 0.7, energy: 0.6, time: 1234.5,
    extensions: { chakraModes: 9, atomicShells: 9, metatronNodes: 19 },
  });
  const extended2b = computeMetatron({
    coherence: 0.7, energy: 0.6, time: 1234.5,
    extensions: { chakraModes: 9, atomicShells: 9, metatronNodes: 19 },
  });
  registerCase({ module: 'MetatronCore', name: 'extensions :: deterministic torusClosure',
    v10: () => extended2.torusClosure, v11: () => extended2b.torusClosure, tol: 0 });
  registerCase({ module: 'MetatronCore', name: 'extensions :: deterministic metatronCoherence',
    v10: () => extended2.metatronCoherence, v11: () => extended2b.metatronCoherence, tol: 0 });
}

interface CaseResult {
  module: string;
  name: string;
  passed: boolean;
  drift: number;
  tol: number;
  v10: string;
  v11: string;
}

function diffNumeric(a: number | string, b: number | string): { drift: number; aS: string; bS: string } {
  const aD = typeof a === 'string' ? new Decimal(a) : new Decimal(a);
  const bD = typeof b === 'string' ? new Decimal(b) : new Decimal(b);
  const denom = Decimal.max(aD.abs(), bD.abs(), new Decimal(1));
  const drift = aD.minus(bD).abs().div(denom);
  return { drift: Number(drift.toString()), aS: aD.toString(), bS: bD.toString() };
}

function run(): { results: CaseResult[]; failed: number } {
  const results: CaseResult[] = [];
  let failed = 0;
  for (const c of CASES) {
    const tol = c.tol ?? PARITY_TOL_F64_REL;
    let result: CaseResult;
    try {
      const a = c.v10();
      const b = c.v11();
      const d = diffNumeric(a, b);
      const passed = d.drift <= tol;
      if (!passed) failed++;
      result = { module: c.module, name: c.name, passed, drift: d.drift, tol, v10: d.aS, v11: d.bS };
    } catch (e) {
      failed++;
      result = {
        module: c.module, name: c.name, passed: false, drift: Infinity, tol,
        v10: 'THREW', v11: (e as Error).message,
      };
    }
    results.push(result);
  }
  return { results, failed };
}

// ─────────────────────────────────────────────────────────────────────────
// CLI
// ─────────────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const wantJson = args.includes('--json');
const moduleFilter = args.find(a => a.startsWith('--module='))?.split('=')[1];

if (moduleFilter) {
  const filtered = CASES.filter(c => c.module === moduleFilter);
  CASES.length = 0;
  CASES.push(...filtered);
}

setWorkingPrecision(60);

// Register the 90 closed-form stability tests (10 × F1..F9).
// Side-effect import: must run AFTER all other registrations so module
// filtering and run order are deterministic.
await import('./stabilityTests');

const { results, failed } = run();

if (wantJson) {
  console.log(JSON.stringify({
    workingPrecision: getWorkingPrecision(),
    total: results.length,
    failed,
    results,
  }, null, 2));
} else {
  for (const r of results) {
    const tag = r.passed ? 'PASS' : 'FAIL';
    console.log(`[${tag}] ${r.module} :: ${r.name}  drift=${r.drift.toExponential(2)}  tol=${r.tol.toExponential(2)}`);
    if (!r.passed) {
      console.log(`        v10: ${r.v10.slice(0, 80)}`);
      console.log(`        v11: ${r.v11.slice(0, 80)}`);
    }
  }
  console.log(`\n${results.length - failed}/${results.length} passed`);
}

process.exit(failed > 0 ? 1 : 0);
