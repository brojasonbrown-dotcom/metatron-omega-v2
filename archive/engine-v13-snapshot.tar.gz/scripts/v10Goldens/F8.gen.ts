/**
 * One-shot golden generator for F8 (Sub-Planckian).
 * Run:  bun scripts/v10Goldens/F8.gen.ts
 * Writes: scripts/v10Goldens/F8.golden.json
 */

import { computeF8_V10, cannedF8Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F8';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const input = cannedF8Input();
const output = computeF8_V10(
  input.coherence, input.energy, input.pinealField,
  input.solfeggioCoherences, input.time,
  input.flowerCoherences, input.hyperGalacticToroidalFeedback,
);

const outPath = join(__dirname, 'F8.golden.json');
writeFileSync(outPath, JSON.stringify(output, (_k, v) => {
  if (v instanceof Float64Array) return Array.from(v);
  return v;
}, 2));
console.log(`F8 golden written: ${outPath}`);
console.log(`  numNodes=${output.superpositions55.length} planckFoamDensity=${output.planckFoamDensity.toFixed(8)} chainUpCoupling=${output.chainUpCoupling.toFixed(8)}`);
