/**
 * One-shot golden generator for F6 (Hebrew · Tree of Life).
 * Run:  bun scripts/v10Goldens/F6_Hebrew.gen.ts
 */
import { computeF6_V10, cannedF6Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F6_Hebrew';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const i = cannedF6Input();
const o = computeF6_V10(
  i.coherence, i.pinealCoherences, i.time,
  i.flowerCoherences, i.solfeggioCoherences,
  i.colorMusicChainUp, i.septenaryCentralColumn,
);
writeFileSync(join(__dirname, 'F6_Hebrew.golden.json'), JSON.stringify(o, null, 2));
console.log(`F6 golden written. hebrewCoherence=${o.hebrewCoherence.toFixed(8)} treeBalance=${o.treeOfLifeBalance.toFixed(8)} sefirot=${o.sefirot.length} paths=${o.treePaths.length} field55=${o.hebrewField55.length}`);
