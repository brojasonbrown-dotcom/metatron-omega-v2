/**
 * One-shot golden generator for F7 (Galactic).
 * Run:  bun scripts/v10Goldens/F7_Galactic.gen.ts
 */
import { computeF7_V10, cannedF7Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F7_Galactic';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const i = cannedF7Input();
const o = computeF7_V10(
  i.coherence, i.energy, i.time, i.recursionDepth,
  i.flowerCoherences, i.solfeggioCoherences, i.hebrewChainUp,
);
writeFileSync(join(__dirname, 'F7_Galactic.golden.json'), JSON.stringify(o, null, 2));
console.log(`F7 golden written. galacticCoherence=${o.galacticCoherence.toFixed(8)}`);
