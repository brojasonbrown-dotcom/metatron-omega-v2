/**
 * One-shot golden generator for F9 (HyperGalactic).
 * Run:  bun scripts/v10Goldens/F9_HyperGalactic.gen.ts
 */
import { computeF9_V10, cannedF9Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F9_HyperGalactic';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const i = cannedF9Input();
const o = computeF9_V10(
  i.coherence, i.energy, i.pinealField, i.solfeggioCoherences,
  i.time, i.recursionDepth, i.flowerCoherences, i.galacticChainUp,
);
writeFileSync(join(__dirname, 'F9_HyperGalactic.golden.json'),
  JSON.stringify(o, (_k, v) => v instanceof Float64Array ? Array.from(v) : v, 2));
console.log(`F9 golden written. cosmicWebCoherence=${o.cosmicWebCoherence.toFixed(8)}`);
