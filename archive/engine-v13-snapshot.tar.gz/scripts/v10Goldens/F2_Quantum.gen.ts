/**
 * One-shot golden generator for F2 (Quantum).
 * Run:  bun scripts/v10Goldens/F2_Quantum.gen.ts
 */
import { computeF2_V10, cannedF2Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F2_Quantum';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const inp = cannedF2Input();
const out = computeF2_V10(
  inp.coherence, inp.energy, inp.pinealField, inp.solfeggioCoherences,
  inp.time, inp.flowerCoherences, inp.septenaryChainUp,
);
const outPath = join(__dirname, 'F2_Quantum.golden.json');
writeFileSync(outPath, JSON.stringify(out, (_k, v) =>
  v instanceof Float64Array ? Array.from(v) : v, 2));
console.log(`F2 golden written: ${outPath}`);
console.log(`  particles=${out.particleModes.length} field55=${out.quantumField55.length} alpha_inv=${out.fineStructure.toFixed(8)} quantumCoherence=${out.quantumCoherence.toFixed(8)}`);
