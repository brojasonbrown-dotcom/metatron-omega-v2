/**
 * One-shot golden generator for F1 (Septenary).
 * Run:  bun scripts/v10Goldens/F1.gen.ts
 * Writes: scripts/v10Goldens/F1.golden.json
 */

import { computeF1_V10, cannedF1Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F1';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const input = cannedF1Input();
const output = computeF1_V10(
  input.coherence, input.phases, input.time,
  input.flowerCoherences, input.subPlanckianChainUp,
);

const outPath = join(__dirname, 'F1.golden.json');
writeFileSync(outPath, JSON.stringify(output, (_k, v) => {
  if (v instanceof Float64Array) return Array.from(v);
  return v;
}, 2));
console.log(`F1 golden written: ${outPath}`);
console.log(`  chakras=${output.chakras.length} overallAlignment=${output.overallAlignment.toFixed(8)} kuramotoOrder=${output.kuramotoOrder.toFixed(8)} psiDampedClosure=${output.psiDampedClosure.toFixed(8)}`);
