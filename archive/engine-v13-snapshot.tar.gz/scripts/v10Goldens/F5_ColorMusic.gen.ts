/**
 * One-shot golden generator for F5 (Color & Music).
 * Run:  bun scripts/v10Goldens/F5_ColorMusic.gen.ts
 * Writes: scripts/v10Goldens/F5_ColorMusic.golden.json
 */

import { computeF5_V10, cannedF5Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F5_ColorMusic';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const i = cannedF5Input();
const o = computeF5_V10(i.coherence, i.solfeggioCoherences, i.time, i.flowerCoherences, i.geometricChainUp);

writeFileSync(join(__dirname, 'F5_ColorMusic.golden.json'),
  JSON.stringify(o, null, 2));
console.log(`F5 golden written. colorMusicCoherence=${o.colorMusicCoherence.toFixed(8)} octaveBridgeCoherence=${o.octaveBridgeCoherence.toFixed(8)}`);
