/**
 * Wave2 precision golden generator for F2.
 *
 * Force-enables FLAG_F2_WAVE2_PRECISION before any F2 import so the QC table
 * is built with the 50-dp Wolfram bank values, then captures the resulting
 * deterministic output into F2_Quantum.wave2.golden.json.
 *
 * Run:  bun scripts/v10Goldens/F2_Quantum.wave2.gen.ts
 *
 * This is the high-precision counterpart to F2_Quantum.gen.ts. The default
 * (flag OFF) golden remains the authoritative V10 parity gate; this golden is
 * only consulted when the flag is ON.
 */
process.env.VITE_FLAG_F2_WAVE2_PRECISION = '1';

import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { computeF2 } from '../../src/core/frameworks/F2_Quantum';
import { cannedF2Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F2_Quantum';
import { portFlag } from '../../src/core/runtime/portFlags';

if (!portFlag('FLAG_F2_WAVE2_PRECISION')) {
  console.error('FATAL: FLAG_F2_WAVE2_PRECISION did not engage. Aborting.');
  process.exit(2);
}

const __dirname = dirname(fileURLToPath(import.meta.url));
const inp = cannedF2Input();
const out = computeF2({
  coherence: inp.coherence, energy: inp.energy, pinealField: inp.pinealField,
  solfeggioCoherences: inp.solfeggioCoherences, time: inp.time,
  flowerCoherences: inp.flowerCoherences, septenaryChainUp: inp.septenaryChainUp,
});

const outPath = join(__dirname, 'F2_Quantum.wave2.golden.json');
writeFileSync(outPath, JSON.stringify(out, (_k, v) =>
  v instanceof Float64Array ? Array.from(v) : v, 2));
console.log(`F2 Wave2 golden written: ${outPath}`);
console.log(
  `  particles=${out.particleModes.length} field55=${out.quantumField55.length} ` +
  `alpha_inv=${out.fineStructure.toFixed(12)} protonElectronRatio=${out.protonElectronRatio.toFixed(8)} ` +
  `quantumCoherence=${out.quantumCoherence.toFixed(12)}`,
);
