/**
 * Wave2 precision golden + parity runner (multi-framework).
 *
 * Force-enables FLAG_WAVE2_PRECISION, recomputes F1/F5/F6/F9 with their
 * deterministic canned V10 inputs, and either:
 *   - generates *.wave2.golden.json (--write), or
 *   - validates every numeric leaf in the current output against the saved
 *     golden at 1e-12 relative tolerance (--check, default).
 *
 * F2 keeps its own dedicated scripts (richer per-field labels). This runner
 * generalises the same shape across F1, F5, F6, F9.
 *
 * Run:
 *   bun scripts/v10Goldens/wave2GoldenRunner.ts --write    # regenerate
 *   bun scripts/v10Goldens/wave2GoldenRunner.ts            # verify
 */
process.env.VITE_FLAG_WAVE2_PRECISION = '1';

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

import { computeF1 } from '../../src/core/frameworks/F1_Septenary';
import { computeF5 } from '../../src/core/frameworks/F5_ColorMusic';
import { computeF6 } from '../../src/core/frameworks/F6_Hebrew';
import { computeF9 } from '../../src/core/frameworks/F9_HyperGalactic';
import { cannedF1Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F1';
import { cannedF5Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F5_ColorMusic';
import { cannedF6Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F6_Hebrew';
import { cannedF9Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F9_HyperGalactic';
import { portFlag } from '../../src/core/runtime/portFlags';

if (!portFlag('FLAG_WAVE2_PRECISION')) {
  console.error('FATAL: FLAG_WAVE2_PRECISION did not engage. Aborting.');
  process.exit(2);
}

const __dirname = dirname(fileURLToPath(import.meta.url));
const WRITE = process.argv.includes('--write');
const TOL = 1e-12;

const FRAMEWORKS: ReadonlyArray<{ name: string; goldenFile: string; compute: () => unknown }> = [
  { name: 'F1', goldenFile: 'F1.wave2.golden.json',           compute: () => computeF1(cannedF1Input() as any) },
  { name: 'F5', goldenFile: 'F5_ColorMusic.wave2.golden.json', compute: () => computeF5(cannedF5Input() as any) },
  { name: 'F6', goldenFile: 'F6_Hebrew.wave2.golden.json',     compute: () => computeF6(cannedF6Input() as any) },
  { name: 'F9', goldenFile: 'F9_HyperGalactic.wave2.golden.json', compute: () => computeF9(cannedF9Input() as any) },
];

function toPlain(v: unknown): unknown {
  if (v instanceof Float64Array || v instanceof Float32Array) return Array.from(v);
  if (Array.isArray(v)) return v.map(toPlain);
  if (v && typeof v === 'object') {
    const o: Record<string, unknown> = {};
    for (const [k, vv] of Object.entries(v as Record<string, unknown>)) o[k] = toPlain(vv);
    return o;
  }
  return v;
}

function reldiff(a: number, b: number): number {
  if (!isFinite(a) || !isFinite(b)) return a === b ? 0 : Infinity;
  const denom = Math.max(Math.abs(a), Math.abs(b), 1e-300);
  if (denom < 1e-300) return 0;
  return Math.abs(a - b) / denom;
}

function deepCompare(path: string, gold: any, live: any, fails: string[]): number {
  let leaves = 0;
  if (typeof gold === 'number') {
    leaves++;
    const d = reldiff(gold, live);
    if (!(d <= TOL)) fails.push(`  ✗ ${path}: golden=${gold} live=${live} rel=${d}`);
    return leaves;
  }
  if (Array.isArray(gold)) {
    if (!Array.isArray(live) || live.length !== gold.length) {
      fails.push(`  ✗ ${path}: array shape diff (g=${gold.length} l=${Array.isArray(live)?live.length:'?'})`);
      return leaves;
    }
    for (let i = 0; i < gold.length; i++) leaves += deepCompare(`${path}[${i}]`, gold[i], live[i], fails);
    return leaves;
  }
  if (gold && typeof gold === 'object') {
    if (!live || typeof live !== 'object') {
      fails.push(`  ✗ ${path}: object expected, got ${typeof live}`);
      return leaves;
    }
    for (const k of Object.keys(gold)) leaves += deepCompare(`${path}.${k}`, gold[k], live[k], fails);
    return leaves;
  }
  // strings / booleans / null — strict equality
  if (gold !== live) fails.push(`  ✗ ${path}: golden=${JSON.stringify(gold)} live=${JSON.stringify(live)}`);
  return leaves;
}

let totalLeaves = 0;
let totalFails = 0;
for (const fw of FRAMEWORKS) {
  const goldenPath = join(__dirname, fw.goldenFile);
  const live = toPlain(fw.compute());

  if (WRITE) {
    writeFileSync(goldenPath, JSON.stringify(live, null, 2));
    console.log(`[gen] ${fw.name} wrote ${fw.goldenFile}`);
    continue;
  }

  if (!existsSync(goldenPath)) {
    console.error(`[skip] ${fw.name}: missing ${fw.goldenFile} (run with --write first)`);
    totalFails++;
    continue;
  }
  const gold = JSON.parse(readFileSync(goldenPath, 'utf8'));
  const fails: string[] = [];
  const leaves = deepCompare(fw.name, gold, live, fails);
  totalLeaves += leaves;
  totalFails += fails.length;
  if (fails.length) {
    console.error(`[FAIL] ${fw.name}: ${fails.length} mismatches over ${leaves} numeric leaves`);
    for (const f of fails.slice(0, 20)) console.error(f);
    if (fails.length > 20) console.error(`  …(${fails.length - 20} more)`);
  } else {
    console.log(`[PASS] ${fw.name}: ${leaves} numeric leaves within ${TOL} rel`);
  }
}

if (WRITE) {
  console.log('Done.');
  process.exit(0);
} else {
  console.log(`\nWave2 multi-framework parity: ${totalLeaves - totalFails}/${totalLeaves} numeric leaves passed (tol=${TOL})`);
  process.exit(totalFails);
}
