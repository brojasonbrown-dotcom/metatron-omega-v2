/**
 * One-shot golden generator for F4 (Geometric).
 * Run:  bun scripts/v10Goldens/F4.gen.ts
 * Writes: scripts/v10Goldens/F4.golden.json
 */

import { computeF4_V10, cannedF4Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F4';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const input = cannedF4Input();
const output = computeF4_V10(
  input.coherence, input.nodeCoherences, input.time,
  input.solfeggioCoherences, input.flowerCoherences, input.atomicChainUp,
);

const outPath = join(__dirname, 'F4.golden.json');
writeFileSync(outPath, JSON.stringify(output, null, 2));
console.log(`F4 golden written: ${outPath}`);
console.log(`  geometricCoherence=${output.geometricCoherence.toFixed(8)}`);
console.log(`  geometricComposite=${output.geometricComposite.toFixed(8)}`);
console.log(`  metatronCubeIntegrity=${output.metatronCubeIntegrity.toFixed(8)}`);
