/**
 * One-shot golden generator for F3 (Atomic).
 * Run:  bun scripts/v10Goldens/F3_Atomic.gen.ts
 */
import { computeF3_V10, cannedF3Input } from '../../vendor/v10-reference/src/engine/v10Goldens/F3_Atomic';
import { writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const inp = cannedF3Input();
const out = computeF3_V10(
  inp.coherence, inp.nodeAmps, inp.solfeggioCoherences,
  inp.time, inp.flowerCoherences, inp.quantumChainUp,
);
const outPath = join(__dirname, 'F3_Atomic.golden.json');
writeFileSync(outPath, JSON.stringify(out, (_k, v) =>
  v instanceof Float64Array ? Array.from(v) : v, 2));
console.log(`F3 golden written: ${outPath}`);
console.log(`  periods=${out.periodModes.length} bohr=${out.bohrOrbits.length} field55=${out.atomicField55.length} atomicCoherence=${out.atomicCoherence.toFixed(8)}`);
